/*
 * automine_csr.cpp
 *
 *  Created on: 16:28 PM Monday 2023-4-17
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <cstdint>
#include <fstream>
#include <string>
#include <unordered_map>
#include <vector>

#include "include/common.hpp"
#include "include/csr/compile/automine_csr.hpp"
#include "include/csr/graph.hpp"
#include "include/csr/vertexset.hpp"
#include "include/utility/clock.hpp"
#include "include/utility/config.hpp"
#include "include/utility/logger.hpp"
#include "include/utility/utility.hpp"

namespace csr {

namespace compile {

namespace automine_csr {

// local type
typedef std::vector<vid_t> result_1d_t;
typedef std::vector<result_1d_t> result_2d_t;

using utility::COUNTER_LOOP_0;
using utility::COUNTER_LOOP_1;
using utility::COUNTER_LOOP_2;
using utility::COUNTER_LOOP_3;
using utility::COUNTER_LOOP_4;
using utility::COUNTER_LOOP_5;

uint64_t COUNTER;
std::ofstream OUTPUT;

#if !defined(COUNTING) and defined(LISTING)

#define Return      (void (0))
#define ReturnType  void
#define Argument    const Graph &g
#define Initialize  std::ofstream out
#define Inner3      out << v0 << " " << v1 << " " << v2 << std::endl
#define Inner4      out << v0 << " " << v1 << " " << v2 << " " << v3 << std::endl
#define Inner5      out << v0 << " " << v1 << " " << v2 << " " << v3 << " " << v4 << std::endl

#elif !defined(COUNTING) and defined(MEMORY)

#define Return                              (void (0))
#define ReturnType                          void
#define Argument                            const Graph &g, result_2d_t& out
#define Initialize                          (void (0))
#define Inner3(out, v0, v1, v2)             out.Append(result_1d_t {v0, v1, v2})
#define Inner4(out, v0, v1, v2, v3)         out.Append(result_1d_t {v0, v1, v2, v3})
#define Inner5(out, v0, v1, v2, v3, v4)     out.push_back(result_1d_t {v0, v1, v2, v3, v4} )

#else

// default COUNTING
#define Return                              return out
#define ReturnType                          uint64_t
#define Argument                            const Graph &g
#define Initialize                          ReturnType out
#define Inner3(out, v0, v1, v2)             out++
#define Inner4(out, v0, v1, v2, v3)         out++
#define Inner5(out, v0, v1, v2, v3, v4)     out++

#endif

#ifdef MEASURE_PERFORMANCE
#define AddOne(x)   (x++)
#else
#define AddOne(x)   (void (0))
#endif

// function with Argument as argument and ReturnType as return type
using expression_t = void (*)(const Graph &, result_2d_t &);
typedef std::unordered_map<std::string, expression_t> expression_map_t;

uint64_t After(Config &config, result_2d_t &result) {
#if !defined(COUNTING) and defined(LISTING)
    // counter lines in the output file
    std::ifstream in_file(config.SaveFile());
    return std::count(std::istreambuf_iterator<char>(in_file),
            std::istreambuf_iterator<char>(), '\n');
#elif !defined(COUNTING) and defined(MEMORY)
    return result.size();
#endif
    return COUNTER;
}

bool Before(Config &config) {
    // return status. true: good. false: failure
#if !defined(COUNTING) and defined(LISTING)
    PrintLCTX("LISTING");
    const std::string &out_file = config.SaveFile();
    if (out_file.size()) {
        OUTPUT.open(out_file);
    } else {
        PrintLCTX("LISTING missing argument: " << Config::KeySaveFile);
        return false;
    }
#elif !defined(COUNTING) and defined(MEMORY)
    PrintLCTX("MEMORY");
#else
    PrintLCTX("Default: COUNTING");
    COUNTER = 0;
#endif
    return true;
}

/* local variable name convention
 * d: difference
 * i: intersection
 * n: neighbor
 * s: less / smaller
 * v: vertex
 */
// size 3
void Triangle_cba(const Graph &g, result_2d_t &result) {
    /* also 3-clique, v0-v1-v2-v0, symmetry breaking v2<v1<v0
     *   v0
     *  /  \
     * v1--vx
     */
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0s0 = g.N(v0, v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            COUNTER += IntersectSize(n0s0, n1, v1);
        }
    }
}

void TwoPath_cb(const Graph &g, result_2d_t &result) {
    // v1-v0-v2, symmetry breaking v2<v1
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        for (vid_t idx1 = 0; idx1 < n0.size; idx1++) {
            vid_t v1 = n0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            COUNTER += DifferenceSize(n0, n1, v1);
        }
    }
}

// size 4
void Diamond_ba_dc(const Graph &g, result_2d_t &result) {
    /* symmetry breaking v1<v0, v3<v2
     * v2-v0
     * | / |
     * v1-vx
     */
    VertexSet n0n1;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            n0n1.ISet(n0, g.N(v1));
            for (vid_t idx2 = 0; idx2 < n0n1.size; idx2++) {
                vid_t v2 = n0n1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                COUNTER += DifferenceSize(n0n1, n2, v2);
            }
        }
    }
}

void FourClique_dcba(const Graph &g, result_2d_t &result) {
    /* symmetry breaking v3<v2<v1<v0
     * v0---v1
     *  | \/ |
     *  | /\ |
     * v2---vx
     * this is 4-clique
     */
    VertexSet n0s0n1s1;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        AddOne(COUNTER_LOOP_0);
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            AddOne(COUNTER_LOOP_1);
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0s0n1s1.ISet(n0s0, n1, v1);
            for (vid_t idx2 = 0; idx2 < n0s0n1s1.size; idx2++) {
                AddOne(COUNTER_LOOP_2);
                vid_t v2 = n0s0n1s1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                COUNTER += IntersectSize(n0s0n1s1, n2, v2);
            }
        }
    }
}

void FourCycle_cba_da(const Graph &g, result_2d_t &result) {
    /* v0-v1-v3-v2-v0 with symmetry breaking v2<v1<v0, v3<v0
     *
     * v0---v1
     *  |   |
     * v2---vx
     */
    VertexSet d0s0n1;
    VertexSet n0s0d1s1;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            d0s0n1.DSet(n1, v0, n0);
            n0s0d1s1.DSet(n0s0, n1, v1);
            for (vid_t idx2 = 0; idx2 < n0s0d1s1.size; idx2++) {
                vid_t v2 = n0s0d1s1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                COUNTER += IntersectSize(d0s0n1, n2, v0);
            }
        }
    }
}

void TailedTriangle_ba(const Graph &g, result_2d_t &result) {
    /* symmetry breaking v1<v0
     * v0--v1
     *  \ /
     *   v2
     *   |
     *   vx
     */
    VertexSet n0n1;
    VertexSet d0n2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            for (vid_t idx2 = 0; idx2 < n0n1.size; idx2++) {
                vid_t v2 = n0n1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                d0n2.DSet(n2, v0, n0);
                COUNTER += DifferenceSize(d0n2, v1, n1);
            }
        }
    }
}

void ThreePath_ba(const Graph &g, result_2d_t &result) {
    /*
     * v0---v1
     *  |    |
     * v2   vx
     */
    VertexSet d0n1;
    VertexSet n0d1;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            d0n1.DSet(n1, v0, n0);
            n0d1.DSet(n0, v1, n1);
            for (vid_t idx2 = 0; idx2 < n0d1.size; idx2++) {
                vid_t v2 = n0d1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                COUNTER += DifferenceSize(d0n1, v2, n2);
            }
        }
    }
}

void ThreeStar_dcb(const Graph &g, result_2d_t &result) {
    /* v0-v1, v0-v2, v0-v3 with symmetry breaking v3<v2<v1
     *   v1
     *   |
     *   v0
     *  / \
     * v2  vx
     */
    VertexSet n0d1s1;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        for (vid_t idx1 = 0; idx1 < n0.size; idx1++) {
            vid_t v1 = n0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0d1s1.DSet(n0, n1, v1);
            for (vid_t idx2 = 0; idx2 < n0d1s1.size; idx2++) {
                vid_t v2 = n0d1s1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                COUNTER += DifferenceSize(n0d1s1, n2, v2);
            }
        }
    }
}

// size 5
void AlmostFiveClique_cba_ed(const Graph &g, result_2d_t &result) {
    /* only (v3, v4) are not connected
     *   --v0--
     *  /  /\  \
     * v1-/--\-v2
     *  \/ \/ \/
     *  v3    vx
     */
    VertexSet n0n1;
    VertexSet n0s0n1s1;
    VertexSet n0n1n2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            n0s0n1s1.ISet(n0s0, n1, v1);
            for (vid_t idx2 = 0; idx2 < n0s0n1s1.size; idx2++) {
                vid_t v2 = n0s0n1s1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                n0n1n2.ISet(n0n1, n2);
                for (vid_t idx3 = 0; idx3 < n0n1n2.size; idx3++) {
                    vid_t v3 = n0n1n2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += DifferenceSize(n0n1n2, n3, v3);
                }
            }
        }
    }
}

void Cobra_ba(const Graph &g, result_2d_t &result) {
    /*   v2
     *  / \
     * v0--v1
     *  \ /
     *   v3
     *   |
     *   vx
     */
    VertexSet n0n1;
    VertexSet n0n1d2;
    VertexSet d0d1n3;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            for (vid_t idx2 = 0; idx2 < n0n1.size; idx2++) {
                vid_t v2 = n0n1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                n0n1d2.DSet(n0n1, v2, n2);
                for (vid_t idx3 = 0; idx3 < n0n1d2.size; idx3++) {
                    vid_t v3 = n0n1d2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    d0d1n3.DSet(n3, v0, n0);
                    d0d1n3.DSet(d0d1n3, v1, n1);
                    COUNTER += DifferenceSize(d0d1n3, v2, n2);
                }
            }
        }
    }
}

void DiamondWedgeCollision_ba_dc(const Graph &g, result_2d_t &result) {
    /*    v0
     *   / | \
     * v3-v1-v2
     *   \   /
     *    vx
     */
    VertexSet n0n1;
    VertexSet n0n1d2s2;
    VertexSet d0d1n2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            for (vid_t idx2 = 0; idx2 < n0n1.size; idx2++) {
                vid_t v2 = n0n1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                n0n1d2s2.DSet(n0n1, n2, v2);
                d0d1n2.DSet(n2, v1, n0);
                d0d1n2.DSet(d0d1n2, v1, n1);
                for (vid_t idx3 = 0; idx3 < n0n1d2s2.size; idx3++) {
                    vid_t v3 = n0n1d2s2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += IntersectSize(d0d1n2, n3);
                }
            }
        }
    }
}

void DoubleTailedTriangle_ba(const Graph &g, result_2d_t &result) {
    /*    v2
     *   /  \
     * v0----v1
     *  |    |
     * v3    vx
     */
    VertexSet n0n1;
    VertexSet d0n1;
    VertexSet n0d1;
    VertexSet d0n1d2;
    VertexSet n0d1d2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            d0n1.DSet(n1, v0, n0);
            n0d1.DSet(n0, v1, n1);
            for (vid_t idx2 = 0; idx2 < n0n1.size; idx2++) {
                vid_t v2 = n0n1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                d0n1d2.DSet(d0n1, v2, n2);
                n0d1d2.DSet(n0d1, v2, n2);
                for (vid_t idx3 = 0; idx3 < n0d1d2.size; idx3++) {
                    vid_t v3 = n0d1d2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += DifferenceSize(d0n1d2, v3, n3);
                }
            }
        }
    }
}

void FiveClique_edcba(const Graph &g, result_2d_t &result) {
    /*
     * clique
     *   ---v0---
     *  /   /\   \
     * v1--/--\-v2
     *  \ /    \/
     *   v3----vx
     */
    VertexSet n0s0n1s1;
    VertexSet n0s0n1s1n2s2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0s0n1s1.ISet(n0s0, n1, v1);
            for (vid_t idx2 = 0; idx2 < n0s0n1s1.size; idx2++) {
                vid_t v2 = n0s0n1s1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                n0s0n1s1n2s2.ISet(n0s0n1s1, n2, v2);
                for (vid_t idx3 = 0; idx3 < n0s0n1s1n2s2.size; idx3++) {
                    vid_t v3 = n0s0n1s1n2s2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += IntersectSize(n0s0n1s1n2s2, n3, v3);
                }
            }
        }
    }
}

void FiveCycle_cba_da_ea(const Graph &g, result_2d_t &result) {
    /* 5-cycle
     * v0 -- v1
     *  |     |
     * v2-vx-v3
     */
    VertexSet d0s0n1;
    VertexSet n0s0d1s1;
    VertexSet d0s0d1n2;
    VertexSet d0s0n1d2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            d0s0n1.DSet(n1, v0, n0);
            n0s0d1s1.DSet(n0s0, n1, v1);
            for (vid_t idx2 = 0; idx2 < n0s0d1s1.size; idx2++) {
                vid_t v2 = n0s0d1s1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                d0s0d1n2.DSet(n2, v0, n0);
                d0s0d1n2.DSet(d0s0d1n2, v1, n1);
                d0s0n1d2.DSet(d0s0n1, v2, n2, v0);
                for (vid_t idx3 = 0; idx3 < d0s0n1d2.size; idx3++) {
                    vid_t v3 = d0s0n1d2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += IntersectSize(d0s0d1n2, n3, v0);
                }
            }
        }
    }
}

void ForktailedTriangle_ba_ed(const Graph &g, result_2d_t &result) {
    /* v0----v1
     *   \  /
     *    v2
     *   /  \
     * v3    vx
     */
    VertexSet n0n1;
    VertexSet d0d1n2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            for (vid_t idx2 = 0; idx2 < n0n1.size; idx2++) {
                vid_t v2 = n0n1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                d0d1n2.DSet(n2, v0, n0);
                d0d1n2.DSet(d0d1n2, v1, n1);
                for (vid_t idx3 = 0; idx3 < d0d1n2.size; idx3++) {
                    vid_t v3 = d0d1n2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += DifferenceSize(d0d1n2, n3, v3);
                }
            }
        }
    }
}

void FourPath_cb(const Graph &g, result_2d_t &result) {
    // v3-v1-v0-v2-vx
    VertexSet d0n1;
    VertexSet n0d1s1;
    VertexSet d0d1n2;
    VertexSet d0n1d2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        for (vid_t idx1 = 0; idx1 < n0.size; idx1++) {
            vid_t v1 = n0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            d0n1.DSet(n1, v0, n0);
            n0d1s1.DSet(n0, n1, v1);
            for (vid_t idx2 = 0; idx2 < n0d1s1.size; idx2++) {
                vid_t v2 = n0d1s1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                d0d1n2.DSet(n2, v0, n0);
                d0d1n2.DSet(d0d1n2, v1, n1);
                d0n1d2.DSet(d0n1, v2, n2);
                for (vid_t idx3 = 0; idx3 < d0n1d2.size; idx3++) {
                    vid_t v3 = d0n1d2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += DifferenceSize(d0d1n2, v3, n3);
                }
            }
        }
    }
}

void FourStar_edcb(const Graph &g, result_2d_t &result) {
    /*     v2
     *     |
     * v1--v0--v3
     *     |
     *     vx
     */
    VertexSet n0d1s1;
    VertexSet n0d1s1d2s2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        for (vid_t idx1 = 0; idx1 < n0.size; idx1++) {
            vid_t v1 = n0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0d1s1.DSet(n0, n1, v1);
            for (vid_t idx2 = 0; idx2 < n0d1s1.size; idx2++) {
                vid_t v2 = n0d1s1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                n0d1s1d2s2.DSet(n0d1s1, n2, v2);
                for (vid_t idx3 = 0; idx3 < n0d1s1d2s2.size; idx3++) {
                    vid_t v3 = n0d1s1d2s2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += DifferenceSize(n0d1s1d2s2, n3, v3);
                }
            }
        }
    }
}

void FourWheel_dba_ea(const Graph &g, result_2d_t &result) {
    /*     v0
     *   / | \
     * v3-v2-v1
     *   \ | /
     *     vx
     */
    VertexSet n0n1;
    VertexSet d0s0n1;
    VertexSet n0s0d1s1;
    VertexSet d0s0n1n2;
    VertexSet n0s0d1n2s1;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            d0s0n1.DSet(n1, v1, n0);
            n0s0d1s1.DSet(n0s0, n1, v1);
            for (vid_t idx2 = 0; idx2 < n0n1.size; idx2++) {
                vid_t v2 = n0n1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                d0s0n1n2.ISet(d0s0n1, n2);
                n0s0d1n2s1.ISet(n0s0d1s1, n2, v1);
                for (vid_t idx3 = 0; idx3 < n0s0d1n2s1.size; idx3++) {
                    vid_t v3 = n0s0d1n2s1.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += IntersectSize(d0s0n1n2, n3, v0);
                }
            }
        }
    }
}

void HattedFourClique_ba_ed(const Graph &g, result_2d_t &result) {
    /*    v2
     *   /  \
     * v0---v1
     *  | \/ |
     *  | /\ |
     * v3---vx
     */
    VertexSet n0n1;
    VertexSet n0n1d2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            for (vid_t idx2 = 0; idx2 < n0n1.size; idx2++) {
                vid_t v2 = n0n1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                n0n1d2.DSet(n0n1, v2, n2);
                for (vid_t idx3 = 0; idx3 < n0n1d2.size; idx3++) {
                    vid_t v3 = n0n1d2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += IntersectSize(n0n1d2, n3, v3);
                }
            }
        }
    }
}

void HattedFourCycle_ba(const Graph &g, result_2d_t &result) {
    /*    v2
     *   /  \
     * v0----v1
     *  |    |
     * v3----vx
     */
    VertexSet n0n1;
    VertexSet d0n1;
    VertexSet n0d1;
    VertexSet d0n1d2;
    VertexSet n0d1d2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            d0n1.DSet(n1, v0, n0);
            n0d1.DSet(n0, v1, n1);
            for (vid_t idx2 = 0; idx2 < n0n1.size; idx2++) {
                vid_t v2 = n0n1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                d0n1d2.DSet(d0n1, v2, n2);
                n0d1d2.DSet(n0d1, v2, n2);
                for (vid_t idx3 = 0; idx3 < n0d1d2.size; idx3++) {
                    vid_t v3 = n0d1d2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += IntersectSize(d0n1d2, n3);
                }
            }
        }
    }
}

void Hourglass_ba_eda(const Graph &g, result_2d_t &result) {
    /* v0---v1
     *   \  /
     *    v2
     *   /  \
     * v3---vx
     */
    VertexSet n0n1;
    VertexSet d0d1n2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            for (vid_t idx2 = 0; idx2 < n0n1.size; idx2++) {
                vid_t v2 = n0n1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                d0d1n2.DSet(n2, v0, n0);
                d0d1n2.DSet(d0d1n2, v1, n1);
                NeighborSet d0d1n2s0(d0d1n2.data, d0d1n2.size, v0);
                for (vid_t idx3 = 0; idx3 < d0d1n2s0.size; idx3++) {
                    vid_t v3 = d0d1n2s0.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += IntersectSize(d0d1n2, n3, v3);
                }
            }
        }
    }
}

void LongTailedTriangle_ba(const Graph &g, result_2d_t &result) {
    /* v0 -- v1
     *   \  /
     *    v2
     *     |
     *    v3
     *     |
     *    vx
     */
    VertexSet n0n1;
    VertexSet d0d1n2;
    VertexSet d0d1n3;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            for (vid_t idx2 = 0; idx2 < n0n1.size; idx2++) {
                vid_t v2 = n0n1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                d0d1n2.DSet(n2, v0, n0);
                d0d1n2.DSet(d0d1n2, v1, n1);
                for (vid_t idx3 = 0; idx3 < d0d1n2.size; idx3++) {
                    vid_t v3 = d0d1n2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    d0d1n3.DSet(n3, v0, n0);
                    d0d1n3.DSet(d0d1n3, v1, n1);
                    COUNTER += DifferenceSize(d0d1n3, v2, n2);
                }
            }
        }
    }
}

void Prong_dc(const Graph &g, result_2d_t &result) {
    /* v2--v0--v3
     *     |
     *     v1
     *     |
     *     v4
     */
    VertexSet d0n1;
    VertexSet n0d1;
    VertexSet d0n1d2;
    VertexSet n0d1d2s2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        for (vid_t idx1 = 0; idx1 < n0.size; idx1++) {
            vid_t v1 = n0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            d0n1.DSet(n1, v0, n0);
            n0d1.DSet(n0, v1, n1);
            for (vid_t idx2 = 0; idx2 < n0d1.size; idx2++) {
                vid_t v2 = n0d1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                d0n1d2.DSet(d0n1, v2, n2);
                n0d1d2s2.DSet(n0d1, n2, v2);
                for (vid_t idx3 = 0; idx3 < n0d1d2s2.size; idx3++) {
                    vid_t v3 = n0d1d2s2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += DifferenceSize(d0n1d2, v3, n3);
                }
            }
        }
    }
}

void Stingray_cb(const Graph &g, result_2d_t &result) {
    /*    v0
     *  / | \
     * v1 |  v2
     *  \ | /
     *    v3
     *    |
     *    v4
     */
    VertexSet n0n1;
    VertexSet n0d1;
    VertexSet n0n1n2;
    VertexSet d0d1n3;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        for (vid_t idx1 = 0; idx1 < n0.size; idx1++) {
            vid_t v1 = n0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            n0d1.DSet(n0, v1, n1);
            NeighborSet n0d1s1(n0d1.data, n0d1.size, v1);
            for (vid_t idx2 = 0; idx2 < n0d1s1.size; idx2++) {
                vid_t v2 = n0d1s1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                n0n1n2.ISet(n0n1, n2);
                for (vid_t idx3 = 0; idx3 < n0n1n2.size; idx3++) {
                    vid_t v3 = n0n1n2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    d0d1n3.DSet(n3, v0, n0);
                    d0d1n3.DSet(d0d1n3, v1, n1);
                    COUNTER += DifferenceSize(d0d1n3, v2, n2);
                }
            }
        }
    }
}

void TailedFourClique_cba(const Graph &g, result_2d_t &result) {
    /* tailed-4-clique
     *     v0
     *   / | \
     * v1--|--v2
     *   \ | /
     *     v3
     *     |
     *    vx
     */
    VertexSet n0n1;
    VertexSet n0s0n1s1;
    VertexSet n0n1n2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            n0s0n1s1.ISet(n0s0, n1, v1);
            for (vid_t idx2 = 0; idx2 < n0s0n1s1.size; idx2++) {
                vid_t v2 = n0s0n1s1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                n0n1n2.ISet(n0n1, n2);
                for (vid_t idx3 = 0; idx3 < n0n1n2.size; idx3++) {
                    vid_t v3 = n0n1n2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    VertexSet d0d1n3;
                    d0d1n3.DSet(n3, v0, n0);
                    d0d1n3.DSet(d0d1n3, v1, n1);
                    COUNTER += DifferenceSize(d0d1n3, v2, n2);
                }
            }
        }
    }
}

void TailedFourCycle_ca(const Graph &g, result_2d_t &result) {
    /*    v1
     *   / \
     * v0   v2
     *   \ /
     *    v3
     *    |
     *    v4
     */
    VertexSet d0n1s0;
    VertexSet n0d1;
    VertexSet n0d1n2;
    VertexSet d0d1n3;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        for (vid_t idx1 = 0; idx1 < n0.size; idx1++) {
            vid_t v1 = n0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            d0n1s0.DSet(n1, n0, v0);
            n0d1.DSet(n0, v1, n1);
            for (vid_t idx2 = 0; idx2 < d0n1s0.size; idx2++) {
                vid_t v2 = d0n1s0.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                n0d1n2.ISet(n0d1, n2);
                for (vid_t idx3 = 0; idx3 < n0d1n2.size; idx3++) {
                    vid_t v3 = n0d1n2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    d0d1n3.DSet(n3, v0, n0);
                    d0d1n3.DSet(d0d1n3, v1, n1);
                    COUNTER += DifferenceSize(d0d1n3, v3, n2);
                }
            }
        }
    }
}

void ThreeTriangleCollision_ba_edc(const Graph &g, result_2d_t &result) {
    /*      v2
     *     /  \
     *    / v3 \
     *   / /  \ \
     * v0 ------ v1
     *   \      /
     *      vx
     */
    VertexSet n0n1;
    VertexSet n0n1d2s2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            for (vid_t idx2 = 0; idx2 < n0n1.size; idx2++) {
                vid_t v2 = n0n1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                n0n1d2s2.DSet(n0n1, n2, v2);
                for (vid_t idx3 = 0; idx3 < n0n1d2s2.size; idx3++) {
                    vid_t v3 = n0n1d2s2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += DifferenceSize(n0n1d2s2, n3, v3);
                }
            }
        }
    }
}

void ThreeWedgeCollision_ca_edb(const Graph &g, result_2d_t &result) {
    /*
     * v0-----v1
     * | \    |
     * |  vx  |
     * |    \ |
     * v3-----v2
     */
    VertexSet d0n1s0;
    VertexSet n0d1;
    VertexSet n0d1n2s1;
    VertexSet n0d1s1n2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        for (vid_t idx1 = 0; idx1 < n0.size; idx1++) {
            vid_t v1 = n0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            d0n1s0.DSet(n1, n0, v0);
            n0d1.DSet(n0, v1, n1);
            NeighborSet n0d1s1(n0d1.data, n0d1.size, v1);
            for (vid_t idx2 = 0; idx2 < d0n1s0.size; idx2++) {
                vid_t v2 = d0n1s0.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                n0d1n2s1.ISet(n0d1, n2, v1);
                n0d1s1n2.ISet(n0d1s1, n2);
                for (vid_t idx3 = 0; idx3 < n0d1n2s1.size; idx3++) {
                    vid_t v3 = n0d1n2s1.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += DifferenceSize(n0d1s1n2, n3, v3);
                }
            }
        }
    }
}

void TriangleStrip_ba(const Graph &g, result_2d_t &result) {
    /*   v0 -- v1
     *  /  \  / \
     * v3 - v2 - v4
     */
    VertexSet n0n1;
    VertexSet d0n1;
    VertexSet n0d1;
    VertexSet d0n1n2;
    VertexSet n0d1n2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet n0s0 = n0.Less(v0);
        for (vid_t idx1 = 0; idx1 < n0s0.size; idx1++) {
            vid_t v1 = n0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0n1.ISet(n0, n1);
            d0n1.DSet(n1, v0, n0);
            n0d1.DSet(n0, v1, n1);
            for (vid_t idx2 = 0; idx2 < n0n1.size; idx2++) {
                vid_t v2 = n0n1.Vertex(idx2);
                NeighborSet n2 = g.N(v2);
                d0n1n2.ISet(d0n1, n2);
                n0d1n2.ISet(n0d1, n2);
                for (vid_t idx3 = 0; idx3 < n0d1n2.size; idx3++) {
                    vid_t v3 = n0d1n2.Vertex(idx3);
                    NeighborSet n3 = g.N(v3);
                    COUNTER += DifferenceSize(d0n1n2, v3, n3);
                }
            }
        }
    }
}

// define here and compile only once
expression_map_t InitializeQueryPlan() {
    /* hash key follows the AutoMine paper
     * each query plan is executed in v0,v1,v2,v3,v4,... order
     * vertex in the function name is the symmetry breaking, separated by _
     * a maps to v0, b maps to v1, ...
     * cba_da means two symmetry breaking: v2<v1<v0 and v3<v0
     */
    expression_map_t e_map;
    e_map.reserve(100);
    // size 3
    e_map["triangle"] = Triangle_cba;
    e_map["2-path"] = TwoPath_cb;
    // size 4
    e_map["diamond"] = Diamond_ba_dc;
    e_map["4-clique"] = FourClique_dcba;
    e_map["4-cycle"] = FourCycle_cba_da;
    e_map["tailed-triangle"] = TailedTriangle_ba;
    e_map["3-path"] = ThreePath_ba;
    e_map["3-star"] = ThreeStar_dcb;
    // size 5
    e_map["almost-5-clique"] = AlmostFiveClique_cba_ed;
    e_map["cobra"] = Cobra_ba;
    e_map["diamond-wedge-collision"] = DiamondWedgeCollision_ba_dc;
    e_map["double-tailed-triangle"] = DoubleTailedTriangle_ba;
    e_map["5-clique"] = FiveClique_edcba;
    e_map["5-cycle"] = FiveCycle_cba_da_ea;
    e_map["forktailed-triangle"] = ForktailedTriangle_ba_ed;
    e_map["4-path"] = FourPath_cb;
    e_map["4-star"] = FourStar_edcb;
    e_map["4-wheel"] = FourWheel_dba_ea;
    e_map["hatted-4-clique"] = HattedFourClique_ba_ed;
    e_map["hatted-4-cycle"] = HattedFourCycle_ba;
    e_map["hourglass"] = Hourglass_ba_eda;
    e_map["long-tailed-triangle"] = LongTailedTriangle_ba;
    e_map["prong"] = Prong_dc;
    e_map["stingray"] = Stingray_cb;
    e_map["tailed-4-clique"] = TailedFourClique_cba;
    e_map["tailed-4-cycle"] = TailedFourCycle_ca;
    e_map["3-triangle-collision"] = ThreeTriangleCollision_ba_edc;
    e_map["3-wedge-collision"] = ThreeWedgeCollision_ca_edb;
    e_map["triangle-strip"] = TriangleStrip_ba;
    return e_map;
}

// public function
bool ExecuteByQueryName(Config &config, const Graph &g, Logger &logger) {
    // execute query by QueryName. pre-defined plans
    // return status. true: good, false: failure
    expression_map_t query_plan = InitializeQueryPlan();
    if (g.LabelSize() > 1) {
        if (config.IsLabeled()) {
            // non uniformly labeled graph (directed/undirected)
            PrintLCTX("not support labels. skip.");
        } else {
            // unlabeled directed graph
            PrintLCTX("not support directed graphs. skip.");
        }
        return false;
    }
    /* c++ error: qualified-id in declaration before '=' token
     * https://stackoverflow.com/a/55330102
     * should define first
     */
    COUNTER = 0;
    utility::InitializeLoopCounter();
    VertexSet::MAX_DEGREE = g.VertexSize();
    if (query_plan.count(config.QueryName())) {
        if (Before(config)) {
            result_2d_t result_2d;
            const utility::timepoint_t &start = utility::GetTimepoint();
            query_plan[config.QueryName()](g, result_2d);
            logger.DurationExecutionCompiled = utility::GetDuration(start);
            logger.MatchCount = After(config, result_2d);
            // need to overwrite because listing is not implemented
            logger.MatchCount = COUNTER;
            PrintCTX("DurationExecutionCompiled(s)=");
            Print(logger.DurationExecutionCompiled << " MatchCount=");
            PrintLine(logger.MatchCount);
            utility::PrintLoopCounter(true);
            return true;
        }
    } else {
        PrintLCTX("NotImplemented QueryName=" << config.QueryName());
    }
    return false;
}

} // namespace automine_csr

} // namespace compile

} // namespace csr
