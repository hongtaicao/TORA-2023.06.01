/*
 * graph.cpp
 *
 * handle labeled graph and symmetry breaking
 *
 *  Created on: 18:53 PM Sunday 2022-8-28
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <cstdlib>          // size_t
#include <fstream>
#include <string>
#include <vector>

#include "include/common.hpp"
#include "include/csr/graph.hpp"
#include "include/utility/config.hpp"
#include "include/utility/graph.hpp"
#include "include/utility/utility.hpp"

namespace csr {

// local type
typedef utility::graph::labelstr_index_t labelstr_index_t;

// local function
inline void ReadCSRData(std::ifstream &in, rid_t *&row_index, vid_t row_size,
        cid_t *&column_index, eid_t column_size) {
    row_index = new rid_t[row_size];
    column_index = new cid_t[column_size];
    in.read(reinterpret_cast<char *>(row_index), sizeof(rid_t) * row_size);
    in.read(reinterpret_cast<char *>(column_index),
            sizeof(cid_t) * column_size);
}
inline void ReadCSRSize(std::ifstream &in, vid_t &row_size,
        eid_t& column_size) {
    in.read(reinterpret_cast<char *>(&row_size), sizeof(vid_t));
    in.read(reinterpret_cast<char *>(&column_size), sizeof(eid_t));
}

void DeleteCSR(lsize_t label_size, vid_t* row_size, rid_t **row_index,
        cid_t **column_index) {
    // delete data graph
    if (label_size == 0) {
        // if nothing allocated
        return;
    }
    label_size--;
    while (label_size > 0) {
        // index_size_ is unsigned, has to use 0 to end the loop
        delete[] column_index[label_size];
        delete[] row_index[label_size];
        label_size--;
    }
    // delete the last item
    delete[] row_index[0];
    delete[] column_index[0];
    // delete the array of pointers
    delete[] row_size;
    delete[] row_index;
    delete[] column_index;
}

void ReadChunk(std::ifstream &in, lsize_t label_size, vid_t *row_size,
        rid_t **row_index, cid_t **column_index, lsize_t *qlabel_1d,
        const lsize_t qlabel_size) {
    // qlabel_1d should be sorted in ascending order
    eid_t column_size = 0;
    if (qlabel_size) {
        // read query related data, based on query label id
        lsize_t j = 0;
        for (lsize_t label_id = 0; label_id < label_size; label_id++) {
            ReadCSRSize(in, row_size[label_id], column_size);
            while ((j < qlabel_size) and (qlabel_1d[j] < label_id)) {
                j++;
            }
            if (j < qlabel_size) {
                // does not finish reading query related data
                if (qlabel_1d[j] == label_id) {
                    // query has this label id. read it
                    ReadCSRData(in, row_index[label_id], row_size[label_id],
                            column_index[label_id], column_size);
                } else {
                    // current label does not appear in query. skip reading
                    in.seekg(
                            sizeof(rid_t) * row_size[label_id]
                                    + sizeof(cid_t) * column_size,
                            std::ios_base::cur);
                }
            } else {
                // finish reading query related data
                break;
            }
        }
    } else {
        // read the entire graphs for all labels
        for (lsize_t label_id = 0; label_id < label_size; label_id++) {
            ReadCSRSize(in, row_size[label_id], column_size);
            ReadCSRData(in, row_index[label_id], row_size[label_id],
                    column_index[label_id], column_size);
        }
    }
}

// public function
void VerifyBinaryGraph(utility::Config &config) {
    std::string bin_file = config.BinaryCSR();
    if (utility::graph::HasBinaryData(bin_file, config.LabelFile())) {
        return;
    }
    PrintLCTX("create files for a binary CSR graph at:");
    PrintLCTX(bin_file);
    PrintLCTX(config.LabelFile());
    utility::graph::TextToBinary text2bin(config);
    utility::graph::edge_map_1d_t edge_map_1d;
    labelstr_index_t labelstr_index;
    vid_t max_vertex = 0;
    text2bin.ReadTextGraph(edge_map_1d, labelstr_index, max_vertex);
    /*
     * convert a graph in text (graph_file) to a binary dataset
     * create data_file and label_file if any is missing
     * create CSR for each label id, label id in range [0, label_size)
     *
     * binary data format
     * vertex_size
     * max_degree
     * label_size
     * row index size [0]
     * column index size
     * row index data [0]
     * column index data [0]
     * row index size [1]
     * column index size
     * row index data [1]
     * column index data [1]
     * ...
     * row index size [label size - 1]
     * column index size
     * row index data [label size - 1]
     * column index data [label size - 1]
     */
    text2bin.WriteBinHeader(bin_file, edge_map_1d, labelstr_index, max_vertex);
    rid_t **row_index = new rid_t*[labelstr_index.size()];
    cid_t **column_index = new cid_t*[labelstr_index.size()];
    /*
     * row size is the length of row_index for a specific label
     * use row_size per vertex label can save memory a bit
     * max_vertex + 1 is the vertex count
     * use the overall max_vertex + 2 can avoid range check
     */
    vid_t r_size = text2bin.vertex_size + 1;
    for (size_t i = 0; i < labelstr_index.size(); i++) {
        row_index[i] = new rid_t[r_size];
        auto &e_map = edge_map_1d[i];
        // collect the number of edges
        eid_t c_size = 0;
        for (auto it = e_map.begin(); it != e_map.end(); it++) {
            c_size += it->second.size();
        }
        column_index[i] = new cid_t[c_size];
        // collect neighbor for each vertex
        c_size = 0;
        vid_t v = 0;
        for (; v < text2bin.vertex_size; v++) {
            row_index[i][v] = c_size;
            if (e_map.count(v)) {
                std::vector<vid_t> n_1d(e_map[v].begin(), e_map[v].end());
                std::sort(n_1d.begin(), n_1d.end());
                for (auto neighbor : n_1d) {
                    column_index[i][c_size] = neighbor;
                    c_size++;
                }
            }
        }
        row_index[i][v] = c_size;
        // binary data format
        text2bin.out.write(reinterpret_cast<char *>(&r_size), sizeof(vid_t));
        text2bin.out.write(reinterpret_cast<char *>(&c_size), sizeof(eid_t));
        text2bin.out.write(reinterpret_cast<char *>(row_index[i]),
                sizeof(rid_t) * (r_size));
        text2bin.out.write(reinterpret_cast<char *>(column_index[i]),
                sizeof(cid_t) * (c_size));
    }
    text2bin.out.close();
    DeleteCSR(labelstr_index.size(), 0, row_index, column_index);
}

// public method
void Graph::WriteText(const std::string &label_file,
        const std::string &out_file) const {
    // test purpose
    utility::graph::BinaryToText bin2text(label_file, out_file);
    // convert and save data into bin2text
    for (lsize_t idx = 0; idx < this->label_size_; idx++) {
        auto row = this->row_index_[idx];
        auto column = this->column_index_[idx];
        for (vid_t src = 0; src < this->row_size_[idx]; src++) {
            for (eid_t e_id = row[src]; e_id < row[src + 1]; e_id++) {
                vid_t dst = column[e_id];
                utility::graph::InsertEdge(src, dst, bin2text.edge_map);
                bin2text.edge_to_label_id[ToString2(src, dst)] = idx;
            }
        }
    }
    // finally write
    bin2text.WriteTextGraph();
}

Graph::Graph(utility::Config &config)
        : optim::Graph(config.BinaryCSR(), config.LabelFile()) {
    // continue to read storage specific binary data
    this->row_size_ = new vid_t[this->label_size_];
    this->row_index_ = new rid_t*[this->label_size_];
    this->column_index_ = new cid_t*[this->label_size_];
    ReadChunk(this->in_, this->label_size_, this->row_size_, this->row_index_,
            this->column_index_, 0, 0);
    /*
     * row_size[row_id] is the size of row_index[row_id]
     * however, when scanning row_index[row_id]
     * we should stop at row_size[row_id] - 1
     */
    for (lsize_t label_id = 0; label_id < this->label_size_; label_id++) {
        if (this->row_size_[label_id] > 0) {
            this->row_size_[label_id]--;
        }
    }
    this->in_.close();
}

Graph::~Graph() {
    DeleteCSR(this->label_size_, this->row_size_, this->row_index_,
            this->column_index_);
}

} // namespace graph
