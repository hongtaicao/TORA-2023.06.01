/*
 * isubgraph.cpp
 *
 * perform induced subgraph matching
 *
 *  Created on: 1:39 AM Sunday 2022-8-28
 *      Author: Hongtai Cao
 */

#include <cstdlib>          // size_t
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include "include/abstract/execution.hpp"
#include "include/abstract/expression.hpp"
#include "include/abstract/operand.hpp"
#include "include/common.hpp"
#include "include/csr/compile/automine_csr.hpp"
#include "include/csr/compile/singledirected_csr.hpp"
#include "include/csr/graph.hpp"
#include "include/optim/expression.hpp"
#include "include/optim/operand.hpp"
#include "include/optim/topdown/optimizer.hpp"
#include "include/sorttrie/compile/adhoc.hpp"
#include "include/sorttrie/compile/automine_sharetrie.hpp"
#include "include/sorttrie/compile/automine_wcoj.hpp"
#include "include/sorttrie/executejoin.hpp"
#include "include/sorttrie/executeunary.hpp"
#include "include/sorttrie/graph.hpp"
#include "include/sorttrie/node.hpp"
#include "include/utility/clock.hpp"
#include "include/utility/config.hpp"
#include "include/utility/graph.hpp"
#include "include/utility/logger.hpp"
#include "include/utility/utility.hpp"

namespace csr {

void main(utility::Config &config, utility::Logger &logger) {
    csr::VerifyBinaryGraph(config);
    const utility::timepoint_t &start = utility::GetTimepoint();
    csr::Graph graph(config);
    logger.DurationReadBinaryGraph = utility::GetDuration(start);
    PrintLCTX("DurationReadBinaryGraph(s)=" << logger.DurationReadBinaryGraph);
    // graph.WriteText(c.LabelFile(), "data.csr.txt");
    if (config.AutoMineCSR()) {
        compile::automine_csr::ExecuteByQueryName(config, graph, logger);
    } else if (config.SingleDirectedCSR()) {
        compile::singledirected_csr::ExecuteByQueryName(config, graph, logger);
    } else {
        PrintLCTX("csr unknown algorithm [" << config.Algorithm() << "]");
        SystemExit(-1);
    }
}

} // namespace csr

namespace sorttrie {

typedef abstract::Operand Operand;
typedef std::unordered_map<Operand *, Node *> operand_to_node_t;

#ifdef NDEBUG
#define DebugIntermediateResult(x, y, z)                        (void(0))
#else
void DebugIntermediateResult(size_t ith, operand_to_node_t &cache,
        abstract::Expression *expr) {
    if (ith) {
        auto size = cache[expr->output]->CountLeaf();
        DPrintCTX("abstract::Expression=" << expr);
        DPrintLine(" intermediate result size=" << size);
        expr->output->DebugPrint(true);
        if (size < 100) {
            cache[expr->output]->DebugPrint(true);
        }
    } else {
#ifdef MEMORY
        auto size = cache[expr->output]->CountLeaf();
        DPrintCTX("abstract::Expression=" << expr);
        DPrintLine(" final result size=" << size);
        expr->output->DebugPrint(true);
        if (size < 100) {
            cache[expr->output]->DebugPrint(true);
        }
#endif
    }
}
#endif

#ifdef MEMORY
inline void DumpMemoryToFile(utility::Config &config, utility::Logger &logger,
        const abstract::Execution &execution, operand_to_node_t &cache) {
    if (cache.count(execution.output)) {
        // edge match
        logger.MatchCount = cache[execution.output]->CountLeaf();
        // can optional choose to save file
        cache[execution.output]->SaveAsTable(config.SaveFile());
    } else {
        // edge mismatch
        logger.MatchCount = 0;
        // can optional choose to save file
        Node node(0);
        node.SaveAsTable(config.SaveFile());
    }
}
#else
#define DumpMemoryToFile(a, b, c, d)                            (void(0))
#endif

void ExecuteDynamic(utility::Config &, utility::Logger &, const Graph &,
        abstract::Execution &, operand_to_node_t &);
Node *GetInput(Operand *, operand_to_node_t &, const Graph &);

void main(utility::Config &config, utility::Logger &logger) {
    sorttrie::VerifyBinaryGraph(config);
    const utility::timepoint_t &start = utility::GetTimepoint();
    Graph graph(config);
    logger.DurationReadBinaryGraph = utility::GetDuration(start);
    PrintLCTX("DurationReadBinaryGraph(s)=" << logger.DurationReadBinaryGraph);
    // graph.WriteText(c.LabelFile(), "data.sorttrie.txt");
    if (config.AutoMineWCOJ()) {
        compile::automine_wcoj::ExecuteByQueryName(config, graph, logger);
    } else if (config.AutoMineShareTrie()) {
        compile::automine_sharetrie::ExecuteByQueryName(config, graph, logger);
    } else if (config.AdhocSorttrie()) {
        compile::adhoc::ExecuteByQueryName(config, graph, logger);
    } else if (config.TopDown()) {
        // run optimization and execution
        if (config.EstimateCost()) {
        }
        // check condition
        if (utility::IsFile(config.QueryFile())) {
            optim::topdown::Optimizer optimizer(config, logger, graph);
            optim::Expression *expr = optimizer.BuildOneExpression();
            PrintCTX("DurationBuildOne(s)=");
            Print(logger.DurationBuildOne);
            Print(" DurationSymbreakOne(s)=");
            PrintLine(logger.DurationSymbreakOne);
            PrintCTX("AutomorphismCount=" << logger.AutomorphismCount);
            Print(" MatchVertex=" << logger.MatchVertex);
            Print(" SymbreakCount=" << logger.SymbreakCount);
            PrintLine(" SymbreakScore=" << logger.SymbreakScore);
            /* AutomorphismCount: the number of Query Symmetry
             * SymbreakCount: the number of symmetry breaking rules
             * SymbreakScore: the score of the best rule
             * expected to be greater than 0
             * if SymbreakScore=-1: no symbreak rule is applied
             */
            abstract::Execution execution;
            optim::topdown::BuildExecution(optimizer, expr, execution);
            operand_to_node_t cache;
            if (config.ExecuteCompiled()) {
                PrintCTX("DurationExecutionCompiled(s)=");
                Print(logger.DurationExecutionCompiled);
            } else if (config.ExecuteDynamic()) {
                ExecuteDynamic(config, logger, graph, execution, cache);
                PrintCTX("DurationExecutionDynamic(s)=");
                Print(logger.DurationExecutionDynamic);
            }
            PrintLine(" MatchCount=" << logger.MatchCount);
            // output function name into a separate file
            utility::MkFileDir(utility::Config::FUNCTION_FILE);
            std::ofstream output(utility::Config::FUNCTION_FILE, std::ios::app);
            output << "=== " << config.DateTime() << " ===" << std::endl;
            output << "data: " << config.DataFile() << std::endl;
            output << "query: " << config.QueryFile() << std::endl;
            output << "query name: " << config.QueryName() << std::endl;
            for (auto &expression : execution.expression_1d) {
                output << expression->FunctionName() << std::endl;
            }
            DumpMemoryToFile(config, logger, execution, cache);
            // clean up
            node_set_t node_set;
            for (auto &pair : cache) {
                if (not node_set.count(pair.second)) {
                    node_set.insert(pair.second);
                    delete pair.second;
                }
            }
        } else {
            PrintLCTX("sorttrie optimization requires a query file");
            PrintLCTX("query not exist [" << config.QueryFile() << "]");
        }
    } else {
        PrintLCTX("sorttrie unknown algorithm [" << config.Algorithm() << "]");
        SystemExit(-1);
    }
}

void ExecuteDynamic(utility::Config &config, utility::Logger &logger,
        const Graph &graph, abstract::Execution &execution,
        operand_to_node_t &cache) {
    const utility::timepoint_t &start = utility::GetTimepoint();
    for (int ith = execution.expression_1d.size() - 1; ith > -1; ith--) {
        // execution order starts from the end
        auto expr = execution.expression_1d[ith];
        DPrintLCTX("execute abstract::Expression=" << expr);
        if (expr->IsJoin()) {
            node_1d_t input_1d;
            node_set_t nonedge_set;                     // mark negation
            for (auto in_op : expr->input_1d) {
                Node *in_node = GetInput(in_op, cache, graph);
                input_1d.push_back(in_node);
                DPrintCTX("input ");
                in_node->DebugPrint(true);
                if (in_op->IsNonedge()) {
                    nonedge_set.insert(in_node);
                }
            }
            auto exe_join = ExecuteJoin(expr, input_1d, nonedge_set,
                    graph.VertexSize());
            if (ith) {
                cache[expr->output] = exe_join.Result();
                if (config.SaveIntermediateFile().size()) {
                    cache[expr->output]->SaveAsTable(
                            config.SaveIntermediateFile(expr->output));
                }
            } else {
                /* the last Expression to execute
                 * per each result: count, write to file, save to memory
                 */
                cache[expr->output] = exe_join.Result(config.SaveFile(),
                        logger.MatchCount);
            }
        } else {
            // this must be Rename or Transpose
            auto exe_unary = ExecuteUnary(expr,
                    GetInput(expr->input_1d[0], cache, graph),
                    graph.VertexSize());
            cache[expr->output] = exe_unary.Result();
        }
        DebugIntermediateResult(ith, cache, expr);
    }
    logger.DurationExecutionDynamic = utility::GetDuration(start);
}

Node *GetInput(Operand *in_op, operand_to_node_t &cache, const Graph &graph) {
    if (in_op->IsNonedge()) {
        // this must be non-edge
        if (not cache.count(in_op)) {
            // such that it can be released
            node_1d_t node_1d;
            for (auto edge_index : in_op->edge_index) {
                node_1d.push_back(graph.Edge(edge_index));
            }
            auto *non_edge = new Node(node_1d, graph.VertexSize());
            cache[in_op] = non_edge;
        }
        return cache[in_op];
    } else if (in_op->edge_index.size()) {
        // this can be edge/non-edge, non-edge is examined first
        return graph.Edge(in_op->edge_index[0]);
    }
    // then must be materialized
    return cache[in_op];
}

} // namespace sorttrie

int main(int argc, char *argv[]) {
    utility::Config config = utility::Config(argc, argv);
    utility::Logger logger;
    if (config.SampleInducedSubgraph()) {
        utility::graph::SampleInducedSubgraph(config);
    }
    if (config.CSR()) {
        csr::main(config, logger);
    } else if (config.SortTrie()) {
        sorttrie::main(config, logger);
    } else {
        PrintLCTX("unknown GraphStorage [" << config.GraphStorage() << "]");
        SystemExit(-1);
    }
    config.SaveToFile(logger);
    PrintLCTX("stop command line at " << utility::GetCurrentTime());
    return 0;
}
