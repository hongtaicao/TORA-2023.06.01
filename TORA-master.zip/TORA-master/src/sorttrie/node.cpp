/*
 * node.cpp
 *
 *  Created on: 16:47 Saturday 2022-9-10
 *      Author: Hongtai Cao
 */

#include <fstream>
#include <iostream>
#include <vector>

#include "include/common.hpp"
#include "include/sorttrie/iterator.hpp"
#include "include/sorttrie/node.hpp"
#include "include/utility/utility.hpp"

namespace sorttrie {

// local type
typedef bool (iterate_inner_t)(vid_t *, vid_t, void *);
/* define a function type: iterate_inner_t
 * return: bool
 * argument: vid_t *, void *
 *
 * equivalent to
 * using iterate_inner_t = bool (*)(vid_t *, void *);
 */

// local function
vid_t IterateTrie(const Node *root, iterate_inner_t iterate_f, void *in) {
    /* calling function should do the following check
     * this function is not time critical
     *
     * if ((root == nullptr) or (not root->HasChild())) {
     *     return 0;
     * }
     */
    iterator_1d_t iter_1d;
    for (const Node *ptr = root; ptr->HasChild(); ptr = ptr->Child(0)) {
        iter_1d.push_back(new Iterator(ptr));
    }
    vid_t depth = iter_1d.size();
    vid_t buffer[depth], ptr = 0;
    for (auto it : iter_1d) {
        buffer[ptr++] = it->Value();
    }
    ptr--; // point to the last element
    while (iter_1d.size() == depth) {
        for (auto it = iter_1d.back(); it->InRange(); it->Next()) {
            vid_t *tuple = new vid_t[depth];
            std::copy(buffer, buffer + ptr, tuple);
            tuple[ptr] = it->Value();
            if (iterate_f(tuple, depth, in)) {
                delete tuple;
            }
        }
        delete iter_1d.back();
        iter_1d.pop_back();
        ptr--;
        if (iter_1d.empty()) {
            return depth;
        }
        // move to next Node and ensure it has value
        // otherwise backtrack to upper levels
        iter_1d.back()->Next();
        for (; not iter_1d.back()->InRange(); iter_1d.back()->Next()) {
            delete iter_1d.back();
            iter_1d.pop_back();
            ptr--;
            if (iter_1d.empty()) {
                return depth;
            }
        }
        // insert back Iterator over children
        while (iter_1d.back()->GetNode()->HasChild()) {
            buffer[ptr++] = iter_1d.back()->Value();
            iter_1d.push_back(new Iterator(iter_1d.back()->GetNode()));
        }
    }
    return depth;
}

bool SaveAsTableInner(vid_t *tuple, vid_t size, void *out_ptr) {
    // should delete tuple
    std::ofstream *out = (std::ofstream *) out_ptr;
    vid_t i = 0;
    if (i < size) {
        (*out) << tuple[0];
    }
    for (i++; i < size; i++) {
        (*out) << " " << tuple[i];
    }
    (*out) << std::endl;
    return true;
}

inline bool ToTableInner(vid_t *tuple, vid_t, void *in) {
    table_t *result = (table_t *) in;
    result->push_back(tuple);
    return false;
}

// public function used in ExecuteJoin, ExecuteUnary
void InitializeNode1d(int size, node_1d_t &node_1d, const vid_t node_size) {
    /* the first node is final result and others are intermediate results
     * used in Rename and Transpose
     */
    while (size > 0) {
        node_1d.push_back(new Node(node_size));
        size--;
    }
}

// method
uint64_t Node::CountLeaf() {
    // this count leaf node at the same depth
    if (not this->HasChild()) {
        return 0;
    }
    uint64_t count = 0;
    iterator_1d_t iter_1d;
    for (Node *ptr = this; ptr->HasChild(); ptr = ptr->Child(0)) {
        iter_1d.push_back(new Iterator(ptr));
    }
    size_type depth = iter_1d.size();
    if (depth == 0) {
        return 0;
    }
    while (iter_1d.size() == depth) {
        count += iter_1d.back()->Size();
        delete iter_1d.back();
        iter_1d.pop_back();
        if (iter_1d.empty()) {
            return count;
        }
        // move to next Node and ensure it has value
        // otherwise backtrack to upper levels
        iter_1d.back()->Next();
        for (; not iter_1d.back()->InRange(); iter_1d.back()->Next()) {
            delete iter_1d.back();
            iter_1d.pop_back();
            if (iter_1d.empty()) {
                return count;
            }
        }
        // insert back Iterator over children
        while (iter_1d.back()->GetNode()->HasChild()) {
            iter_1d.push_back(new Iterator(iter_1d.back()->GetNode()));
        }
    }
    return count;
}

#ifndef NDEBUG
void Node::DebugPrint(bool) const {
    table_t result;
    vid_t width = this->ToTable(result);
    DPrint("Node=" << this << " as table shape=(" << result.size() << ",");
    DPrintLine(width << ")");
    for (auto tuple : result) {
        DPrint("(");
        DPrintArray(tuple, width);
        DPrintLine(")");
        delete[] tuple;
    }
}
#endif

size_t Node::Depth() const {
    size_t depth = 0;
    for (auto ptr = this; ptr->HasChild(); ptr = ptr->Child(0)) {
        depth++;
    }
    return depth;
}

vid_t Node::SaveAsTable(const std::string &out_file) {
    // this count leaf node at the same depth
    std::ofstream out;
    if (out_file.size()) {
        utility::MkFileDir(out_file);
        out.open(out_file, std::ios::out);
        PrintLCTX("write relation to file: "<< out_file);
    }
    if (not this->HasChild()) {
        return 0;
    }
    return IterateTrie(this, SaveAsTableInner, &out);
}

vid_t Node::ToTable(table_t &result) const {
    // this count leaf node at the same depth
    if (not this->HasChild()) {
        return 0;
    }
    return IterateTrie(this, ToTableInner, &result);
}

Node::Node(const std::vector<Node *> &edge_1d, vid_t vertex_count)
        : data_(new Node*[vertex_count]), size_(vertex_count), value_(0) {
    // create Node for non-edge
    typename Iterator::iterator_min_heap_t pool;
    vid_t *leaf_1d = new vid_t[vertex_count];
    vid_t size = 0;
    for (auto node : edge_1d) {
        pool.push(new Iterator(node));
    }
    for (vid_t v = 0; v < vertex_count; v++) {
        while ((not pool.empty()) and (v == pool.top()->Value())) {
            /* collect all node
             * leaf_1d collects neighbors of a certain node
             * the same vertex pair can appear as an edge in at most one node
             * therefore leaf_1d is guaranteed to contain distinct values
             */
            Iterator *top = pool.top();
            Node *node = top->GetNode();
            for (vid_t j = 0; j < node->size_; j++) {
                leaf_1d[size++] = node->data_[j]->value_;
            }
            pool.pop();
            top->Next();
            if (top->InRange()) {
                pool.push(top);
            } else {
                delete top;
            }
        }
        if (size > 0) {
            // has multiple children
            // add self loop
            leaf_1d[size++] = v;
            Node *root = new Node(v, 0, new Node*[size]);
            std::sort(leaf_1d, leaf_1d + size);
            for (vid_t j = 0; j < size; j++) {
                root->Append(leaf_1d[j]);
            }
            this->data_[v] = root;
            size = 0;
        } else {
            // add only self loop
            Node *root = new Node(v, 0, new Node*[1]);
            root->Append(v);
            this->data_[v] = root;
        }
    }
    delete[] leaf_1d;
}

}
