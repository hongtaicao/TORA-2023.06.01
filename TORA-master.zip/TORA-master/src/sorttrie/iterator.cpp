/*
 * iterator.cpp
 *
 *  Created on: 1:36 AM Friday 2022-9-9
 *      Author: Hongtai Cao
 */

#include "include/sorttrie/iterator.hpp"
#include "include/sorttrie/node.hpp"

namespace sorttrie {

#if defined(SORTTRIE_LINEAR_SEARCH) and !defined(SORTTRIE_MIX_SEARCH)
// under linear mode, always linear search
#define LinearSearch(a, b)      true
#elif !defined(SORTTRIE_LINEAR_SEARCH) and defined(SORTTRIE_MIX_SEARCH)
// under mixed mode, do linear search when the range is small
#define LinearSearch(a, b)      ((b - a) < 64)
#else
#define LinearSearch(a, b)      false
#endif

#ifndef NDEBUG
void DPrintIterator(Iterator **iterator_1d, vid_t size) {
    for (size_type ith = 0; ith < size; ith++) {
        DPrint("[" << ith << "] ");
        iterator_1d[ith]->DebugPrint(true);
    }
}

void Iterator::DebugPrint(bool) const {
    DPrint("Iterator=" << this << " size=" << this->Size() << " :");
    size_type counter = 0;
    for (auto ptr = this->ptr_; ptr < this->end_; ptr++) {
        DPrint(" " << (*ptr)->Value());
        counter++;
        if (counter == DPRINT_LIMIT) {
            break;
        }
    }
    if (counter == DPRINT_LIMIT) {
        DPrint(" ... (truncated)");
    }
    DPrintLine("");
}
#endif

Iterator *Iterator::Greater(const value_t value) {
    /* adjust this->ptr_
     * can point to a greater value or out of range (this->end_)
     */
    if (LinearSearch(this->ptr_, this->end_)) {
        while (this->ptr_ < this->end_) {
            if ((*(this->ptr_))->Value() <= value) {
                this->ptr_++;
            } else {
                return this;
            }
        }
        return this;
    }
    pointer_t end = this->end_;
    while (this->ptr_ < end) {
        pointer_t mid = this->ptr_ + (end - this->ptr_) / 2;
        if ((*mid)->Value() <= value) {
            this->ptr_ = mid + 1;
        } else {
            end = mid;
        }
    }
    return this;
}

Iterator *Iterator::GreaterEqual(const value_t value) {
    /* adjust this->ptr_
     * can point to an equal or greater value, or out of range (this->end_)
     * if there are multiple equal values, point to the first one
     */
    if (LinearSearch(this->ptr_, this->end_)) {
        while (this->ptr_ < this->end_) {
            if ((*(this->ptr_))->Value() < value) {
                this->ptr_++;
            } else {
                return this;
            }
        }
        return this;
    }
    pointer_t end = this->end_;
    while (this->ptr_ < end) {
        pointer_t mid = this->ptr_ + (end - this->ptr_) / 2;
        if ((*mid)->Value() < value) {
            this->ptr_ = mid + 1;
        } else {
            end = mid;
        }
    }
    return this;
}

Iterator *Iterator::Less(const value_t value) {
    /* adjust this->end_
     * can point to either up, the first value > up, or this->ptr_
     */
    pointer_t head = this->ptr_;
    if (LinearSearch(this->ptr_, this->end_)) {
        while (head < this->end_) {
            if ((*(head))->Value() < value) {
                head++;
            } else {
                this->end_ = head;
                return this;
            }
        }
        this->end_ = head;
        return this;
    }
    while (head < this->end_) {
        pointer_t mid = head + (this->end_ - head) / 2;
        if ((*mid)->Value() < value) {
            head = mid + 1;
        } else {
            this->end_ = mid;
        }
    }
    // the first value >= up is head
    this->end_ = head;
    return this;
}

}
