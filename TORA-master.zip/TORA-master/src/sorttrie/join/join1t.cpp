/*
 * join1t.cpp
 *
 *  Created on: 3:27 AM Friday 2023-3-3
 *      Author: Hongtai Cao
 */

#include "include/sorttrie/join/join1t.hpp"

namespace sorttrie {

namespace join {

void Join1T::Negate() {
    // joined value cannot be in the negation leaf level
    while (this->InRange()
            and (this->iter1_a_->Match(this->Value())
                    or this->iter1_b_->Match(this->Value()))) {
        // join on a negation value
        Join::Next();
    }
}

} // namespace join

} // namespace sorttrie
