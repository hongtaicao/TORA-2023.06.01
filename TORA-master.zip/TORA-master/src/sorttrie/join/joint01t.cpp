/*
 * joint01t.cpp
 *
 *  Created on: 2:44 AM Friday 2023-3-3
 *      Author: Hongtai Cao
 */

#include "include/sorttrie/join/joint01t.hpp"

namespace sorttrie {

namespace join {

JoinT01T::~JoinT01T() {
    for (size_type i = 0; i < this->size0_; i++) {
        delete this->iterator0_[i];
    }
}

} // namespace join

} // namespace sorttrie
