/*
 * joint0.cpp
 *
 *  Created on: 22:46 PM Thursday 2023-3-2
 *      Author: Hongtai Cao
 */

#include "include/sorttrie/join/joint0.hpp"

namespace sorttrie {

namespace join {

JoinT0::~JoinT0() {
    for (size_type i = 0; i < this->size0_; i++) {
        delete this->iterator0_[i];
    }
}

} // namespace join

} // namespace sorttrie
