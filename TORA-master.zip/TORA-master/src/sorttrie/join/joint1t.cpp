/*
 * joint1t.cpp
 *
 *  Created on: 2:28 AM Friday 2023-3-3
 *      Author: Hongtai Cao
 */

#include "include/sorttrie/join/joint1t.hpp"

namespace sorttrie {

namespace join {

void JoinT1T::Negate() {
    // joined value cannot be in the negation leaf level
    while (this->InRange()
            and (this->iter1_a_->Match(this->Value())
                    or this->iter1_b_->Match(this->Value()))) {
        // join on a negation value
        JoinT::Next();
    }
}

} // namespace join

} // namespace sorttrie
