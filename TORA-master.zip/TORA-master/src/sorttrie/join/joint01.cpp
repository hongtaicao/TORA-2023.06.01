/*
 * joint01.cpp
 *
 *  Created on: 2:30 AM Friday 2023-3-3
 *      Author: Hongtai Cao
 */

#include "include/sorttrie/join/joint01.hpp"

namespace sorttrie {

namespace join {

JoinT01::~JoinT01() {
    for (size_type i = 0; i < this->size0_; i++) {
        delete this->iterator0_[i];
    }
}

} // namespace join

} // namespace sorttrie
