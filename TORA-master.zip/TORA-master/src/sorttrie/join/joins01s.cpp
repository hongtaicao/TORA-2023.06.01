/*
 * joins01s.cpp
 *
 *  Created on: 16:41 PM Thursday 2023-3-2
 *      Author: Hongtai Cao
 */

#include "include/sorttrie/join/joins01s.hpp"

namespace sorttrie {

namespace join {

JoinS01S::~JoinS01S() {
    for (size_type i = 0; i < this->size0_; i++) {
        delete this->iterator0_[i];
    }
}

} // namespace join

} // namespace sorttrie
