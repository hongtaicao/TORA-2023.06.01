/*
 * joins01t.cpp
 *
 *  Created on: 16:45 PM Thursday 2023-3-2
 *      Author: Hongtai Cao
 */

#include "include/sorttrie/join/joins01t.hpp"

namespace sorttrie {

namespace join {

JoinS01T::~JoinS01T() {
    for (size_type i = 0; i < this->size0_; i++) {
        delete this->iterator0_[i];
    }
}

} // namespace join

} // namespace sorttrie
