/*
 * join1s.cpp
 *
 *  Created on: 3:25 AM Friday 2023-3-3
 *      Author: Hongtai Cao
 */

#include "include/sorttrie/join/join1s.hpp"

namespace sorttrie {

namespace join {

void Join1S::Negate() {
    // joined value cannot be in the negation leaf level
    while (this->InRange() and this->iterator1_->Match(this->Value())) {
        // join on a negation value and therefore try Next() value
        Join::Next();
    }
}

} // namespace join

} // namespace sorttrie
