/*
 * join01s.cpp
 *
 *  Created on: 3:32 AM Friday 2023-3-3
 *      Author: Hongtai Cao
 */

#include "include/sorttrie/join/join01s.hpp"

namespace sorttrie {

namespace join {

Join01S::~Join01S() {
    for (size_type i = 0; i < this->size0_; i++) {
        delete this->iterator0_[i];
    }
}

} // namespace join

} // namespace sorttrie
