/*
 * join01.cpp
 *
 *  Created on: 3:21 AM Wednesday 2022-9-14
 *      Author: Hongtai Cao
 */

#include "include/sorttrie/join/join01.hpp"

namespace sorttrie {

namespace join {

Join01::~Join01() {
    for (size_type i = 0; i < this->size0_; i++) {
        delete this->iterator0_[i];
    }
}

} // namespace join

} // namespace sorttrie
