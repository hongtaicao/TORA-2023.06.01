/*
 * joins0.cpp
 *
 *  Created on: 12:52 PM Thursday 2023-3-2
 *      Author: Hongtai Cao
 */

#include "include/sorttrie/join/joins0.hpp"

namespace sorttrie {

namespace join {

JoinS0::~JoinS0() {
    for (size_type i = 0; i < this->size0_; i++) {
        delete this->iterator0_[i];
    }
}

} // namespace join

} // namespace sorttrie
