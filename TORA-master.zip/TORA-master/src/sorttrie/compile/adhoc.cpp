/*
 * adhoc.cpp
 *
 *  Created on: 1:02 AM Sunday 2022-9-11
 *      Author: Hongtai Cao
 */

#include <cstdint>
#include <string>
#include <vector>

#include "include/common.hpp"
#include "include/sorttrie/compile/adhoc.hpp"
#include "include/sorttrie/compile/adhoc_expression.hpp"
#include "include/sorttrie/graph.hpp"
#include "include/sorttrie/node.hpp"
#include "include/utility/clock.hpp"
#include "include/utility/config.hpp"
#include "include/utility/logger.hpp"
#include "include/utility/utility.hpp"

namespace sorttrie {

namespace compile {

namespace adhoc {

// static declare and define (initialize). visible only in current file.
// local global variable
static vid_t MAX_DEGREE;
static vid_t VERTEX_SIZE;

typedef utility::timepoint_t timepoint_t;

// graph matching function
// these are used to compare materializing clique time / space cost
Node *Clique3Count(const Graph &graph) {
    // compute 3-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 3; i++) {
        in.push_back(graph.Edge(0));
    }
    CountQuery(in, "3-clique", "c_abc_ab_ac_bc__ab_bc");
    return nullptr;
}

Node *Clique3Match(const Graph &graph) {
    // compute 3-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 3; i++) {
        in.push_back(graph.Edge(0));
    }
    return MatchQuery(in, "3-clique", "abc_ab_ac_bc__ab_bc");
}

Node *Clique4Count(const Graph &graph) {
    // compute 4-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 6; i++) {
        in.push_back(graph.Edge(0));
    }
    CountQuery(in, "4-clique", "c_abcd_ab_ac_ad_bc_bd_cd__ab_bc_cd");
    return nullptr;
}

Node *Clique4Match(const Graph &graph) {
    // compute 4-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 6; i++) {
        in.push_back(graph.Edge(0));
    }
    return MatchQuery(in, "4-clique", "abcd_ab_ac_ad_bc_bd_cd__ab_bc_cd");
}

Node *Clique5Count(const Graph &graph) {
    // compute 5-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 10; i++) {
        in.push_back(graph.Edge(0));
    }
    CountQuery(in, "5-clique",
            "c_abcde_ab_ac_ad_ae_bc_bd_be_cd_ce_de__ab_bc_cd_de");
    return nullptr;
}

Node *Clique5Match(const Graph &graph) {
    // compute 5-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 10; i++) {
        in.push_back(graph.Edge(0));
    }
    return MatchQuery(in, "5-clique",
            "abcde_ab_ac_ad_ae_bc_bd_be_cd_ce_de__ab_bc_cd_de");
}

Node *Clique6Count(const Graph &graph) {
    // compute 5-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 15; i++) {
        in.push_back(graph.Edge(0));
    }
    CountQuery(in, "6-clique",
            "c_abcdef_ab_ac_ad_ae_af_bc_bd_be_bf_cd_ce_cf_de_df_ef__ab_bc_cd_de_ef");
    return nullptr;
}

Node *Clique6Match(const Graph &graph) {
    // compute 5-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 15; i++) {
        in.push_back(graph.Edge(0));
    }
    return MatchQuery(in, "6-clique",
            "abcdef_ab_ac_ad_ae_af_bc_bd_be_bf_cd_ce_cf_de_df_ef__ab_bc_cd_de_ef");
}

Node *Clique7Count(const Graph &graph) {
    // compute 5-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 21; i++) {
        in.push_back(graph.Edge(0));
    }
    CountQuery(in, "7-clique",
            "c_abcdefg_ab_ac_ad_ae_af_ag_bc_bd_be_bf_bg_cd_ce_cf_cg_de_df_dg_ef_eg_fg__ab_bc_cd_de_ef_fg");
    return nullptr;
}

Node *Clique7Match(const Graph &graph) {
    // compute 5-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 21; i++) {
        in.push_back(graph.Edge(0));
    }
    return MatchQuery(in, "7-clique",
            "abcdefg_ab_ac_ad_ae_af_ag_bc_bd_be_bf_bg_cd_ce_cf_cg_de_df_dg_ef_eg_fg__ab_bc_cd_de_ef_fg");
}

Node *Clique8Count(const Graph &graph) {
    // compute 5-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 28; i++) {
        in.push_back(graph.Edge(0));
    }
    CountQuery(in, "8-clique",
            "c_abcdefgh_ab_ac_ad_ae_af_ag_ah_bc_bd_be_bf_bg_bh_cd_ce_cf_cg_ch_de_df_dg_dh_ef_eg_eh_fg_fh_gh__ab_bc_cd_de_ef_fg_gh");
    return nullptr;
}

Node *Clique8Match(const Graph &graph) {
    // compute 5-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 28; i++) {
        in.push_back(graph.Edge(0));
    }
    return MatchQuery(in, "8-clique",
            "abcdefgh_ab_ac_ad_ae_af_ag_ah_bc_bd_be_bf_bg_bh_cd_ce_cf_cg_ch_de_df_dg_dh_ef_eg_eh_fg_fh_gh__ab_bc_cd_de_ef_fg_gh");
}

Node *Clique9Count(const Graph &graph) {
    // compute 5-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 36; i++) {
        in.push_back(graph.Edge(0));
    }
    CountQuery(in, "9-clique",
            "c_abcdefghi_ab_ac_ad_ae_af_ag_ah_ai_bc_bd_be_bf_bg_bh_bi_cd_ce_cf_cg_ch_ci_de_df_dg_dh_di_ef_eg_eh_ei_fg_fh_fi_gh_gi_hi__ab_bc_cd_de_ef_fg_gh_hi");
    return nullptr;
}

Node *Clique9Match(const Graph &graph) {
    // compute 5-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 36; i++) {
        in.push_back(graph.Edge(0));
    }
    return MatchQuery(in, "9-clique",
            "abcdefghi_ab_ac_ad_ae_af_ag_ah_ai_bc_bd_be_bf_bg_bh_bi_cd_ce_cf_cg_ch_ci_de_df_dg_dh_di_ef_eg_eh_ei_fg_fh_fi_gh_gi_hi__ab_bc_cd_de_ef_fg_gh_hi");
}

Node *Clique10Count(const Graph &graph) {
    // compute 5-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 45; i++) {
        in.push_back(graph.Edge(0));
    }
    CountQuery(in, "10-clique",
            "c_abcdefghij_ab_ac_ad_ae_af_ag_ah_ai_aj_bc_bd_be_bf_bg_bh_bi_bj_cd_ce_cf_cg_ch_ci_cj_de_df_dg_dh_di_dj_ef_eg_eh_ei_ej_fg_fh_fi_fj_gh_gi_gj_hi_hj_ij__ab_bc_cd_de_ef_fg_gh_hi_ij");
    return nullptr;
}

Node *Clique10Match(const Graph &graph) {
    // compute 5-clique using backtracking. measure time space cost
    std::vector<Node *> in;
    for (size_t i = 0; i < 45; i++) {
        in.push_back(graph.Edge(0));
    }
    return MatchQuery(in, "10-clique",
            "abcdefghij_ab_ac_ad_ae_af_ag_ah_ai_aj_bc_bd_be_bf_bg_bh_bi_bj_cd_ce_cf_cg_ch_ci_cj_de_df_dg_dh_di_dj_ef_eg_eh_ei_ej_fg_fh_fi_fj_gh_gi_gj_hi_hj_ij__ab_bc_cd_de_ef_fg_gh_hi_ij");
}

Node *CliqueMatch(const Graph &graph) {
    // measure time cost and loop count
    /* test match
     * match 3 clique by edges
     * this is the only option
     */
    node_1d_t in;
    auto *clique_3 = Clique3Match(graph);
    in.clear();
    in.push_back(clique_3);
    CountQuery(in, "3-clique", "c_0_11");
    // match 4 clique by edges
    auto *clique_4 = Clique4Match(graph);
    in.clear();
    in.push_back(clique_4);
    CountQuery(in, "4-clique", "c_0_11");
    /* match 4-clique by sharing 3-clique
     * note this uses 3-clique result
     * therefore total time should add 3-clique duration.
     */
    in.clear();
    in.push_back(clique_3);
    in.push_back(clique_3);
    in.push_back(graph.Edge(0));
    delete MatchByShare(in, "4-clique", "abcd_abc_abd_cd__cd");
    // match 5-clique by edges
    auto *clique_5 = Clique5Match(graph);
    in.clear();
    in.push_back(clique_5);
    CountQuery(in, "5-clique", "c_0_11");
    // match 5-clique by sharing 3-clique
    in.clear();
    for (size_t i = 0; i < 4; i++) {
        in.push_back(clique_3);
    }
    delete MatchByShare(in, "5-clique", "abcde_abc_abd_abe_cde");
    // match 5-clique by sharing 4-clique
    in.clear();
    in.push_back(clique_4);
    in.push_back(clique_4);
    in.push_back(graph.Edge(0));
    delete MatchByShare(in, "5-clique", "abcde_abcd_abce_de__de");
    // match 6 clique by edges
    auto *clique_6 = Clique6Match(graph);
    in.clear();
    in.push_back(clique_6);
    CountQuery(in, "6-clique", "c_0_11");
    // match 6-clique by sharing 3-clique
    in.clear();
    for (size_t i = 0; i < 7; i++) {
        in.push_back(clique_3);
    }
    /* a 6-clique has 6x5/2=15 edges, each triangle covers 3 edges
     * the min triangle cover is 15/3=5 triangles
     * the max triangle cover without identical ones is 6 choose 3 = 20
     *
     * a 5-triangle cover might not be possible
     * a cover of 6 triangles is possible
     * abc, abe, adf, bdf, cde, cef
     */
    delete MatchByShare(in, "6-clique", "abcdef_abc_abd_abe_abf_cde_cdf_def");
    // match 6-clique by sharing 4-clique
    in.clear();
    for (size_t i = 0; i < 4; i++) {
        in.push_back(clique_4);
    }
    delete MatchByShare(in, "6-clique", "abcdef_abcd_abce_abcf_cdef");
    // match 6-clique by sharing 5-clique
    in.clear();
    in.push_back(clique_5);
    in.push_back(clique_5);
    in.push_back(graph.Edge(0));
    delete MatchByShare(in, "6-clique", "abcdef_abcde_abcdf_ef__ef");
    // match 7-clique
    auto *clique_7 = Clique7Match(graph);
    in.clear();
    in.push_back(clique_7);
    CountQuery(in, "7-clique", "c_0_11");
    // match 7-clique by sharing 3-clique
    in.clear();
    for (size_t i = 0; i < 9; i++) {
        in.push_back(clique_3);
    }
    delete MatchByShare(in, "7-clique",
            "abcdefg_abc_abd_abe_abf_abg_cde_cdf_cdg_efg");
    // match 7-clique by sharing 4-clique
    in.clear();
    for (size_t i = 0; i < 5; i++) {
        in.push_back(clique_4);
    }
    delete MatchByShare(in, "7-clique", "abcdefg_abcd_abce_abcf_abcg_defg");
    // match 7-clique by sharing 5-clique
    in.clear();
    for (size_t i = 0; i < 4; i++) {
        in.push_back(clique_5);
    }
    delete MatchByShare(in, "7-clique", "abcdefg_abcde_abcdf_abcdg_cdefg");
    // match 7-clique by sharing 6-clique
    in.clear();
    in.push_back(clique_6);
    in.push_back(clique_6);
    in.push_back(graph.Edge(0));
    delete MatchByShare(in, "7-clique", "abcdefg_abcdef_abcdeg_fg__fg");
    // match 8-clique
    auto *clique_8 = Clique8Match(graph);
    in.clear();
    in.push_back(clique_8);
    CountQuery(in, "8-clique", "c_0_11");
    // match 8-clique by sharing 3-clique
    in.clear();
    for (size_t i = 0; i < 13; i++) {
        in.push_back(clique_3);
    }
    delete MatchByShare(in, "8-clique",
            "abcdefgh_abc_abd_abe_abf_abg_abh_cde_cdf_cdg_cdh_efg_efh_fgh");
    // match 8-clique by sharing 4-clique
    in.clear();
    for (size_t i = 0; i < 8; i++) {
        in.push_back(clique_4);
    }
    delete MatchByShare(in, "8-clique",
            "abcdefgh_abcd_abce_abcf_abcg_abch_defg_defh_efgh");
    // match 8-clique by sharing 5-clique
    in.clear();
    for (size_t i = 0; i < 5; i++) {
        in.push_back(clique_5);
    }
    delete MatchByShare(in, "8-clique",
            "abcdefgh_abcde_abcdf_abcdg_abcdh_defgh");
    // match 8-clique by sharing 6-clique
    in.clear();
    for (size_t i = 0; i < 4; i++) {
        in.push_back(clique_6);
    }
    delete MatchByShare(in, "8-clique", "abcdefgh_abcdef_abcdeg_abcdeh_cdefgh");
    // match 8-clique by sharing 7-clique
    in.clear();
    in.push_back(clique_7);
    in.push_back(clique_7);
    in.push_back(graph.Edge(0));
    delete MatchByShare(in, "8-clique", "abcdefgh_abcdefg_abcdefh_gh__gh");
    // match 9-clique
    auto *clique_9 = Clique9Match(graph);
    in.clear();
    in.push_back(clique_9);
    CountQuery(in, "9-clique", "c_0_11");
    // match 9-clique by sharing 3-clique
    in.clear();
    for (size_t i = 0; i < 16; i++) {
        in.push_back(clique_3);
    }
    delete MatchByShare(in, "9-clique",
            "abcdefghi_abc_abd_abe_abf_abg_abh_abi_cde_cdf_cdg_cdh_cdi_efg_efh_efi_ghi");
    // match 9-clique by sharing 4-clique
    in.clear();
    for (size_t i = 0; i < 10; i++) {
        in.push_back(clique_4);
    }
    delete MatchByShare(in, "9-clique",
            "abcdefghi_abcd_abce_abcf_abcg_abch_abci_defg_defh_defi_fghi");
    // match 9-clique by sharing 5-clique
    in.clear();
    for (size_t i = 0; i < 6; i++) {
        in.push_back(clique_5);
    }
    delete MatchByShare(in, "9-clique",
            "abcdefghi_abcde_abcdf_abcdg_abcdh_abcdi_efghi");
    // match 9-clique by sharing 6-clique
    in.clear();
    for (size_t i = 0; i < 5; i++) {
        in.push_back(clique_6);
    }
    delete MatchByShare(in, "9-clique",
            "abcdefghi_abcdef_abcdeg_abcdeh_abcdei_defghi");
    // match 9-clique by sharing 7-clique
    in.clear();
    for (size_t i = 0; i < 4; i++) {
        in.push_back(clique_7);
    }
    delete MatchByShare(in, "9-clique",
            "abcdefghi_abcdefg_abcdefh_abcdefi_cdefghi");
    // match 9-clique by sharing 8-clique
    in.clear();
    in.push_back(clique_8);
    in.push_back(clique_8);
    in.push_back(graph.Edge(0));
    delete MatchByShare(in, "9-clique", "abcdefghi_abcdefgh_abcdefgi_hi__hi");
    // match 10-clique
    auto *clique_10 = Clique10Match(graph);
    in.clear();
    in.push_back(clique_10);
    CountQuery(in, "10-clique", "c_0_11");
    // match 10-clique by sharing 3-clique
    /* a 10-clique has 10x9/2=45 edges, the min possible triangle cover is 15
     *
     * a cover of 17 triangles is possible
     * abc, ade, afg, ahi, acj
     * bdf, beg, bei, bhj
     * cdg, ceh, cfi
     * dfh, dij
     * efj, egj
     * ghi
     */
    in.clear();
    for (size_t i = 0; i < 21; i++) {
        in.push_back(clique_3);
    }
    delete MatchByShare(in, "10-clique",
            "abcdefghij_abc_abd_abe_abf_abg_abh_abi_abj_cde_cdf_cdg_cdh_cdi_cdj_efg_efh_efi_efj_ghi_ghj_hij");
    // match 10-clique by sharing 4-clique
    /* a 10-clique has 10x9/2=45 edges, the min possible 4-clique cover is
     * 45/6=8
     *
     * a cover of 9 4-cliques is possible
     * abcd, aefg, ahij
     * behi, bfgj
     * cdej, cdgh, cfhi
     * dfgi
     */
    in.clear();
    for (size_t i = 0; i < 12; i++) {
        in.push_back(clique_4);
    }
    /*
     */
    delete MatchByShare(in, "10-clique",
            "abcdefghij_abcd_abce_abcf_abcg_abch_abci_abcj_defg_defh_defi_defj_ghij");
    // match 10-clique by sharing 5-clique
    in.clear();
    for (size_t i = 0; i < 9; i++) {
        in.push_back(clique_5);
    }
    delete MatchByShare(in, "10-clique",
            "abcdefghij_abcde_abcdf_abcdg_abcdh_abcdi_abcdj_efghi_efghj_fghij");
    // match 10-clique by sharing 6-clique
    in.clear();
    for (size_t i = 0; i < 6; i++) {
        in.push_back(clique_6);
    }
    delete MatchByShare(in, "10-clique",
            "abcdefghij_abcdef_abcdeg_abcdeh_abcdei_abcdej_efghij");
    // match 10-clique by sharing 7-clique
    in.clear();
    for (size_t i = 0; i < 5; i++) {
        in.push_back(clique_7);
    }
    delete MatchByShare(in, "10-clique",
            "abcdefghij_abcdefg_abcdefh_abcdefi_abcdefj_defghij");
    // match 10-clique by sharing 8-clique
    in.clear();
    for (size_t i = 0; i < 4; i++) {
        in.push_back(clique_8);
    }
    delete MatchByShare(in, "10-clique",
            "abcdefghij_abcdefgh_abcdefgi_abcdefgj_cdefghij");
    // match 10-clique by sharing 9-clique
    in.clear();
    in.push_back(clique_9);
    in.push_back(clique_9);
    in.push_back(graph.Edge(0));
    delete MatchByShare(in, "10-clique",
            "abcdefghij_abcdefghi_abcdefghj_ij__ij");
    delete clique_3;
    delete clique_4;
    delete clique_5;
    delete clique_6;
    delete clique_7;
    delete clique_8;
    delete clique_9;
    delete clique_10;
    return nullptr;
}

Node *FourClique(const Graph &graph) {
    // this is an example execution
    std::vector<Node *> input;
    input.push_back(graph.Edge(0));
    input.push_back(graph.Edge(0));
    input.push_back(graph.Edge(0));
    std::string key = "abc_ab_bc_ac__ab_bc";
    if (MATCHING_EXPRESSION.count(key)) {
        PrintLCTX("start execution: " << key);
        Node *abc = MATCHING_EXPRESSION[key](input);
        PrintLCTX("Count(abc)=" << abc->CountLeaf());
        key = "abcd_abc_bcd_ad";
        if (MATCHING_EXPRESSION.count(key)) {
            PrintLCTX("start execution: " << key);
            input.clear();
            input.push_back(abc);
            input.push_back(abc);
            input.push_back(graph.Edge(0));
            Node *abcd = MATCHING_EXPRESSION[key](input);
            PrintLCTX("Count(abcd)=" << abcd->CountLeaf());
            return abcd;
        } else {
            PrintLCTX("key not found. abort execution: " << key);
        }
    } else {
        PrintLCTX("key not found. abort execution: " << key);
    }
    return nullptr;
}

Node *FourCycle(const Graph &graph) {
    // this is an example execution
    std::vector<Node *> edge_1d;
    edge_1d.push_back(graph.Edge(0));
    Node *non_edge = new Node(edge_1d, VERTEX_SIZE);
    std::vector<Node *> input;
    input.push_back(graph.Edge(0));
    input.push_back(graph.Edge(0));
    input.push_back(non_edge);
    std::string key = "abc_ab_bc_ac0__ac";
    if (MATCHING_EXPRESSION.count(key)) {
        PrintLCTX("start execution: " << key);
        Node *abc = MATCHING_EXPRESSION[key](input);
        PrintLCTX("Count(abc)=" << abc->CountLeaf());
        key = "abcd_abc_bcd_ad__ab";
        if (MATCHING_EXPRESSION.count(key)) {
            PrintLCTX("start execution: " << key);
            input.clear();
            input.push_back(abc);
            input.push_back(abc);
            input.push_back(non_edge);
            Node *abcd = MATCHING_EXPRESSION[key](input);
            PrintLCTX("Count(abcd)=" << abcd->CountLeaf());
            return abcd;
        } else {
            PrintLCTX("key not found. abort execution: " << key);
        }
    } else {
        PrintLCTX("key not found. abort execution: " << key);
    }
    return nullptr;
}

uint64_t UStar4(node_1d_t &input) {
    Node *abc = MATCHING_EXPRESSION["s_abc_ab_ac_bc0__bc"](input);
    node_1d_t in;
    in.push_back(abc);
    in.push_back(input[1]);
    return COUNTING_EXPRESSION["c_s_abcd_abc_abd_cd0__cd"](in);
}

uint64_t UStar5(node_1d_t &input) {
    Node *abc = MATCHING_EXPRESSION["s_abc_ab_ac_bc0__bc"](input);
    node_1d_t in;
    in.push_back(abc);
    in.push_back(input[1]);
    Node *abcd = MATCHING_EXPRESSION["s_abcd_abc_abd_cd0__cd"](in);
    in[0] = abcd;
    return COUNTING_EXPRESSION["c_s_abcde_abcd_abce_de0__de"](in);
}

Node *DSink4(const Graph &graph) {
    // directed
    if (graph.LabelSize() != 2) {
        PrintLCTX("only support unlabeled graphs without undirected edges.");
        return nullptr;
    }
    std::vector<Node *> edge_1d;
    edge_1d.push_back(graph.Edge(0)); // in-coming edges
    edge_1d.push_back(graph.Edge(1)); // out-going edges
    Node *non_edge = new Node(edge_1d, VERTEX_SIZE);
    std::vector<Node *> input;
    input.push_back(graph.Edge(0)); // in-coming edges
    input.push_back(non_edge);
    PrintLCTX("d-sink-4 MatchCount=" << UStar4(input));
    return nullptr;
}

Node *DSink5(const Graph &graph) {
    // directed
    if (graph.LabelSize() != 2) {
        PrintLCTX("only support unlabeled graphs without undirected edges.");
        return nullptr;
    }
    std::vector<Node *> edge_1d;
    edge_1d.push_back(graph.Edge(0)); // in-coming edges
    edge_1d.push_back(graph.Edge(1)); // out-going edges
    Node *non_edge = new Node(edge_1d, VERTEX_SIZE);
    std::vector<Node *> input;
    input.push_back(graph.Edge(0)); // in-coming edges
    input.push_back(non_edge);
    PrintLCTX("d-sink-5 MatchCount=" << UStar5(input));
    return nullptr;
}

Node *DStar4(const Graph &graph) {
    // directed
    if (graph.LabelSize() != 2) {
        PrintLCTX("only support unlabeled graphs without undirected edges.");
        return nullptr;
    }
    std::vector<Node *> edge_1d;
    edge_1d.push_back(graph.Edge(0)); // in-coming edges
    edge_1d.push_back(graph.Edge(1)); // out-going edges
    Node *non_edge = new Node(edge_1d, VERTEX_SIZE);
    std::vector<Node *> input;
    input.push_back(graph.Edge(1)); // out-going edges
    input.push_back(non_edge);
    PrintLCTX("d-star-4 MatchCount=" << UStar4(input));
    return nullptr;
}

Node *DStar5(const Graph &graph) {
    // directed
    if (graph.LabelSize() != 2) {
        PrintLCTX("only support unlabeled graphs without undirected edges.");
        return nullptr;
    }
    std::vector<Node *> edge_1d;
    edge_1d.push_back(graph.Edge(0)); // in-coming edges
    edge_1d.push_back(graph.Edge(1)); // out-going edges
    Node *non_edge = new Node(edge_1d, VERTEX_SIZE);
    std::vector<Node *> input;
    input.push_back(graph.Edge(1)); // out-going edges
    input.push_back(non_edge);
    PrintLCTX("d-star-5 MatchCount=" << UStar5(input));
    return nullptr;
}

Node *TwoPath(const Graph &graph) {
    std::vector<Node*> edge_1d;
    edge_1d.push_back(graph.Edge(0));
    Node *non_edge = new Node(edge_1d, VERTEX_SIZE);
    std::vector<Node *> input;
    input.push_back(graph.Edge(0));
    input.push_back(graph.Edge(0));
    input.push_back(non_edge);
    std::string key = "abc_ab_bc_ac0__ac";
    if (MATCHING_EXPRESSION.count(key)) {
        PrintLCTX("start execution: " << key);
        Node *abc = MATCHING_EXPRESSION[key](input);
        PrintLCTX("Count(abc)=" << abc->CountLeaf());
        return abc;
    } else {
        PrintLCTX("key not found. abort execution: " << key);
    }
    return nullptr;
}

using plan_t = Node *(*)(const Graph &);
typedef std::unordered_map<std::string, plan_t> plan_map_t;

plan_map_t InitializeQueryPlan() {
    plan_map_t e_map;
    e_map.reserve(100);
    e_map["clique-3-count"] = Clique3Count;
    e_map["clique-3-match"] = Clique3Match;
    e_map["clique-4-count"] = Clique4Count;
    e_map["clique-4-match"] = Clique4Match;
    e_map["clique-5-count"] = Clique5Count;
    e_map["clique-5-match"] = Clique5Match;
    e_map["clique-6-count"] = Clique6Count;
    e_map["clique-6-match"] = Clique6Match;
    e_map["clique-7-count"] = Clique7Count;
    e_map["clique-7-match"] = Clique7Match;
    e_map["clique-8-count"] = Clique8Count;
    e_map["clique-8-match"] = Clique8Match;
    e_map["clique-9-count"] = Clique9Count;
    e_map["clique-9-match"] = Clique9Match;
    e_map["clique-10-count"] = Clique10Count;
    e_map["clique-10-match"] = Clique10Match;
    e_map["clique-match"] = CliqueMatch;
    e_map["d-sink-4"] = DSink4;
    e_map["d-sink-5"] = DSink5;
    e_map["d-star-4"] = DStar4;
    e_map["d-star-5"] = DStar5;
    e_map["4-clique"] = FourClique;
    e_map["4-cycle"] = FourCycle;
    e_map["2-path"] = TwoPath;
    return e_map;
}

plan_map_t QUERY_PLAN = InitializeQueryPlan();

// public function
bool ExecuteByQueryName(Config &config, const Graph &graph, Logger &logger) {
    // return status. true: good, false: failure
    MAX_DEGREE = graph.MaxDegree();
    VERTEX_SIZE = graph.VertexSize();
    SetDegreeSize(MAX_DEGREE, VERTEX_SIZE);
    if (QUERY_PLAN.count(config.QueryName())) {
        const timepoint_t &start = utility::GetTimepoint();
        Node *result = QUERY_PLAN[config.QueryName()](graph);
        logger.DurationExecutionCompiled = utility::GetDuration(start);
        if (result != nullptr) {
            logger.MatchCount = result->CountLeaf();
        }
        PrintCTX("DurationExecutionCompiled(s)=");
        Print(logger.DurationExecutionCompiled << " MatchCount=");
        Print(logger.MatchCount << " DataFile=" << config.DataFile());
        PrintLine(" QueryName=" << config.QueryName());
        const std::string &out_file = config.SaveFile();
        if ((result != nullptr) and out_file.size()) {
            result->SaveAsTable(out_file);
        }
        return true;
    } else {
        PrintLCTX("NotImplemented QueryName=" << config.QueryName());
    }
    return false;
}

} // namespace adhoc

} //namespace compile

} // namespace sorttrie
