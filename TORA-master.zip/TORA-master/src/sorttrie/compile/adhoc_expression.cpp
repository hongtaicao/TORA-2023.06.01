/*
 * adhoc_expression.cpp
 *
 *  Created on: 12:52 PM Thursday 2023年5-11
 *      Author: Hongtai Cao
 */

#include <cstdlib>          // size_t

#include "include/sorttrie/compile/adhoc_expression.hpp"
#include "include/sorttrie/iterator.hpp"
#include "include/sorttrie/join/join.hpp"
#include "include/sorttrie/join/join0.hpp"
#include "include/sorttrie/join/join01.hpp"
#include "include/sorttrie/join/join1.hpp"
#include "include/sorttrie/join/joins0.hpp"
#include "include/sorttrie/join/joins1s.hpp"
#include "include/sorttrie/join/joint.hpp"
#include "include/utility/clock.hpp"
#include "include/utility/utility.hpp"

namespace sorttrie {

namespace compile {

namespace adhoc {

// static declare and define (initialize). visible only in current file.
// local global variable
static vid_t MAX_DEGREE;
static vid_t VERTEX_SIZE;

typedef Iterator It;
typedef join::JoinT JoinT;
typedef join::JoinS0 JoinS0;
typedef join::JoinS1S JoinS1S;
typedef utility::timepoint_t timepoint_t;

using utility::COUNTER_LOOP_0;
using utility::COUNTER_LOOP_1;
using utility::COUNTER_LOOP_2;
using utility::COUNTER_LOOP_3;
using utility::COUNTER_LOOP_4;
using utility::COUNTER_LOOP_5;
using utility::COUNTER_LOOP_6;
using utility::COUNTER_LOOP_7;
using utility::COUNTER_LOOP_8;
using utility::COUNTER_LOOP_9;
using utility::COUNTER_LOOP_10;
using utility::COUNTER_LOOP_11;

// forward declaration
uint64_t c_6_11(Node *);

// local function definition that invisible outside
// trie width counter
uint64_t c_0_11(node_1d_t &in) {
    // count up to 12 levels
    for (It ia(in[0]); ia.InRange(); ia.Next()) {
        AddOne(COUNTER_LOOP_0);
        for (It ib(ia.GetNode()); ib.InRange(); ib.Next()) {
            AddOne(COUNTER_LOOP_1);
            for (It ic(ib.GetNode()); ic.InRange(); ic.Next()) {
                AddOne(COUNTER_LOOP_2);
                for (It id(ic.GetNode()); id.InRange(); id.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    for (It ie(id.GetNode()); ie.InRange(); ie.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        for (It iif(ie.GetNode()); iif.InRange(); iif.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            c_6_11(iif.GetNode());
                        }
                    }
                }
            }
        }
    }
    return 0;
}

uint64_t c_6_11(Node *node) {
    for (It ig(node); ig.InRange(); ig.Next()) {
        AddOne(COUNTER_LOOP_6);
        for (It ih(ig.GetNode()); ih.InRange(); ih.Next()) {
            AddOne(COUNTER_LOOP_7);
            for (It ii(ih.GetNode()); ii.InRange(); ii.Next()) {
                AddOne(COUNTER_LOOP_8);
                for (It ij(ii.GetNode()); ij.InRange(); ij.Next()) {
                    AddOne(COUNTER_LOOP_9);
                    for (It ij(ii.GetNode()); ij.InRange(); ij.Next()) {
                        AddOne(COUNTER_LOOP_10);
                        for (It ij(ii.GetNode()); ij.InRange(); ij.Next()) {
                            AddOne(COUNTER_LOOP_11);
                        }
                    }
                }
            }
        }
    }
    return 0;
}

Node *abc_ab_ac_bc__ab_bc(node_1d_t &in) {
    // optimized Join
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    const size_t VSIZE = 2;
    // Iterator on attribute a
    It *ia[VSIZE] { new It(in[0]), new It(in[1]) };
    // It on attribute b
    It *ib[VSIZE];
    // It on attribute c
    It *ic[VSIZE];
    for (JoinT a(ia); a.InRange(); a.Next()) {
        // Join (a,b).a and (a,c).a
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0));
        ib[1] = new It(in[2]);
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), b.Child(1));
            ic[1] = new It(a.Child(1));
            for (JoinT c(ic); c.InRange(); c.Next()) {
                // leaf level
                AddOne(COUNTER_LOOP_2);
                node_b.Append(c.Value());
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

uint64_t c_abc_ab_ac_bc__ab_bc(node_1d_t &in) {
    // optimized Join
    uint64_t counter = 0;
    const size_t VSIZE = 2;
    // Iterator on attribute a
    It *ia[VSIZE] { new It(in[0]), new It(in[1]) };
    // It on attribute b
    It *ib[VSIZE];
    // It on attribute c
    It *ic[VSIZE];
    for (JoinT a(ia); a.InRange(); a.Next()) {
        // Join (a,b).a and (a,c).a
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0));
        ib[1] = new It(in[2]);
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), b.Child(1));
            ic[1] = new It(a.Child(1));
            for (JoinT c(ic); c.InRange(); c.Next()) {
                // leaf level
                AddOne(COUNTER_LOOP_2);
                counter++;
            }
        }
    }
    return counter;
}

Node *abc_ab_bc_ac__ac(node_1d_t &in) {
    /*
     * function name indicates the computation
     * abc   ab bc ac   ac
     * first: WCOJ order is abc
     * remaining before __: relations are ab, bc, ac
     * after __: symmetry breaking is a<c
     */
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    const size_t VSIZE = 2;
    // Iterator on attribute a
    Iterator *ia[VSIZE] { new Iterator(in[0]), new Iterator(in[2]) };
    // Iterator on attribute b
    Iterator *ib[VSIZE];
    // Iterator on attribute c
    Iterator *ic[VSIZE];
    for (JoinT a(ia); a.InRange(); a.Next()) {
        // Join (a,b).a and (a,c).a
        AddOne(COUNTER_LOOP_0);
        Iterator a_c(a.Value(), a.Child(1)); // a<c
        ib[0] = new Iterator(a.Child(0));
        ib[1] = new Iterator(in[1]);
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new Iterator(a.Value(), b.Child(1));
            ic[1] = new Iterator(a_c);
            for (JoinT c(ic); c.InRange(); c.Next()) {
                // leaf level
                AddOne(COUNTER_LOOP_2);
                node_b.Append(c.Value());
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abc_ab_bc_ac__ab_bc(node_1d_t &in) {
    /*
     * function name indicates the computation
     * abc   ab bc ac   ab bc
     * first: WCOJ order is abc
     * remaining before __: relations are ab, bc, ac
     * after __: symmetry breaking is a<b and b<c
     */
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    const size_t VSIZE = 2;
    // Iterator on attribute a
    Iterator *ia[VSIZE] { new Iterator(in[0]), new Iterator(in[2]) };
    // Iterator on attribute b
    Iterator *ib[VSIZE];
    // Iterator on attribute c
    Iterator *ic[VSIZE];
    for (JoinT a(ia); a.InRange(); a.Next()) {
        // Join (a,b).a and (a,c).a
        AddOne(COUNTER_LOOP_0);
        ib[0] = new Iterator(a.Value(), a.Child(0));
        ib[1] = new Iterator(in[1]);
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new Iterator(b.Value(), b.Child(1));
            ic[1] = new Iterator(a.Child(1));
            for (JoinT c(ic); c.InRange(); c.Next()) {
                // leaf level
                AddOne(COUNTER_LOOP_2);
                node_b.Append(c.Value());
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abc_ab_bc_ac0__ac(node_1d_t &in) {
    /*
     * function name indicates the computation
     * abc   ab bc ac0   ac
     * first: WCOJ order is abc
     * remaining before __: relations are ab, bc, ac
     * after __: symmetry breaking is a<c
     * ac0: (a,c) are not connected. 0 -> negation
     */
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] { new Iterator(in[0]) };
    Iterator *ia0[1] { new Iterator(in[2]) };
    // Iterator on b
    Iterator *ib[2];
    // Iterator on c
    Iterator *ic[1];
    Iterator *ic1[1];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        // Join (a,b).a and (a,c).a
        AddOne(COUNTER_LOOP_0);
        ib[0] = new Iterator(a.Child(0));
        ib[1] = new Iterator(in[1]);
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new Iterator(a.Value(), b.Child(1)); // a<c
            ic1[0] = new Iterator(a.Child0(0));
            for (JoinS1S c(ic, ic1); c.InRange(); c.Next()) {
                // leaf level
                AddOne(COUNTER_LOOP_2);
                node_b.Append(c.Value());
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcd_ab_ac_ad_bc_bd_cd__ab_bc_cd(node_1d_t &in) {
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    const size_t VSIZE = 3;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]), new It(in[2]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    for (join::Join a(ia, VSIZE); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0)); // a<b
        ib[1] = new It(in[3]);
        ib[2] = new It(in[4]);
        for (join::Join b(ib, VSIZE); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), a.Child(1)); // b<c
            ic[1] = new It(b.Child(1));
            ic[2] = new It(in[5]);
            for (join::Join c(ic, VSIZE); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), a.Child(2)); // c<d
                id[1] = new It(b.Child(2));
                id[2] = new It(c.Child(2));
                for (join::Join d(id, VSIZE); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    node_c.Append(d.Value());
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

uint64_t c_abcd_ab_ac_ad_bc_bd_cd__ab_bc_cd(node_1d_t &in) {
    // optimized Join
    uint64_t counter = 0;
    const size_t VSIZE = 3;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]), new It(in[2]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    for (join::Join a(ia, VSIZE); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0)); // a<b
        ib[1] = new It(in[3]);
        ib[2] = new It(in[4]);
        for (join::Join b(ib, VSIZE); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), a.Child(1)); // b<c
            ic[1] = new It(b.Child(1));
            ic[2] = new It(in[5]);
            for (join::Join c(ic, VSIZE); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), a.Child(2)); // c<d
                id[1] = new It(b.Child(2));
                id[2] = new It(c.Child(2));
                for (join::Join d(id, VSIZE); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    counter++;
                }
            }
        }
    }
    return counter;
}

Node *abcd_abc_abd_cd__cd(node_1d_t &in) {
    // optimized Join
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    const size_t VSIZE = 2;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    for (JoinT a(ia); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0));
        ib[1] = new It(a.Child(1));
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0));
            ic[1] = new It(in[2]);
            for (JoinT c(ic); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), b.Child(1)); // c<d
                id[1] = new It(c.Child(1));
                for (JoinT d(id); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    node_c.Append(d.Value());
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

uint64_t c_abcd_abc_abd_cd__cd(node_1d_t &in) {
    // optimized Join
    uint64_t counter = 0;
    const size_t VSIZE = 2;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    for (JoinT a(ia); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0));
        ib[1] = new It(a.Child(1));
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0));
            ic[1] = new It(in[2]);
            for (JoinT c(ic); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), b.Child(1));
                id[1] = new It(c.Child(1));
                for (JoinT d(id); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    counter++;
                }
            }
        }
    }
    return counter;
}

Node *abcd_abc_bcd_ad(node_1d_t &in) {
    /*
     * WCOJ order is abcd
     * relations are abc, bcd, ad
     */
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    const size_t VSIZE = 2;
    Iterator *ia[VSIZE] { new Iterator(in[0]), new Iterator(in[2]) };
    Iterator *ib[VSIZE];
    Iterator *ic[VSIZE];
    Iterator *id[VSIZE];
    for (JoinT a(ia); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new Iterator(a.Child(0));
        ib[1] = new Iterator(in[1]);
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new Iterator(b.Child(0));
            ic[1] = new Iterator(b.Child(1));
            for (JoinT c(ic); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new Iterator(c.Child(1));
                id[1] = new Iterator(a.Child(1));
                for (JoinT d(id); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    node_c.Append(d.Value());
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcd_abc_bcd_ad__ab(node_1d_t &in) {
    /*
     * WCOJ order is abcd
     * relations are abc, bcd, ad
     * symmetry breaking is a<b
     */
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    const size_t VSIZE = 2;
    Iterator *ia[VSIZE] { new Iterator(in[0]), new Iterator(in[2]) };
    Iterator *ib[VSIZE];
    Iterator *ic[VSIZE];
    Iterator *id[VSIZE];
    for (JoinT a(ia); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new Iterator(a.Value(), a.Child(0)); // a<b
        ib[1] = new Iterator(in[1]);
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new Iterator(b.Child(0));
            ic[1] = new Iterator(b.Child(1));
            for (JoinT c(ic); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new Iterator(c.Child(1));
                id[1] = new Iterator(a.Child(1));
                for (JoinT d(id); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    node_c.Append(d.Value());
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcde_ab_ac_ad_ae_bc_bd_be_cd_ce_de__ab_bc_cd_de(node_1d_t &in) {
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    const size_t VSIZE = 4;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    for (join::Join a(ia, VSIZE); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0)); // a<b
        ib[1] = new It(in[4]);
        ib[2] = new It(in[5]);
        ib[3] = new It(in[6]);
        for (join::Join b(ib, VSIZE); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), a.Child(1)); // b<c
            ic[1] = new It(b.Child(1));
            ic[2] = new It(in[7]);
            ic[3] = new It(in[8]);
            for (join::Join c(ic, VSIZE); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), a.Child(2)); // c<d
                id[1] = new It(b.Child(2));
                id[2] = new It(c.Child(2));
                id[3] = new It(in[9]);
                for (join::Join d(id, VSIZE); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Value(), a.Child(3)); // d<e
                    ie[1] = new It(b.Child(3));
                    ie[2] = new It(c.Child(3));
                    ie[3] = new It(d.Child(3));
                    for (join::Join e(ie, VSIZE); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        node_d.Append(e.Value());
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

uint64_t c_abcde_ab_ac_ad_ae_bc_bd_be_cd_ce_de__ab_bc_cd_de(node_1d_t &in) {
    uint64_t counter = 0;
    const size_t VSIZE = 4;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    for (join::Join a(ia, VSIZE); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0)); // a<b
        ib[1] = new It(in[4]);
        ib[2] = new It(in[5]);
        ib[3] = new It(in[6]);
        for (join::Join b(ib, VSIZE); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), a.Child(1)); // b<c
            ic[1] = new It(b.Child(1));
            ic[2] = new It(in[7]);
            ic[3] = new It(in[8]);
            for (join::Join c(ic, VSIZE); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), a.Child(2)); // c<d
                id[1] = new It(b.Child(2));
                id[2] = new It(c.Child(2));
                id[3] = new It(in[9]);
                for (join::Join d(id, VSIZE); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Value(), a.Child(3)); // d<e
                    ie[1] = new It(b.Child(3));
                    ie[2] = new It(c.Child(3));
                    ie[3] = new It(d.Child(3));
                    for (join::Join e(ie, VSIZE); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        counter++;
                    }
                }
            }
        }
    }
    return counter;
}

Node *abcde_abc_abd_abe_cde(node_1d_t &in) {
    // optimized Join
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    It *ia[3] { new It(in[0]), new It(in[1]), new It(in[2]) };
    It *ib[3];
    It *ic[2];
    It *id[2];
    It *ie[2];
    for (join::Join a(ia, 3); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0));
        ib[1] = new It(a.Child(1));
        ib[2] = new It(a.Child(2));
        for (join::Join b(ib, 3); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0));
            ic[1] = new It(in[3]);
            for (JoinT c(ic); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(b.Child(1));
                id[1] = new It(c.Child(1));
                for (JoinT d(id); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(b.Child(2));
                    ie[1] = new It(d.Child(1));
                    for (JoinT e(ie); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        node_d.Append(e.Value());
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcde_abcd_abce_de__de(node_1d_t &in) {
    // optimized Join
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    const size_t VSIZE = 2;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    for (JoinT a(ia); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0));
        ib[1] = new It(a.Child(1));
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0));
            ic[1] = new It(b.Child(0));
            for (JoinT c(ic); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0));
                id[1] = new It(in[2]);
                for (JoinT d(id); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Value(), c.Child(1)); // d<c
                    ie[1] = new It(d.Child(1));
                    for (JoinT e(ie); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        node_d.Append(e.Value());
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdef_ab_ac_ad_ae_af_bc_bd_be_bf_cd_ce_cf_de_df_ef__ab_bc_cd_de_ef(
        node_1d_t &in) {
    // 6-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    const size_t VSIZE = 5;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    for (join::Join a(ia, VSIZE); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0)); // a<b
        ib[1] = new It(in[5]);
        ib[2] = new It(in[6]);
        ib[3] = new It(in[7]);
        ib[4] = new It(in[8]);
        for (join::Join b(ib, VSIZE); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), a.Child(1)); // b<c
            ic[1] = new It(b.Child(1));
            ic[2] = new It(in[9]);
            ic[3] = new It(in[10]);
            ic[4] = new It(in[11]);
            for (join::Join c(ic, VSIZE); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), a.Child(2)); // c<d
                id[1] = new It(b.Child(2));
                id[2] = new It(c.Child(2));
                id[3] = new It(in[12]);
                id[4] = new It(in[13]);
                for (join::Join d(id, VSIZE); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Value(), a.Child(3)); // d<e
                    ie[1] = new It(b.Child(3));
                    ie[2] = new It(c.Child(3));
                    ie[3] = new It(d.Child(3));
                    ie[4] = new It(in[14]);
                    for (join::Join e(ie, VSIZE); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Value(), a.Child(4)); // e<f
                        iif[1] = new It(b.Child(4));
                        iif[2] = new It(c.Child(4));
                        iif[3] = new It(d.Child(4));
                        iif[4] = new It(e.Child(4));
                        for (join::Join f(iif, VSIZE); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            node_e.Append(f.Value());
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

uint64_t c_abcdef_ab_ac_ad_ae_af_bc_bd_be_bf_cd_ce_cf_de_df_ef__ab_bc_cd_de_ef(
        node_1d_t &in) {
    // 6-clique
    uint64_t counter = 0;
    const size_t VSIZE = 5;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    for (join::Join a(ia, VSIZE); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0)); // a<b
        ib[1] = new It(in[5]);
        ib[2] = new It(in[6]);
        ib[3] = new It(in[7]);
        ib[4] = new It(in[8]);
        for (join::Join b(ib, VSIZE); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), a.Child(1)); // b<c
            ic[1] = new It(b.Child(1));
            ic[2] = new It(in[9]);
            ic[3] = new It(in[10]);
            ic[4] = new It(in[11]);
            for (join::Join c(ic, VSIZE); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), a.Child(2)); // c<d
                id[1] = new It(b.Child(2));
                id[2] = new It(c.Child(2));
                id[3] = new It(in[12]);
                id[4] = new It(in[13]);
                for (join::Join d(id, VSIZE); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Value(), a.Child(3)); // d<e
                    ie[1] = new It(b.Child(3));
                    ie[2] = new It(c.Child(3));
                    ie[3] = new It(d.Child(3));
                    ie[4] = new It(in[14]);
                    for (join::Join e(ie, VSIZE); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Value(), a.Child(4)); // e<f
                        iif[1] = new It(b.Child(4));
                        iif[2] = new It(c.Child(4));
                        iif[3] = new It(d.Child(4));
                        iif[4] = new It(e.Child(4));
                        for (join::Join f(iif, VSIZE); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            counter++;
                        }
                    }
                }
            }
        }
    }
    return counter;
}

Node *abcdef_abc_abd_abe_abf_cde_cdf_def(node_1d_t &in) {
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    It *ia[4] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]) };
    It *ib[4];
    It *ic[3];
    It *id[4];
    It *ie[3];
    It *iif[3];
    for (join::Join a(ia, 4); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0));
        ib[1] = new It(a.Child(1));
        ib[2] = new It(a.Child(2));
        ib[3] = new It(a.Child(3));
        for (join::Join b(ib, 4); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0));
            ic[1] = new It(in[4]);
            ic[2] = new It(in[5]);
            for (join::Join c(ic, 3); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(b.Child(1));
                id[1] = new It(c.Child(1));
                id[2] = new It(c.Child(2));
                id[3] = new It(in[6]);
                for (join::Join d(id, 4); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(b.Child(2));
                    ie[1] = new It(d.Child(1));
                    ie[2] = new It(d.Child(3));
                    for (join::Join e(ie, 3); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(b.Child(3));
                        iif[1] = new It(d.Child(2));
                        iif[2] = new It(e.Child(2));
                        for (join::Join f(iif, 3); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            node_e.Append(f.Value());
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdef_abcd_abce_abcf_cdef(node_1d_t &in) {
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    It *ia[3] { new It(in[0]), new It(in[1]), new It(in[2]) };
    It *ib[3];
    It *ic[4];
    It *id[2];
    It *ie[2];
    It *iif[2];
    for (join::Join a(ia, 3); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0));
        ib[1] = new It(a.Child(1));
        ib[2] = new It(a.Child(2));
        for (join::Join b(ib, 3); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0));
            ic[1] = new It(b.Child(1));
            ic[2] = new It(b.Child(2));
            ic[3] = new It(in[3]);
            for (join::Join c(ic, 4); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0));
                id[1] = new It(c.Child(3));
                for (JoinT d(id); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(c.Child(1));
                    ie[1] = new It(d.Child(1));
                    for (JoinT e(ie); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(c.Child(2));
                        iif[1] = new It(e.Child(1));
                        for (JoinT f(iif); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            node_e.Append(f.Value());
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdef_abcde_abcdf_ef__ef(node_1d_t &in) {
    // 6-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    const size_t VSIZE = 2;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    for (JoinT a(ia); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0));
        ib[1] = new It(a.Child(1));
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0));
            ic[1] = new It(b.Child(1));
            for (JoinT c(ic); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0));
                id[1] = new It(c.Child(1));
                for (JoinT d(id); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0));
                    ie[1] = new It(in[2]);
                    for (JoinT e(ie); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Value(), d.Child(1)); // e<f
                        iif[1] = new It(e.Child(1));
                        for (JoinT f(iif); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            node_e.Append(f.Value());
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefg_ab_ac_ad_ae_af_ag_bc_bd_be_bf_bg_cd_ce_cf_cg_de_df_dg_ef_eg_fg__ab_bc_cd_de_ef_fg(
        node_1d_t &in) {
    // 7-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    const size_t VSIZE = 6;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]), new It(in[5]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    It *ig[VSIZE];
    for (join::Join a(ia, VSIZE); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0)); // a<b
        ib[1] = new It(in[6]);
        ib[2] = new It(in[7]);
        ib[3] = new It(in[8]);
        ib[4] = new It(in[9]);
        ib[5] = new It(in[10]);
        for (join::Join b(ib, VSIZE); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), a.Child(1)); // b<c
            ic[1] = new It(b.Child(1));
            ic[2] = new It(in[11]);
            ic[3] = new It(in[12]);
            ic[4] = new It(in[13]);
            ic[5] = new It(in[14]);
            for (join::Join c(ic, VSIZE); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), a.Child(2)); // c<d
                id[1] = new It(b.Child(2));
                id[2] = new It(c.Child(2));
                id[3] = new It(in[15]);
                id[4] = new It(in[16]);
                id[5] = new It(in[17]);
                for (join::Join d(id, VSIZE); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Value(), a.Child(3)); // d<e
                    ie[1] = new It(b.Child(3));
                    ie[2] = new It(c.Child(3));
                    ie[3] = new It(d.Child(3));
                    ie[4] = new It(in[18]);
                    ie[5] = new It(in[19]);
                    for (join::Join e(ie, VSIZE); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Value(), a.Child(4)); // e<f
                        iif[1] = new It(b.Child(4));
                        iif[2] = new It(c.Child(4));
                        iif[3] = new It(d.Child(4));
                        iif[4] = new It(e.Child(4));
                        iif[5] = new It(in[20]);
                        for (join::Join f(iif, VSIZE); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Value(), a.Child(5)); // f<g
                            ig[1] = new It(b.Child(5));
                            ig[2] = new It(c.Child(5));
                            ig[3] = new It(d.Child(5));
                            ig[4] = new It(e.Child(5));
                            ig[5] = new It(f.Child(5));
                            for (join::Join g(ig, VSIZE); g.InRange();
                                    g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                node_f.Append(g.Value());
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

uint64_t c_abcdefg_ab_ac_ad_ae_af_ag_bc_bd_be_bf_bg_cd_ce_cf_cg_de_df_dg_ef_eg_fg__ab_bc_cd_de_ef_fg(
        node_1d_t &in) {
    uint64_t counter = 0;
    const size_t VSIZE = 6;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]), new It(in[5]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    It *ig[VSIZE];
    for (join::Join a(ia, VSIZE); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0)); // a<b
        ib[1] = new It(in[6]);
        ib[2] = new It(in[7]);
        ib[3] = new It(in[8]);
        ib[4] = new It(in[9]);
        ib[5] = new It(in[10]);
        for (join::Join b(ib, VSIZE); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), a.Child(1)); // b<c
            ic[1] = new It(b.Child(1));
            ic[2] = new It(in[11]);
            ic[3] = new It(in[12]);
            ic[4] = new It(in[13]);
            ic[5] = new It(in[14]);
            for (join::Join c(ic, VSIZE); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), a.Child(2)); // c<d
                id[1] = new It(b.Child(2));
                id[2] = new It(c.Child(2));
                id[3] = new It(in[15]);
                id[4] = new It(in[16]);
                id[5] = new It(in[17]);
                for (join::Join d(id, VSIZE); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Value(), a.Child(3)); // d<e
                    ie[1] = new It(b.Child(3));
                    ie[2] = new It(c.Child(3));
                    ie[3] = new It(d.Child(3));
                    ie[4] = new It(in[18]);
                    ie[5] = new It(in[19]);
                    for (join::Join e(ie, VSIZE); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Value(), a.Child(4)); // e<f
                        iif[1] = new It(b.Child(4));
                        iif[2] = new It(c.Child(4));
                        iif[3] = new It(d.Child(4));
                        iif[4] = new It(e.Child(4));
                        iif[5] = new It(in[20]);
                        for (join::Join f(iif, VSIZE); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Value(), a.Child(5)); // f<g
                            ig[1] = new It(b.Child(5));
                            ig[2] = new It(c.Child(5));
                            ig[3] = new It(d.Child(5));
                            ig[4] = new It(e.Child(5));
                            ig[5] = new It(f.Child(5));
                            for (join::Join g(ig, VSIZE); g.InRange();
                                    g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                counter++;
                            }
                        }
                    }
                }
            }
        }
    }
    return counter;
}

Node *abcdefg_abc_abd_abe_abf_abg_cde_cdf_cdg_efg(node_1d_t &in) {
    // 7-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    It *ia[5] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]) };
    It *ib[5];
    It *ic[4];
    It *id[4];
    It *ie[3];
    It *iif[3];
    It *ig[3];
    for (join::Join a(ia, 5); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abc
        ib[1] = new It(a.Child(1)); // abd
        ib[2] = new It(a.Child(2)); // abe
        ib[3] = new It(a.Child(3)); // abf
        ib[4] = new It(a.Child(4)); // abg
        for (join::Join b(ib, 5); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abc
            ic[1] = new It(in[5]); // cde
            ic[2] = new It(in[6]); // cdf
            ic[3] = new It(in[7]); // cdg
            for (join::Join c(ic, 4); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(b.Child(1)); // abd
                id[1] = new It(c.Child(1)); // cde
                id[2] = new It(c.Child(2)); // cdf
                id[3] = new It(c.Child(3)); // cdg
                for (join::Join d(id, 4); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(b.Child(2)); // abe
                    ie[1] = new It(d.Child(1)); // cde
                    ie[2] = new It(in[8]); // efg
                    for (join::Join e(ie, 3); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(b.Child(3)); // abf
                        iif[1] = new It(d.Child(2)); // cdf
                        iif[2] = new It(e.Child(2)); // efg
                        for (join::Join f(iif, 3); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(b.Child(4)); // abg
                            ig[1] = new It(d.Child(3)); // cdg
                            ig[2] = new It(f.Child(2)); // efg
                            for (join::Join g(ig, 3); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                node_f.Append(g.Value());
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefg_abcd_abce_abcf_abcg_defg(node_1d_t &in) {
    // 7-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    It *ia[4] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]) };
    It *ib[4];
    It *ic[4];
    It *id[2];
    It *ie[2];
    It *iif[2];
    It *ig[2];
    for (join::Join a(ia, 4); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abcd
        ib[1] = new It(a.Child(1)); // abce
        ib[2] = new It(a.Child(2)); // abcf
        ib[3] = new It(a.Child(3)); // abcg
        for (join::Join b(ib, 4); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abcd
            ic[1] = new It(b.Child(1)); // abce
            ic[2] = new It(b.Child(2)); // abcf
            ic[3] = new It(b.Child(3)); // abcg
            for (join::Join c(ic, 4); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0)); // abcd
                id[1] = new It(in[4]); // defg
                for (JoinT d(id); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(c.Child(1)); // abce
                    ie[1] = new It(d.Child(1)); // defg
                    for (JoinT e(ie); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(c.Child(2)); // abcf
                        iif[1] = new It(e.Child(1)); // defg
                        for (JoinT f(iif); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(c.Child(3)); // abcg
                            ig[1] = new It(f.Child(1)); // defg
                            for (JoinT g(ig); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                node_f.Append(g.Value());
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefg_abcde_abcdf_abcdg_cdefg(node_1d_t &in) {
    // 7-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    It *ia[3] { new It(in[0]), new It(in[1]), new It(in[2]) };
    It *ib[3];
    It *ic[4];
    It *id[4];
    It *ie[2];
    It *iif[2];
    It *ig[2];
    for (join::Join a(ia, 3); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abcde
        ib[1] = new It(a.Child(1)); // abcdf
        ib[2] = new It(a.Child(2)); // abcdg
        for (join::Join b(ib, 3); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abcde
            ic[1] = new It(b.Child(1)); // abcdf
            ic[2] = new It(b.Child(2)); // abcdg
            ic[3] = new It(in[3]); // cdefg
            for (join::Join c(ic, 4); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0)); // abcde
                id[1] = new It(c.Child(1)); // abcdf
                id[2] = new It(c.Child(2)); // abcdg
                id[3] = new It(c.Child(3)); // cdefg
                for (join::Join d(id, 4); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0)); // abcde
                    ie[1] = new It(d.Child(3)); // cdefg
                    for (JoinT e(ie); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(d.Child(1)); // abcdf
                        iif[1] = new It(e.Child(1)); // cdefg
                        for (JoinT f(iif); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(d.Child(2)); // abcdg
                            ig[1] = new It(f.Child(1)); // cdefg
                            for (JoinT g(ig); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                node_f.Append(g.Value());
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefg_abcdef_abcdeg_fg__fg(node_1d_t &in) {
    // 7-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    const size_t VSIZE = 2;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    It *ig[VSIZE];
    for (JoinT a(ia); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0));
        ib[1] = new It(a.Child(1));
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0));
            ic[1] = new It(b.Child(1));
            for (JoinT c(ic); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0));
                id[1] = new It(c.Child(1));
                for (JoinT d(id); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0));
                    ie[1] = new It(d.Child(1));
                    for (JoinT e(ie); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Child(0));
                        iif[1] = new It(in[2]);
                        for (JoinT f(iif); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Value(), e.Child(1)); // f<g
                            ig[1] = new It(f.Child(1));
                            for (JoinT g(ig); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                node_f.Append(g.Value());
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefgh_ab_ac_ad_ae_af_ag_ah_bc_bd_be_bf_bg_bh_cd_ce_cf_cg_ch_de_df_dg_dh_ef_eg_eh_fg_fh_gh__ab_bc_cd_de_ef_fg_gh(
        node_1d_t &in) {
    // 8-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    const size_t VSIZE = 7;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]), new It(in[5]), new It(in[6]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    It *ig[VSIZE];
    It *ih[VSIZE];
    for (join::Join a(ia, VSIZE); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0)); // a<b
        ib[1] = new It(in[7]);
        ib[2] = new It(in[8]);
        ib[3] = new It(in[9]);
        ib[4] = new It(in[10]);
        ib[5] = new It(in[11]);
        ib[6] = new It(in[12]);
        for (join::Join b(ib, VSIZE); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), a.Child(1)); // b<c
            ic[1] = new It(b.Child(1));
            ic[2] = new It(in[13]);
            ic[3] = new It(in[14]);
            ic[4] = new It(in[15]);
            ic[5] = new It(in[16]);
            ic[6] = new It(in[17]);
            for (join::Join c(ic, VSIZE); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), a.Child(2)); // c<d
                id[1] = new It(b.Child(2));
                id[2] = new It(c.Child(2));
                id[3] = new It(in[18]);
                id[4] = new It(in[19]);
                id[5] = new It(in[20]);
                id[6] = new It(in[21]);
                for (join::Join d(id, VSIZE); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Value(), a.Child(3)); // d<e
                    ie[1] = new It(b.Child(3));
                    ie[2] = new It(c.Child(3));
                    ie[3] = new It(d.Child(3));
                    ie[4] = new It(in[22]);
                    ie[5] = new It(in[23]);
                    ie[6] = new It(in[24]);
                    for (join::Join e(ie, VSIZE); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Value(), a.Child(4)); // e<f
                        iif[1] = new It(b.Child(4));
                        iif[2] = new It(c.Child(4));
                        iif[3] = new It(d.Child(4));
                        iif[4] = new It(e.Child(4));
                        iif[5] = new It(in[25]);
                        iif[6] = new It(in[26]);
                        for (join::Join f(iif, VSIZE); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Value(), a.Child(5)); // f<g
                            ig[1] = new It(b.Child(5));
                            ig[2] = new It(c.Child(5));
                            ig[3] = new It(d.Child(5));
                            ig[4] = new It(e.Child(5));
                            ig[5] = new It(f.Child(5));
                            ig[6] = new It(in[27]);
                            for (join::Join g(ig, VSIZE); g.InRange();
                                    g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(g.Value(), a.Child(6)); // g<h
                                ih[1] = new It(b.Child(6));
                                ih[2] = new It(c.Child(6));
                                ih[3] = new It(d.Child(6));
                                ih[4] = new It(e.Child(6));
                                ih[5] = new It(f.Child(6));
                                ih[6] = new It(g.Child(6));
                                for (join::Join h(ih, VSIZE); h.InRange();
                                        h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    node_g.Append(h.Value());
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

uint64_t c_abcdefgh_ab_ac_ad_ae_af_ag_ah_bc_bd_be_bf_bg_bh_cd_ce_cf_cg_ch_de_df_dg_dh_ef_eg_eh_fg_fh_gh__ab_bc_cd_de_ef_fg_gh(
        node_1d_t &in) {
    // 8-clique
    uint64_t counter = 0;
    const size_t VSIZE = 7;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]), new It(in[5]), new It(in[6]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    It *ig[VSIZE];
    It *ih[VSIZE];
    for (join::Join a(ia, VSIZE); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0)); // a<b
        ib[1] = new It(in[7]);
        ib[2] = new It(in[8]);
        ib[3] = new It(in[9]);
        ib[4] = new It(in[10]);
        ib[5] = new It(in[11]);
        ib[6] = new It(in[12]);
        for (join::Join b(ib, VSIZE); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), a.Child(1)); // b<c
            ic[1] = new It(b.Child(1));
            ic[2] = new It(in[13]);
            ic[3] = new It(in[14]);
            ic[4] = new It(in[15]);
            ic[5] = new It(in[16]);
            ic[6] = new It(in[17]);
            for (join::Join c(ic, VSIZE); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), a.Child(2)); // c<d
                id[1] = new It(b.Child(2));
                id[2] = new It(c.Child(2));
                id[3] = new It(in[18]);
                id[4] = new It(in[19]);
                id[5] = new It(in[20]);
                id[6] = new It(in[21]);
                for (join::Join d(id, VSIZE); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Value(), a.Child(3)); // d<e
                    ie[1] = new It(b.Child(3));
                    ie[2] = new It(c.Child(3));
                    ie[3] = new It(d.Child(3));
                    ie[4] = new It(in[22]);
                    ie[5] = new It(in[23]);
                    ie[6] = new It(in[24]);
                    for (join::Join e(ie, VSIZE); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Value(), a.Child(4)); // e<f
                        iif[1] = new It(b.Child(4));
                        iif[2] = new It(c.Child(4));
                        iif[3] = new It(d.Child(4));
                        iif[4] = new It(e.Child(4));
                        iif[5] = new It(in[25]);
                        iif[6] = new It(in[26]);
                        for (join::Join f(iif, VSIZE); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Value(), a.Child(5)); // f<g
                            ig[1] = new It(b.Child(5));
                            ig[2] = new It(c.Child(5));
                            ig[3] = new It(d.Child(5));
                            ig[4] = new It(e.Child(5));
                            ig[5] = new It(f.Child(5));
                            ig[6] = new It(in[27]);
                            for (join::Join g(ig, VSIZE); g.InRange();
                                    g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(g.Value(), a.Child(6)); // g<h
                                ih[1] = new It(b.Child(6));
                                ih[2] = new It(c.Child(6));
                                ih[3] = new It(d.Child(6));
                                ih[4] = new It(e.Child(6));
                                ih[5] = new It(f.Child(6));
                                ih[6] = new It(g.Child(6));
                                for (join::Join h(ih, VSIZE); h.InRange();
                                        h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    counter++;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return counter;
}

Node *abcdefgh_abc_abd_abe_abf_abg_abh_cde_cdf_cdg_cdh_efg_efh_fgh(
        node_1d_t &in) {
    // 8-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    It *ia[6] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]), new It(in[5]) };
    It *ib[6];
    It *ic[5];
    It *id[5];
    It *ie[4];
    It *iif[5];
    It *ig[4];
    It *ih[4];
    for (join::Join a(ia, 6); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abc
        ib[1] = new It(a.Child(1)); // abd
        ib[2] = new It(a.Child(2)); // abe
        ib[3] = new It(a.Child(3)); // abf
        ib[4] = new It(a.Child(4)); // abg
        ib[5] = new It(a.Child(5)); // abh
        for (join::Join b(ib, 6); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abc
            ic[1] = new It(in[6]); // cde
            ic[2] = new It(in[7]); // cdf
            ic[3] = new It(in[8]); // cdg
            ic[4] = new It(in[9]); // cdh
            for (join::Join c(ic, 5); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(b.Child(1)); // abd
                id[1] = new It(c.Child(1)); // cde
                id[2] = new It(c.Child(2)); // cdf
                id[3] = new It(c.Child(3)); // cdg
                id[4] = new It(c.Child(4)); // cdh
                for (join::Join d(id, 5); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(b.Child(2)); // abe
                    ie[1] = new It(d.Child(1)); // cde
                    ie[2] = new It(in[10]); // efg
                    ie[3] = new It(in[11]); // efh
                    for (join::Join e(ie, 4); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(b.Child(3)); // abf
                        iif[1] = new It(d.Child(2)); // cdf
                        iif[2] = new It(e.Child(2)); // efg
                        iif[3] = new It(e.Child(3)); // efh
                        iif[4] = new It(in[12]); // fgh
                        for (join::Join f(iif, 5); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(b.Child(4)); // abg
                            ig[1] = new It(d.Child(3)); // cdg
                            ig[2] = new It(f.Child(2)); // efg
                            ig[3] = new It(f.Child(4)); // fgh
                            for (join::Join g(ig, 4); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(b.Child(5)); // abh
                                ih[1] = new It(d.Child(4)); // cdh
                                ih[2] = new It(f.Child(3)); // efh
                                ih[3] = new It(g.Child(3)); // fgh
                                for (join::Join h(ih, 4); h.InRange();
                                        h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    node_g.Append(h.Value());
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefgh_abcd_abce_abcf_abcg_abch_defg_defh_efgh(node_1d_t &in) {
    // 8-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    It *ia[5] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]) };
    It *ib[5];
    It *ic[5];
    It *id[3];
    It *ie[4];
    It *iif[4];
    It *ig[3];
    It *ih[3];
    for (join::Join a(ia, 5); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abcd
        ib[1] = new It(a.Child(1)); // abce
        ib[2] = new It(a.Child(2)); // abcf
        ib[3] = new It(a.Child(3)); // abcg
        ib[4] = new It(a.Child(4)); // abch
        for (join::Join b(ib, 5); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abcd
            ic[1] = new It(b.Child(1)); // abce
            ic[2] = new It(b.Child(2)); // abcf
            ic[3] = new It(b.Child(3)); // abcg
            ic[4] = new It(b.Child(4)); // abch
            for (join::Join c(ic, 5); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0)); // abcd
                id[1] = new It(in[5]); // defg
                id[2] = new It(in[6]); // defh
                for (join::Join d(id, 3); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(c.Child(1)); // abce
                    ie[1] = new It(d.Child(1)); // defg
                    ie[2] = new It(d.Child(2)); // defh
                    ie[3] = new It(in[7]); // efgh
                    for (join::Join e(ie, 4); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(c.Child(2)); // abcf
                        iif[1] = new It(e.Child(1)); // defg
                        iif[2] = new It(e.Child(2)); // defh
                        iif[3] = new It(e.Child(3)); // efgh
                        for (join::Join f(iif, 4); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(c.Child(3)); // abcg
                            ig[1] = new It(f.Child(1)); // defg
                            ig[2] = new It(f.Child(3)); // efgh
                            for (join::Join g(ig, 3); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(c.Child(4)); // abch
                                ih[1] = new It(f.Child(2)); // defh
                                ih[2] = new It(g.Child(2)); // efgh
                                for (join::Join h(ih, 3); h.InRange();
                                        h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    node_g.Append(h.Value());
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefgh_abcde_abcdf_abcdg_abcdh_defgh(node_1d_t &in) {
    // 8-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    It *ia[4] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]) };
    It *ib[4];
    It *ic[4];
    It *id[5];
    It *ie[2];
    It *iif[2];
    It *ig[2];
    It *ih[2];
    for (join::Join a(ia, 4); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abcde
        ib[1] = new It(a.Child(1)); // abcdf
        ib[2] = new It(a.Child(2)); // abcdg
        ib[3] = new It(a.Child(3)); // abcdh
        for (join::Join b(ib, 4); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abcde
            ic[1] = new It(b.Child(1)); // abcdf
            ic[2] = new It(b.Child(2)); // abcdg
            ic[3] = new It(b.Child(3)); // abcdh
            for (join::Join c(ic, 4); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0)); // abcde
                id[1] = new It(c.Child(1)); // abcdf
                id[2] = new It(c.Child(2)); // abcdg
                id[3] = new It(c.Child(3)); // abcdh
                id[4] = new It(in[4]); // defgh
                for (join::Join d(id, 5); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0)); // abcde
                    ie[1] = new It(d.Child(4)); // defgh
                    for (JoinT e(ie); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(d.Child(1)); // abcdf
                        iif[1] = new It(e.Child(1)); // defgh
                        for (JoinT f(iif); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(d.Child(2)); // abcdg
                            ig[1] = new It(f.Child(1)); // defgh
                            for (JoinT g(ig); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(d.Child(3)); // abcdh
                                ih[1] = new It(g.Child(1)); // defgh
                                for (JoinT h(ih); h.InRange(); h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    node_g.Append(h.Value());
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefgh_abcdef_abcdeg_abcdeh_cdefgh(node_1d_t &in) {
    // 8-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    It *ia[3] { new It(in[0]), new It(in[1]), new It(in[2]) };
    It *ib[3];
    It *ic[4];
    It *id[4];
    It *ie[4];
    It *iif[2];
    It *ig[2];
    It *ih[2];
    for (join::Join a(ia, 3); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abcdef
        ib[1] = new It(a.Child(1)); // abcdeg
        ib[2] = new It(a.Child(2)); // abcdeh
        for (join::Join b(ib, 3); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abcdef
            ic[1] = new It(b.Child(1)); // abcdeg
            ic[2] = new It(b.Child(2)); // abcdeh
            ic[3] = new It(in[3]); // cdefgh
            for (join::Join c(ic, 4); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0)); // abcdef
                id[1] = new It(c.Child(1)); // abcdeg
                id[2] = new It(c.Child(2)); // abcdeh
                id[3] = new It(c.Child(3)); // cdefgh
                for (join::Join d(id, 4); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0)); // abcdef
                    ie[1] = new It(d.Child(1)); // abcdeg
                    ie[2] = new It(d.Child(2)); // abcdeh
                    ie[3] = new It(d.Child(3)); // cdefgh
                    for (join::Join e(ie, 4); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Child(0)); // abcdef
                        iif[1] = new It(e.Child(3)); // cdefgh
                        for (JoinT f(iif); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(e.Child(1)); // abcdeg
                            ig[1] = new It(f.Child(1)); // cdefgh
                            for (JoinT g(ig); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(e.Child(2)); // abcdeh
                                ih[1] = new It(g.Child(1)); // cdefgh
                                for (JoinT h(ih); h.InRange(); h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    node_g.Append(h.Value());
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefgh_abcdefg_abcdefh_gh__gh(node_1d_t &in) {
    // 8-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    const size_t VSIZE = 2;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    It *ig[VSIZE];
    It *ih[VSIZE];
    for (JoinT a(ia); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0));
        ib[1] = new It(a.Child(1));
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0));
            ic[1] = new It(b.Child(1));
            for (JoinT c(ic); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0));
                id[1] = new It(c.Child(1));
                for (JoinT d(id); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0));
                    ie[1] = new It(d.Child(1));
                    for (JoinT e(ie); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Child(0));
                        iif[1] = new It(e.Child(1));
                        for (JoinT f(iif); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Child(0));
                            ig[1] = new It(in[2]);
                            for (JoinT g(ig); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(g.Value(), f.Child(1));
                                ih[1] = new It(g.Child(1));
                                for (JoinT h(ih); h.InRange(); h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    node_g.Append(h.Value());
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefghi_ab_ac_ad_ae_af_ag_ah_ai_bc_bd_be_bf_bg_bh_bi_cd_ce_cf_cg_ch_ci_de_df_dg_dh_di_ef_eg_eh_ei_fg_fh_fi_gh_gi_hi__ab_bc_cd_de_ef_fg_gh_hi(
        node_1d_t &in) {
    // 9-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    const size_t VSIZE = 8;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]), new It(in[5]), new It(in[6]), new It(in[7]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    It *ig[VSIZE];
    It *ih[VSIZE];
    It *ii[VSIZE];
    for (join::Join a(ia, VSIZE); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0)); // a<b
        ib[1] = new It(in[8]);
        ib[2] = new It(in[9]);
        ib[3] = new It(in[10]);
        ib[4] = new It(in[11]);
        ib[5] = new It(in[12]);
        ib[6] = new It(in[13]);
        ib[7] = new It(in[14]);
        for (join::Join b(ib, VSIZE); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), a.Child(1)); // b<c
            ic[1] = new It(b.Child(1));
            ic[2] = new It(in[15]);
            ic[3] = new It(in[16]);
            ic[4] = new It(in[17]);
            ic[5] = new It(in[18]);
            ic[6] = new It(in[19]);
            ic[7] = new It(in[20]);
            for (join::Join c(ic, VSIZE); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), a.Child(2)); // c<d
                id[1] = new It(b.Child(2));
                id[2] = new It(c.Child(2));
                id[3] = new It(in[21]);
                id[4] = new It(in[22]);
                id[5] = new It(in[23]);
                id[6] = new It(in[24]);
                id[7] = new It(in[25]);
                for (join::Join d(id, VSIZE); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Value(), a.Child(3)); // d<e
                    ie[1] = new It(b.Child(3));
                    ie[2] = new It(c.Child(3));
                    ie[3] = new It(d.Child(3));
                    ie[4] = new It(in[26]);
                    ie[5] = new It(in[27]);
                    ie[6] = new It(in[28]);
                    ie[7] = new It(in[29]);
                    for (join::Join e(ie, VSIZE); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Value(), a.Child(4)); // e<f
                        iif[1] = new It(b.Child(4));
                        iif[2] = new It(c.Child(4));
                        iif[3] = new It(d.Child(4));
                        iif[4] = new It(e.Child(4));
                        iif[5] = new It(in[30]);
                        iif[6] = new It(in[31]);
                        iif[7] = new It(in[32]);
                        for (join::Join f(iif, VSIZE); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Value(), a.Child(5)); // f<g
                            ig[1] = new It(b.Child(5));
                            ig[2] = new It(c.Child(5));
                            ig[3] = new It(d.Child(5));
                            ig[4] = new It(e.Child(5));
                            ig[5] = new It(f.Child(5));
                            ig[6] = new It(in[33]);
                            ig[7] = new It(in[34]);
                            for (join::Join g(ig, VSIZE); g.InRange();
                                    g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(g.Value(), a.Child(6)); // g<h
                                ih[1] = new It(b.Child(6));
                                ih[2] = new It(c.Child(6));
                                ih[3] = new It(d.Child(6));
                                ih[4] = new It(e.Child(6));
                                ih[5] = new It(f.Child(6));
                                ih[6] = new It(g.Child(6));
                                ih[7] = new It(in[35]);
                                for (join::Join h(ih, VSIZE); h.InRange();
                                        h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(h.Value(), a.Child(7)); // h<i
                                    ii[1] = new It(b.Child(7));
                                    ii[2] = new It(c.Child(7));
                                    ii[3] = new It(d.Child(7));
                                    ii[4] = new It(e.Child(7));
                                    ii[5] = new It(f.Child(7));
                                    ii[6] = new It(g.Child(7));
                                    ii[7] = new It(h.Child(7));
                                    for (join::Join i(ii, VSIZE); i.InRange();
                                            i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        node_h.Append(i.Value());
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

uint64_t c_abcdefghi_ab_ac_ad_ae_af_ag_ah_ai_bc_bd_be_bf_bg_bh_bi_cd_ce_cf_cg_ch_ci_de_df_dg_dh_di_ef_eg_eh_ei_fg_fh_fi_gh_gi_hi__ab_bc_cd_de_ef_fg_gh_hi(
        node_1d_t &in) {
    // 9-clique
    uint64_t counter = 0;
    const size_t VSIZE = 8;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]), new It(in[5]), new It(in[6]), new It(in[7]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    It *ig[VSIZE];
    It *ih[VSIZE];
    It *ii[VSIZE];
    for (join::Join a(ia, VSIZE); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0)); // a<b
        ib[1] = new It(in[8]);
        ib[2] = new It(in[9]);
        ib[3] = new It(in[10]);
        ib[4] = new It(in[11]);
        ib[5] = new It(in[12]);
        ib[6] = new It(in[13]);
        ib[7] = new It(in[14]);
        for (join::Join b(ib, VSIZE); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), a.Child(1)); // b<c
            ic[1] = new It(b.Child(1));
            ic[2] = new It(in[15]);
            ic[3] = new It(in[16]);
            ic[4] = new It(in[17]);
            ic[5] = new It(in[18]);
            ic[6] = new It(in[19]);
            ic[7] = new It(in[20]);
            for (join::Join c(ic, VSIZE); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), a.Child(2)); // c<d
                id[1] = new It(b.Child(2));
                id[2] = new It(c.Child(2));
                id[3] = new It(in[21]);
                id[4] = new It(in[22]);
                id[5] = new It(in[23]);
                id[6] = new It(in[24]);
                id[7] = new It(in[25]);
                for (join::Join d(id, VSIZE); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Value(), a.Child(3)); // d<e
                    ie[1] = new It(b.Child(3));
                    ie[2] = new It(c.Child(3));
                    ie[3] = new It(d.Child(3));
                    ie[4] = new It(in[26]);
                    ie[5] = new It(in[27]);
                    ie[6] = new It(in[28]);
                    ie[7] = new It(in[29]);
                    for (join::Join e(ie, VSIZE); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Value(), a.Child(4)); // e<f
                        iif[1] = new It(b.Child(4));
                        iif[2] = new It(c.Child(4));
                        iif[3] = new It(d.Child(4));
                        iif[4] = new It(e.Child(4));
                        iif[5] = new It(in[30]);
                        iif[6] = new It(in[31]);
                        iif[7] = new It(in[32]);
                        for (join::Join f(iif, VSIZE); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Value(), a.Child(5)); // f<g
                            ig[1] = new It(b.Child(5));
                            ig[2] = new It(c.Child(5));
                            ig[3] = new It(d.Child(5));
                            ig[4] = new It(e.Child(5));
                            ig[5] = new It(f.Child(5));
                            ig[6] = new It(in[33]);
                            ig[7] = new It(in[34]);
                            for (join::Join g(ig, VSIZE); g.InRange();
                                    g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(g.Value(), a.Child(6)); // g<h
                                ih[1] = new It(b.Child(6));
                                ih[2] = new It(c.Child(6));
                                ih[3] = new It(d.Child(6));
                                ih[4] = new It(e.Child(6));
                                ih[5] = new It(f.Child(6));
                                ih[6] = new It(g.Child(6));
                                ih[7] = new It(in[35]);
                                for (join::Join h(ih, VSIZE); h.InRange();
                                        h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(h.Value(), a.Child(7)); // h<i
                                    ii[1] = new It(b.Child(7));
                                    ii[2] = new It(c.Child(7));
                                    ii[3] = new It(d.Child(7));
                                    ii[4] = new It(e.Child(7));
                                    ii[5] = new It(f.Child(7));
                                    ii[6] = new It(g.Child(7));
                                    ii[7] = new It(h.Child(7));
                                    for (join::Join i(ii, VSIZE); i.InRange();
                                            i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return counter;
}

Node *abcdefghi_abc_abd_abe_abf_abg_abh_abi_cde_cdf_cdg_cdh_cdi_efg_efh_efi_ghi(
        node_1d_t &in) {
    // 9-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    It *ia[7] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]), new It(in[5]), new It(in[6]) };
    It *ib[7];
    It *ic[6];
    It *id[6];
    It *ie[5];
    It *iif[5];
    It *ig[4];
    It *ih[4];
    It *ii[4];
    for (join::Join a(ia, 7); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abc
        ib[1] = new It(a.Child(1)); // abd
        ib[2] = new It(a.Child(2)); // abe
        ib[3] = new It(a.Child(3)); // abf
        ib[4] = new It(a.Child(4)); // abg
        ib[5] = new It(a.Child(5)); // abh
        ib[6] = new It(a.Child(6)); // abi
        for (join::Join b(ib, 7); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abc
            ic[1] = new It(in[7]); // cde
            ic[2] = new It(in[8]); // cdf
            ic[3] = new It(in[9]); // cdg
            ic[4] = new It(in[10]); // cdh
            ic[5] = new It(in[11]); // cdi
            for (join::Join c(ic, 6); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(b.Child(1)); // abd
                id[1] = new It(c.Child(1)); // cde
                id[2] = new It(c.Child(2)); // cdf
                id[3] = new It(c.Child(3)); // cdg
                id[4] = new It(c.Child(4)); // cdh
                id[5] = new It(c.Child(5)); // cdi
                for (join::Join d(id, 6); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(b.Child(2)); // abe
                    ie[1] = new It(d.Child(1)); // cde
                    ie[2] = new It(in[12]); // efg
                    ie[3] = new It(in[13]); // efh
                    ie[4] = new It(in[14]); // efi
                    for (join::Join e(ie, 5); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(b.Child(3)); // abf
                        iif[1] = new It(d.Child(2)); // cdf
                        iif[2] = new It(e.Child(2)); // efg
                        iif[3] = new It(e.Child(3)); // efh
                        iif[4] = new It(e.Child(4)); // efi
                        for (join::Join f(iif, 5); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(b.Child(4)); // abg
                            ig[1] = new It(d.Child(3)); // cdg
                            ig[2] = new It(f.Child(2)); // efg
                            ig[3] = new It(in[15]); // ghi
                            for (join::Join g(ig, 4); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(b.Child(5)); // abh
                                ih[1] = new It(d.Child(4)); // cdh
                                ih[2] = new It(f.Child(3)); // efh
                                ih[3] = new It(g.Child(3)); // ghi
                                for (join::Join h(ih, 4); h.InRange();
                                        h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(b.Child(6)); // abi
                                    ii[1] = new It(d.Child(5)); // cdi
                                    ii[2] = new It(f.Child(4)); // efi
                                    ii[3] = new It(h.Child(3)); // ghi
                                    for (join::Join i(ii, 4); i.InRange();
                                            i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        node_h.Append(i.Value());
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefghi_abcd_abce_abcf_abcg_abch_abci_defg_defh_defi_fghi(
        node_1d_t &in) {
    // 9-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    It *ia[6] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]), new It(in[5]) };
    It *ib[6];
    It *ic[6];
    It *id[4];
    It *ie[4];
    It *iif[5];
    It *ig[3];
    It *ih[3];
    It *ii[3];
    for (join::Join a(ia, 6); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abcd
        ib[1] = new It(a.Child(1)); // abce
        ib[2] = new It(a.Child(2)); // abcf
        ib[3] = new It(a.Child(3)); // abcg
        ib[4] = new It(a.Child(4)); // abch
        ib[5] = new It(a.Child(5)); // abci
        for (join::Join b(ib, 6); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abcd
            ic[1] = new It(b.Child(1)); // abce
            ic[2] = new It(b.Child(2)); // abcf
            ic[3] = new It(b.Child(3)); // abcg
            ic[4] = new It(b.Child(4)); // abch
            ic[5] = new It(b.Child(5)); // abci
            for (join::Join c(ic, 6); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0)); // abcd
                id[1] = new It(in[6]); // defg
                id[2] = new It(in[7]); // defh
                id[3] = new It(in[8]); // defi
                for (join::Join d(id, 4); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(c.Child(1)); // abce
                    ie[1] = new It(d.Child(1)); // defg
                    ie[2] = new It(d.Child(2)); // defh
                    ie[3] = new It(d.Child(3)); // defi
                    for (join::Join e(ie, 4); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(c.Child(2)); // abcf
                        iif[1] = new It(e.Child(1)); // defg
                        iif[2] = new It(e.Child(2)); // defh
                        iif[3] = new It(e.Child(3)); // defi
                        iif[4] = new It(in[9]); // fghi
                        for (join::Join f(iif, 5); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(c.Child(3)); // abcg
                            ig[1] = new It(f.Child(1)); // defg
                            ig[2] = new It(f.Child(4)); // fghi
                            for (join::Join g(ig, 3); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(c.Child(4)); // abch
                                ih[1] = new It(f.Child(2)); // defh
                                ih[2] = new It(g.Child(2)); // fghi
                                for (join::Join h(ih, 3); h.InRange();
                                        h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(c.Child(5)); // abci
                                    ii[1] = new It(f.Child(3)); // defi
                                    ii[2] = new It(h.Child(2)); // fghi
                                    for (join::Join i(ii, 3); i.InRange();
                                            i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        node_h.Append(i.Value());
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefghi_abcde_abcdf_abcdg_abcdh_abcdi_efghi(node_1d_t &in) {
    // 9-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    It *ia[5] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]) };
    It *ib[5];
    It *ic[5];
    It *id[5];
    It *ie[2];
    It *iif[2];
    It *ig[2];
    It *ih[2];
    It *ii[2];
    for (join::Join a(ia, 5); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abcde
        ib[1] = new It(a.Child(1)); // abcdf
        ib[2] = new It(a.Child(2)); // abcdg
        ib[3] = new It(a.Child(3)); // abcdh
        ib[4] = new It(a.Child(4)); // abcdi
        for (join::Join b(ib, 5); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abcde
            ic[1] = new It(b.Child(1)); // abcdf
            ic[2] = new It(b.Child(2)); // abcdg
            ic[3] = new It(b.Child(3)); // abcdh
            ic[4] = new It(b.Child(4)); // abcdi
            for (join::Join c(ic, 5); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0)); // abcde
                id[1] = new It(c.Child(1)); // abcdf
                id[2] = new It(c.Child(2)); // abcdg
                id[3] = new It(c.Child(3)); // abcdh
                id[4] = new It(c.Child(4)); // abcdi
                for (join::Join d(id, 5); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0)); // abcde
                    ie[1] = new It(in[5]); // efghi
                    for (JoinT e(ie); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(d.Child(1)); // abcdf
                        iif[1] = new It(e.Child(1)); // efghi
                        for (JoinT f(iif); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(d.Child(2)); // abcdg
                            ig[1] = new It(f.Child(1)); // efghi
                            for (JoinT g(ig); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(d.Child(3)); // abcdh
                                ih[1] = new It(g.Child(1)); // efghi
                                for (JoinT h(ih); h.InRange(); h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(d.Child(4)); // abcdi
                                    ii[1] = new It(h.Child(1)); // efghi
                                    for (JoinT i(ii); i.InRange(); i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        node_h.Append(i.Value());
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefghi_abcdef_abcdeg_abcdeh_abcdei_defghi(node_1d_t &in) {
    // 9-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    It *ia[4] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]) };
    It *ib[4];
    It *ic[4];
    It *id[5];
    It *ie[5];
    It *iif[2];
    It *ig[2];
    It *ih[2];
    It *ii[2];
    for (join::Join a(ia, 4); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abcdef
        ib[1] = new It(a.Child(1)); // abcdeg
        ib[2] = new It(a.Child(2)); // abcdeh
        ib[3] = new It(a.Child(3)); // abcdei
        for (join::Join b(ib, 4); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abcdef
            ic[1] = new It(b.Child(1)); // abcdeg
            ic[2] = new It(b.Child(2)); // abcdeh
            ic[3] = new It(b.Child(3)); // abcdei
            for (join::Join c(ic, 4); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0)); // abcdef
                id[1] = new It(c.Child(1)); // abcdeg
                id[2] = new It(c.Child(2)); // abcdeh
                id[3] = new It(c.Child(3)); // abcdei
                id[4] = new It(in[4]); // defghi
                for (join::Join d(id, 5); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0)); // abcdef
                    ie[1] = new It(d.Child(1)); // abcdeg
                    ie[2] = new It(d.Child(2)); // abcdeh
                    ie[3] = new It(d.Child(3)); // abcdei
                    ie[4] = new It(d.Child(4)); // defghi
                    for (join::Join e(ie, 5); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Child(0)); // abcdef
                        iif[1] = new It(e.Child(4)); // defghi
                        for (JoinT f(iif); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(e.Child(1)); // abcdeg
                            ig[1] = new It(f.Child(1)); // defghi
                            for (JoinT g(ig); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(e.Child(2)); // abcdeh
                                ih[1] = new It(g.Child(1)); // defghi
                                for (JoinT h(ih); h.InRange(); h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(e.Child(3)); // abcdei
                                    ii[1] = new It(h.Child(1)); // defghi
                                    for (JoinT i(ii); i.InRange(); i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        node_h.Append(i.Value());
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefghi_abcdefg_abcdefh_abcdefi_cdefghi(node_1d_t &in) {
    // 9-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    It *ia[3] { new It(in[0]), new It(in[1]), new It(in[2]) };
    It *ib[3];
    It *ic[4];
    It *id[4];
    It *ie[4];
    It *iif[4];
    It *ig[2];
    It *ih[2];
    It *ii[2];
    for (join::Join a(ia, 3); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abcdefg
        ib[1] = new It(a.Child(1)); // abcdefh
        ib[2] = new It(a.Child(2)); // abcdefi
        for (join::Join b(ib, 3); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abcdefg
            ic[1] = new It(b.Child(1)); // abcdefh
            ic[2] = new It(b.Child(2)); // abcdefi
            ic[3] = new It(in[3]); // cdefghi
            for (join::Join c(ic, 4); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0)); // abcdefg
                id[1] = new It(c.Child(1)); // abcdefh
                id[2] = new It(c.Child(2)); // abcdefi
                id[3] = new It(c.Child(3)); // cdefghi
                for (join::Join d(id, 4); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0)); // abcdefg
                    ie[1] = new It(d.Child(1)); // abcdefh
                    ie[2] = new It(d.Child(2)); // abcdefi
                    ie[3] = new It(d.Child(3)); // cdefghi
                    for (join::Join e(ie, 4); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Child(0)); // abcdefg
                        iif[1] = new It(e.Child(1)); // abcdefh
                        iif[2] = new It(e.Child(2)); // abcdefi
                        iif[3] = new It(e.Child(3)); // cdefghi
                        for (join::Join f(iif, 4); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Child(0)); // abcdefg
                            ig[1] = new It(f.Child(3)); // cdefghi
                            for (JoinT g(ig); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(f.Child(1)); // abcdefh
                                ih[1] = new It(g.Child(1)); // cdefghi
                                for (JoinT h(ih); h.InRange(); h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(f.Child(2)); // abcdefi
                                    ii[1] = new It(h.Child(1)); // cdefghi
                                    for (JoinT i(ii); i.InRange(); i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        node_h.Append(i.Value());
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefghi_abcdefgh_abcdefgi_hi__hi(node_1d_t &in) {
    // 9-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    const size_t VSIZE = 2;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    It *ig[VSIZE];
    It *ih[VSIZE];
    It *ii[VSIZE];
    for (JoinT a(ia); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0));
        ib[1] = new It(a.Child(1));
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0));
            ic[1] = new It(b.Child(1));
            for (JoinT c(ic); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0));
                id[1] = new It(c.Child(1));
                for (JoinT d(id); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0));
                    ie[1] = new It(d.Child(1));
                    for (JoinT e(ie); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Child(0));
                        iif[1] = new It(e.Child(1));
                        for (JoinT f(iif); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Child(0));
                            ig[1] = new It(f.Child(1));
                            for (JoinT g(ig); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(g.Child(0));
                                ih[1] = new It(in[2]);
                                for (JoinT h(ih); h.InRange(); h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(h.Value(), g.Child(1)); // h<i
                                    ii[1] = new It(h.Child(1));
                                    for (JoinT i(ii); i.InRange(); i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        node_h.Append(i.Value());
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefghij_ab_ac_ad_ae_af_ag_ah_ai_aj_bc_bd_be_bf_bg_bh_bi_bj_cd_ce_cf_cg_ch_ci_cj_de_df_dg_dh_di_dj_ef_eg_eh_ei_ej_fg_fh_fi_fj_gh_gi_gj_hi_hj_ij__ab_bc_cd_de_ef_fg_gh_hi_ij(
        node_1d_t &in) {
    // 10-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    Node node_i(MAX_DEGREE);
    const size_t VSIZE = 9;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]), new It(in[5]), new It(in[6]), new It(in[7]), new It(
                    in[8]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    It *ig[VSIZE];
    It *ih[VSIZE];
    It *ii[VSIZE];
    It *ij[VSIZE];
    for (join::Join a(ia, VSIZE); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0)); // a<b
        ib[1] = new It(in[9]);
        ib[2] = new It(in[10]);
        ib[3] = new It(in[11]);
        ib[4] = new It(in[12]);
        ib[5] = new It(in[13]);
        ib[6] = new It(in[14]);
        ib[7] = new It(in[15]);
        ib[8] = new It(in[16]);
        for (join::Join b(ib, VSIZE); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), a.Child(1)); // b<c
            ic[1] = new It(b.Child(1));
            ic[2] = new It(in[17]);
            ic[3] = new It(in[18]);
            ic[4] = new It(in[19]);
            ic[5] = new It(in[20]);
            ic[6] = new It(in[21]);
            ic[7] = new It(in[22]);
            ic[8] = new It(in[23]);
            for (join::Join c(ic, VSIZE); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), a.Child(2)); // c<d
                id[1] = new It(b.Child(2));
                id[2] = new It(c.Child(2));
                id[3] = new It(in[24]);
                id[4] = new It(in[25]);
                id[5] = new It(in[26]);
                id[6] = new It(in[27]);
                id[7] = new It(in[28]);
                id[8] = new It(in[29]);
                for (join::Join d(id, VSIZE); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Value(), a.Child(3)); // d<e
                    ie[1] = new It(b.Child(3));
                    ie[2] = new It(c.Child(3));
                    ie[3] = new It(d.Child(3));
                    ie[4] = new It(in[30]);
                    ie[5] = new It(in[31]);
                    ie[6] = new It(in[32]);
                    ie[7] = new It(in[33]);
                    ie[8] = new It(in[34]);
                    for (join::Join e(ie, VSIZE); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Value(), a.Child(4)); // e<f
                        iif[1] = new It(b.Child(4));
                        iif[2] = new It(c.Child(4));
                        iif[3] = new It(d.Child(4));
                        iif[4] = new It(e.Child(4));
                        iif[5] = new It(in[35]);
                        iif[6] = new It(in[36]);
                        iif[7] = new It(in[37]);
                        iif[8] = new It(in[38]);
                        for (join::Join f(iif, VSIZE); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Value(), a.Child(5)); // f<g
                            ig[1] = new It(b.Child(5));
                            ig[2] = new It(c.Child(5));
                            ig[3] = new It(d.Child(5));
                            ig[4] = new It(e.Child(5));
                            ig[5] = new It(f.Child(5));
                            ig[6] = new It(in[39]);
                            ig[7] = new It(in[40]);
                            ig[8] = new It(in[41]);
                            for (join::Join g(ig, VSIZE); g.InRange();
                                    g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(g.Value(), a.Child(6)); // g<h
                                ih[1] = new It(b.Child(6));
                                ih[2] = new It(c.Child(6));
                                ih[3] = new It(d.Child(6));
                                ih[4] = new It(e.Child(6));
                                ih[5] = new It(f.Child(6));
                                ih[6] = new It(g.Child(6));
                                ih[7] = new It(in[42]);
                                ih[8] = new It(in[43]);
                                for (join::Join h(ih, VSIZE); h.InRange();
                                        h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(h.Value(), a.Child(7)); // h<i
                                    ii[1] = new It(b.Child(7));
                                    ii[2] = new It(c.Child(7));
                                    ii[3] = new It(d.Child(7));
                                    ii[4] = new It(e.Child(7));
                                    ii[5] = new It(f.Child(7));
                                    ii[6] = new It(g.Child(7));
                                    ii[7] = new It(h.Child(7));
                                    ii[8] = new It(in[44]);
                                    for (join::Join i(ii, VSIZE); i.InRange();
                                            i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        ij[0] = new It(i.Value(), a.Child(8)); // i<j
                                        ij[1] = new It(b.Child(8));
                                        ij[2] = new It(c.Child(8));
                                        ij[3] = new It(d.Child(8));
                                        ij[4] = new It(e.Child(8));
                                        ij[5] = new It(f.Child(8));
                                        ij[6] = new It(g.Child(8));
                                        ij[7] = new It(h.Child(8));
                                        ij[8] = new It(i.Child(8));
                                        for (join::Join j(ij, VSIZE);
                                                j.InRange(); j.Next()) {
                                            AddOne(COUNTER_LOOP_9);
                                            node_i.Append(j.Value());
                                        }
                                        node_h.Append(i.Value(), node_i);
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

uint64_t c_abcdefghij_ab_ac_ad_ae_af_ag_ah_ai_aj_bc_bd_be_bf_bg_bh_bi_bj_cd_ce_cf_cg_ch_ci_cj_de_df_dg_dh_di_dj_ef_eg_eh_ei_ej_fg_fh_fi_fj_gh_gi_gj_hi_hj_ij__ab_bc_cd_de_ef_fg_gh_hi_ij(
        node_1d_t &in) {
    // 10-clique
    uint64_t counter = 0;
    const size_t VSIZE = 9;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]), new It(in[5]), new It(in[6]), new It(in[7]), new It(
                    in[8]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    It *ig[VSIZE];
    It *ih[VSIZE];
    It *ii[VSIZE];
    It *ij[VSIZE];
    for (join::Join a(ia, VSIZE); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Value(), a.Child(0)); // a<b
        ib[1] = new It(in[9]);
        ib[2] = new It(in[10]);
        ib[3] = new It(in[11]);
        ib[4] = new It(in[12]);
        ib[5] = new It(in[13]);
        ib[6] = new It(in[14]);
        ib[7] = new It(in[15]);
        ib[8] = new It(in[16]);
        for (join::Join b(ib, VSIZE); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Value(), a.Child(1)); // b<c
            ic[1] = new It(b.Child(1));
            ic[2] = new It(in[17]);
            ic[3] = new It(in[18]);
            ic[4] = new It(in[19]);
            ic[5] = new It(in[20]);
            ic[6] = new It(in[21]);
            ic[7] = new It(in[22]);
            ic[8] = new It(in[23]);
            for (join::Join c(ic, VSIZE); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Value(), a.Child(2)); // c<d
                id[1] = new It(b.Child(2));
                id[2] = new It(c.Child(2));
                id[3] = new It(in[24]);
                id[4] = new It(in[25]);
                id[5] = new It(in[26]);
                id[6] = new It(in[27]);
                id[7] = new It(in[28]);
                id[8] = new It(in[29]);
                for (join::Join d(id, VSIZE); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Value(), a.Child(3)); // d<e
                    ie[1] = new It(b.Child(3));
                    ie[2] = new It(c.Child(3));
                    ie[3] = new It(d.Child(3));
                    ie[4] = new It(in[30]);
                    ie[5] = new It(in[31]);
                    ie[6] = new It(in[32]);
                    ie[7] = new It(in[33]);
                    ie[8] = new It(in[34]);
                    for (join::Join e(ie, VSIZE); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Value(), a.Child(4)); // e<f
                        iif[1] = new It(b.Child(4));
                        iif[2] = new It(c.Child(4));
                        iif[3] = new It(d.Child(4));
                        iif[4] = new It(e.Child(4));
                        iif[5] = new It(in[35]);
                        iif[6] = new It(in[36]);
                        iif[7] = new It(in[37]);
                        iif[8] = new It(in[38]);
                        for (join::Join f(iif, VSIZE); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Value(), a.Child(5)); // f<g
                            ig[1] = new It(b.Child(5));
                            ig[2] = new It(c.Child(5));
                            ig[3] = new It(d.Child(5));
                            ig[4] = new It(e.Child(5));
                            ig[5] = new It(f.Child(5));
                            ig[6] = new It(in[39]);
                            ig[7] = new It(in[40]);
                            ig[8] = new It(in[41]);
                            for (join::Join g(ig, VSIZE); g.InRange();
                                    g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(g.Value(), a.Child(6)); // g<h
                                ih[1] = new It(b.Child(6));
                                ih[2] = new It(c.Child(6));
                                ih[3] = new It(d.Child(6));
                                ih[4] = new It(e.Child(6));
                                ih[5] = new It(f.Child(6));
                                ih[6] = new It(g.Child(6));
                                ih[7] = new It(in[42]);
                                ih[8] = new It(in[43]);
                                for (join::Join h(ih, VSIZE); h.InRange();
                                        h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(h.Value(), a.Child(7)); // h<i
                                    ii[1] = new It(b.Child(7));
                                    ii[2] = new It(c.Child(7));
                                    ii[3] = new It(d.Child(7));
                                    ii[4] = new It(e.Child(7));
                                    ii[5] = new It(f.Child(7));
                                    ii[6] = new It(g.Child(7));
                                    ii[7] = new It(h.Child(7));
                                    ii[8] = new It(in[44]);
                                    for (join::Join i(ii, VSIZE); i.InRange();
                                            i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        ij[0] = new It(i.Value(), a.Child(8)); // i<j
                                        ij[1] = new It(b.Child(8));
                                        ij[2] = new It(c.Child(8));
                                        ij[3] = new It(d.Child(8));
                                        ij[4] = new It(e.Child(8));
                                        ij[5] = new It(f.Child(8));
                                        ij[6] = new It(g.Child(8));
                                        ij[7] = new It(h.Child(8));
                                        ij[8] = new It(i.Child(8));
                                        for (join::Join j(ij, VSIZE);
                                                j.InRange(); j.Next()) {
                                            AddOne(COUNTER_LOOP_9);
                                            counter++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return counter;
}

Node *abcdefghij_abc_abd_abe_abf_abg_abh_abi_abj_cde_cdf_cdg_cdh_cdi_cdj_efg_efh_efi_efj_ghi_ghj_hij(
        node_1d_t &in) {
    // 10-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    Node node_i(MAX_DEGREE);
    It *ia[8] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]), new It(in[5]), new It(in[6]), new It(in[7]) };
    It *ib[8];
    It *ic[7];
    It *id[7];
    It *ie[6];
    It *iif[6];
    It *ig[5];
    It *ih[6];
    It *ii[5];
    It *ij[5];
    for (join::Join a(ia, 8); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abc.b
        ib[1] = new It(a.Child(1)); // abd.b
        ib[2] = new It(a.Child(2)); // abe.b
        ib[3] = new It(a.Child(3)); // abf.b
        ib[4] = new It(a.Child(4)); // abg.b
        ib[5] = new It(a.Child(5)); // abh.b
        ib[6] = new It(a.Child(6)); // abi.b
        ib[7] = new It(a.Child(7)); // abj.b
        for (join::Join b(ib, 8); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abc.c
            ic[1] = new It(in[8]); // cde.c
            ic[2] = new It(in[9]); // cdf.c
            ic[3] = new It(in[10]); // cdg.c
            ic[4] = new It(in[11]); // cdh.c
            ic[5] = new It(in[12]); // cdi.c
            ic[6] = new It(in[13]); // cdj.c
            for (join::Join c(ic, 7); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(b.Child(1)); // abd.d
                id[1] = new It(c.Child(1)); // cde.d
                id[2] = new It(c.Child(2)); // cdf.d
                id[3] = new It(c.Child(3)); // cdg.d
                id[4] = new It(c.Child(4)); // cdh.d
                id[5] = new It(c.Child(5)); // cdi.d
                id[6] = new It(c.Child(6)); // cdj.d
                for (join::Join d(id, 7); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(b.Child(2)); // abe.e
                    ie[1] = new It(d.Child(1)); // cde.e
                    ie[2] = new It(in[14]); // efg.e
                    ie[3] = new It(in[15]); // efh
                    ie[4] = new It(in[16]); // efi
                    ie[5] = new It(in[17]); // efj
                    for (join::Join e(ie, 6); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(b.Child(3)); // abf
                        iif[1] = new It(d.Child(2)); // cdf
                        iif[2] = new It(e.Child(2)); // efg
                        iif[3] = new It(e.Child(3)); // efh
                        iif[4] = new It(e.Child(4)); // efi
                        iif[5] = new It(e.Child(5)); // efj
                        for (join::Join f(iif, 6); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(b.Child(4)); // abg
                            ig[1] = new It(d.Child(3)); // cdg
                            ig[2] = new It(f.Child(2)); // efg
                            ig[3] = new It(in[18]); // ghi
                            ig[4] = new It(in[19]); // ghj
                            for (join::Join g(ig, 5); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(b.Child(5)); // abh
                                ih[1] = new It(d.Child(4)); // cdh
                                ih[2] = new It(f.Child(3)); // efh
                                ih[3] = new It(g.Child(3)); // ghi
                                ih[4] = new It(g.Child(4)); // ghj
                                ih[5] = new It(in[20]); // hij
                                for (join::Join h(ih, 6); h.InRange();
                                        h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(b.Child(6)); // abi
                                    ii[1] = new It(d.Child(5)); // cdi
                                    ii[2] = new It(f.Child(4)); // efi
                                    ii[3] = new It(h.Child(3)); // ghi
                                    ii[4] = new It(h.Child(5)); // hij
                                    for (join::Join i(ii, 5); i.InRange();
                                            i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        ij[0] = new It(b.Child(7)); // abj
                                        ij[1] = new It(d.Child(6)); // cdj
                                        ij[2] = new It(f.Child(5)); // efj
                                        ij[3] = new It(h.Child(4)); // ghj
                                        ij[4] = new It(i.Child(4)); // hij
                                        for (join::Join j(ij, 5); j.InRange();
                                                j.Next()) {
                                            AddOne(COUNTER_LOOP_9);
                                            node_i.Append(j.Value());
                                        }
                                        node_h.Append(i.Value(), node_i);
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefghij_abcd_abce_abcf_abcg_abch_abci_abcj_defg_defh_defi_defj_ghij(
        node_1d_t &in) {
    // 10-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    Node node_i(MAX_DEGREE);
    It *ia[7] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]), new It(in[5]), new It(in[6]) };
    It *ib[7];
    It *ic[7];
    It *id[5];
    It *ie[5];
    It *iif[5];
    It *ig[3];
    It *ih[3];
    It *ii[3];
    It *ij[3];
    for (join::Join a(ia, 7); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abcd.b
        ib[1] = new It(a.Child(1)); // abce.b
        ib[2] = new It(a.Child(2)); // abcf.b
        ib[3] = new It(a.Child(3)); // abcg.b
        ib[4] = new It(a.Child(4)); // abch.b
        ib[5] = new It(a.Child(5)); // abci.b
        ib[6] = new It(a.Child(6)); // abcj.b
        for (join::Join b(ib, 7); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abcd.c
            ic[1] = new It(b.Child(1)); // abce.c
            ic[2] = new It(b.Child(2)); // abcf.c
            ic[3] = new It(b.Child(3)); // abcg.c
            ic[4] = new It(b.Child(4)); // abch.c
            ic[5] = new It(b.Child(5)); // abci.c
            ic[6] = new It(b.Child(6)); // abcj.c
            for (join::Join c(ic, 7); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0)); // abcd.d
                id[1] = new It(in[7]); // defg
                id[2] = new It(in[8]); // defh
                id[3] = new It(in[9]); // defi
                id[4] = new It(in[10]); // defj
                for (join::Join d(id, 5); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(c.Child(1)); // abce
                    ie[1] = new It(d.Child(1)); // defg
                    ie[2] = new It(d.Child(2)); // defh
                    ie[3] = new It(d.Child(3)); // defi
                    ie[4] = new It(d.Child(4)); // defj
                    for (join::Join e(ie, 5); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(c.Child(2)); // abcf
                        iif[1] = new It(e.Child(1)); // defg
                        iif[2] = new It(e.Child(2)); // defh
                        iif[3] = new It(e.Child(3)); // defi
                        iif[4] = new It(e.Child(4)); // defj
                        for (join::Join f(iif, 5); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(c.Child(3)); // abcg
                            ig[1] = new It(f.Child(1)); // defg
                            ig[2] = new It(in[11]); // ghij
                            for (join::Join g(ig, 3); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(c.Child(4)); // abch
                                ih[1] = new It(f.Child(2)); // defh
                                ih[2] = new It(g.Child(2)); // ghij
                                for (join::Join h(ih, 3); h.InRange();
                                        h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(c.Child(5)); // abci
                                    ii[1] = new It(f.Child(3)); // defi
                                    ii[2] = new It(h.Child(2)); // ghij
                                    for (join::Join i(ii, 3); i.InRange();
                                            i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        ij[0] = new It(c.Child(6)); // abcj
                                        ij[1] = new It(f.Child(4)); // defj
                                        ij[2] = new It(i.Child(2)); // ghij
                                        for (join::Join j(ij, 3); j.InRange();
                                                j.Next()) {
                                            AddOne(COUNTER_LOOP_9);
                                            node_i.Append(j.Value());
                                        }
                                        node_h.Append(i.Value(), node_i);
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefghij_abcde_abcdf_abcdg_abcdh_abcdi_abcdj_efghi_efghj_fghij(
        node_1d_t &in) {
    // 10-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    Node node_i(MAX_DEGREE);
    It *ia[6] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]), new It(in[5]) };
    It *ib[6];
    It *ic[6];
    It *id[6];
    It *ie[3];
    It *iif[4];
    It *ig[4];
    It *ih[4];
    It *ii[3];
    It *ij[3];
    for (join::Join a(ia, 6); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abcde.b
        ib[1] = new It(a.Child(1)); // abcdf.b
        ib[2] = new It(a.Child(2)); // abcdg.b
        ib[3] = new It(a.Child(3)); // abcdh.b
        ib[4] = new It(a.Child(4)); // abcdi.b
        ib[5] = new It(a.Child(5)); // abcdj.b
        for (join::Join b(ib, 6); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abcde.c
            ic[1] = new It(b.Child(1)); // abcdf.c
            ic[2] = new It(b.Child(2)); // abcdg.c
            ic[3] = new It(b.Child(3)); // abcdh.c
            ic[4] = new It(b.Child(4)); // abcdi.c
            ic[5] = new It(b.Child(5)); // abcdj.c
            for (join::Join c(ic, 6); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0)); // abcde.d
                id[1] = new It(c.Child(1)); // abcdf
                id[2] = new It(c.Child(2)); // abcdg
                id[3] = new It(c.Child(3)); // abcdh
                id[4] = new It(c.Child(4)); // abcdi
                id[5] = new It(c.Child(5)); // abcdj
                for (join::Join d(id, 6); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0)); // abcde
                    ie[1] = new It(in[6]); // efghi
                    ie[2] = new It(in[7]); // efghj
                    for (join::Join e(ie, 3); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(d.Child(1)); // abcdf
                        iif[1] = new It(e.Child(1)); // efghi
                        iif[2] = new It(e.Child(2)); // efghj
                        iif[3] = new It(in[8]); // fghij
                        for (join::Join f(iif, 4); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(d.Child(2)); // abcdg
                            ig[1] = new It(f.Child(1)); // efghi
                            ig[2] = new It(f.Child(2)); // efghj
                            ig[3] = new It(f.Child(3)); // fghij
                            for (join::Join g(ig, 4); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(d.Child(3)); // abcdh
                                ih[1] = new It(g.Child(1)); // efghi
                                ih[2] = new It(g.Child(2)); // efghj
                                ih[3] = new It(g.Child(3)); // fghij
                                for (join::Join h(ih, 4); h.InRange();
                                        h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(d.Child(4)); // abcdi
                                    ii[1] = new It(h.Child(1)); // efghi
                                    ii[2] = new It(h.Child(3)); // fghij
                                    for (join::Join i(ii, 3); i.InRange();
                                            i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        ij[0] = new It(d.Child(5)); // abcdj
                                        ij[1] = new It(h.Child(2)); // efghj
                                        ij[2] = new It(i.Child(2)); // fghij
                                        for (join::Join j(ij, 3); j.InRange();
                                                j.Next()) {
                                            AddOne(COUNTER_LOOP_9);
                                            node_i.Append(j.Value());
                                        }
                                        node_h.Append(i.Value(), node_i);
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefghij_abcdef_abcdeg_abcdeh_abcdei_abcdej_efghij(node_1d_t &in) {
    // 10-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    Node node_i(MAX_DEGREE);
    It *ia[5] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]),
            new It(in[4]) };
    It *ib[5];
    It *ic[5];
    It *id[5];
    It *ie[6];
    It *iif[2];
    It *ig[2];
    It *ih[2];
    It *ii[2];
    It *ij[2];
    for (join::Join a(ia, 5); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abcdef.b
        ib[1] = new It(a.Child(1)); // abcdeg.b
        ib[2] = new It(a.Child(2)); // abcdeh.b
        ib[3] = new It(a.Child(3)); // abcdei.b
        ib[4] = new It(a.Child(4)); // abcdej.b
        for (join::Join b(ib, 5); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abcdef.c
            ic[1] = new It(b.Child(1)); // abcdeg.c
            ic[2] = new It(b.Child(2)); // abcdeh.c
            ic[3] = new It(b.Child(3)); // abcdei.c
            ic[4] = new It(b.Child(4)); // abcdej.c
            for (join::Join c(ic, 5); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0)); // abcdef.d
                id[1] = new It(c.Child(1)); // abcdeg
                id[2] = new It(c.Child(2)); // abcdeh
                id[3] = new It(c.Child(3)); // abcdei
                id[4] = new It(c.Child(4)); // abcdej
                for (join::Join d(id, 5); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0)); // abcdef
                    ie[1] = new It(d.Child(1)); // abcdeg
                    ie[2] = new It(d.Child(2)); // abcdeh
                    ie[3] = new It(d.Child(3)); // abcdei
                    ie[4] = new It(d.Child(4)); // abcdej
                    ie[5] = new It(in[5]); // efghij
                    for (join::Join e(ie, 6); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Child(0)); // abcdef
                        iif[1] = new It(e.Child(5)); // efghij
                        for (JoinT f(iif); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(e.Child(1)); // abcdeg
                            ig[1] = new It(f.Child(1)); // efghij
                            for (JoinT g(ig); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(e.Child(2)); // abcdeh
                                ih[1] = new It(g.Child(1)); // efghij
                                for (JoinT h(ih); h.InRange(); h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(e.Child(3)); // abcdei
                                    ii[1] = new It(h.Child(1)); // efghij
                                    for (JoinT i(ii); i.InRange(); i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        ij[0] = new It(e.Child(4)); // abcdej
                                        ij[1] = new It(i.Child(1)); // efghij
                                        for (JoinT j(ij); j.InRange();
                                                j.Next()) {
                                            AddOne(COUNTER_LOOP_9);
                                            node_i.Append(j.Value());
                                        }
                                        node_h.Append(i.Value(), node_i);
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefghij_abcdefg_abcdefh_abcdefi_abcdefj_defghij(node_1d_t &in) {
    // 10-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    Node node_i(MAX_DEGREE);
    It *ia[4] { new It(in[0]), new It(in[1]), new It(in[2]), new It(in[3]) };
    It *ib[4];
    It *ic[4];
    It *id[5];
    It *ie[5];
    It *iif[5];
    It *ig[2];
    It *ih[2];
    It *ii[2];
    It *ij[2];
    for (join::Join a(ia, 4); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abcdefg.b
        ib[1] = new It(a.Child(1)); // abcdefh.b
        ib[2] = new It(a.Child(2)); // abcdefi.b
        ib[3] = new It(a.Child(3)); // abcdefj.b
        for (join::Join b(ib, 4); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abcdefg.c
            ic[1] = new It(b.Child(1)); // abcdefh.c
            ic[2] = new It(b.Child(2)); // abcdefi.c
            ic[3] = new It(b.Child(3)); // abcdefj.c
            for (join::Join c(ic, 4); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0)); // abcdefg.d
                id[1] = new It(c.Child(1)); // abcdefh
                id[2] = new It(c.Child(2)); // abcdefi
                id[3] = new It(c.Child(3)); // abcdefj
                id[4] = new It(in[4]); // defghij
                for (join::Join d(id, 5); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0)); // abcdefg
                    ie[1] = new It(d.Child(1)); // abcdefh
                    ie[2] = new It(d.Child(2)); // abcdefi
                    ie[3] = new It(d.Child(3)); // abcdefj
                    ie[4] = new It(d.Child(4)); // defghij
                    for (join::Join e(ie, 5); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Child(0)); // abcdefg
                        iif[1] = new It(e.Child(1)); // abcdefh
                        iif[2] = new It(e.Child(2)); // abcdefi
                        iif[3] = new It(e.Child(3)); // abcdefj
                        iif[4] = new It(e.Child(4)); // defghij
                        for (join::Join f(iif, 5); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Child(0)); // abcdefg
                            ig[1] = new It(f.Child(4)); // defghij
                            for (JoinT g(ig); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(f.Child(1)); // abcdefh
                                ih[1] = new It(g.Child(1)); // defghij
                                for (JoinT h(ih); h.InRange(); h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(f.Child(2)); // abcdefi
                                    ii[1] = new It(h.Child(1)); // defghij
                                    for (JoinT i(ii); i.InRange(); i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        ij[0] = new It(f.Child(3)); // abcdefj
                                        ij[1] = new It(i.Child(1)); // defghij
                                        for (JoinT j(ij); j.InRange();
                                                j.Next()) {
                                            AddOne(COUNTER_LOOP_9);
                                            node_i.Append(j.Value());
                                        }
                                        node_h.Append(i.Value(), node_i);
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefghij_abcdefgh_abcdefgi_abcdefgj_cdefghij(node_1d_t &in) {
    // 10-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    Node node_i(MAX_DEGREE);
    It *ia[3] { new It(in[0]), new It(in[1]), new It(in[2]) };
    It *ib[3];
    It *ic[4];
    It *id[4];
    It *ie[4];
    It *iif[4];
    It *ig[4];
    It *ih[2];
    It *ii[2];
    It *ij[2];
    for (join::Join a(ia, 3); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0)); // abcdefgh.b
        ib[1] = new It(a.Child(1)); // abcdefgi.b
        ib[2] = new It(a.Child(2)); // abcdefgj.b
        for (join::Join b(ib, 3); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0)); // abcdefgh.c
            ic[1] = new It(b.Child(1)); // abcdefgi.c
            ic[2] = new It(b.Child(2)); // abcdefgj.c
            ic[3] = new It(in[3]); // cdefghij.c
            for (join::Join c(ic, 4); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0)); // abcdefgh.d
                id[1] = new It(c.Child(1)); // abcdefgi
                id[2] = new It(c.Child(2)); // abcdefgj
                id[3] = new It(c.Child(3)); // cdefghij
                for (join::Join d(id, 4); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0)); // abcdefgh
                    ie[1] = new It(d.Child(1)); // abcdefgi
                    ie[2] = new It(d.Child(2)); // abcdefgj
                    ie[3] = new It(d.Child(3)); // cdefghij
                    for (join::Join e(ie, 4); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Child(0)); // abcdefgh
                        iif[1] = new It(e.Child(1)); // abcdefgi
                        iif[2] = new It(e.Child(2)); // abcdefgj
                        iif[3] = new It(e.Child(3)); // cdefghij
                        for (join::Join f(iif, 4); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Child(0)); // abcdefgh
                            ig[1] = new It(f.Child(1)); // abcdefgi
                            ig[2] = new It(f.Child(2)); // abcdefgj
                            ig[3] = new It(f.Child(3)); // cdefghij
                            for (join::Join g(ig, 4); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(g.Child(0)); // abcdefgh
                                ih[1] = new It(g.Child(3)); // cdefghij
                                for (JoinT h(ih); h.InRange(); h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(g.Child(1)); // abcdefgi
                                    ii[1] = new It(h.Child(1)); // cdefghij
                                    for (JoinT i(ii); i.InRange(); i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        ij[0] = new It(g.Child(2)); // abcdefgj
                                        ij[1] = new It(i.Child(1)); // cdefghij
                                        for (JoinT j(ij); j.InRange();
                                                j.Next()) {
                                            AddOne(COUNTER_LOOP_9);
                                            node_i.Append(j.Value());
                                        }
                                        node_h.Append(i.Value(), node_i);
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

Node *abcdefghij_abcdefghi_abcdefghj_ij__ij(node_1d_t &in) {
    // 10-clique
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
    Node node_e(MAX_DEGREE);
    Node node_f(MAX_DEGREE);
    Node node_g(MAX_DEGREE);
    Node node_h(MAX_DEGREE);
    Node node_i(MAX_DEGREE);
    const size_t VSIZE = 2;
    It *ia[VSIZE] { new It(in[0]), new It(in[1]) };
    It *ib[VSIZE];
    It *ic[VSIZE];
    It *id[VSIZE];
    It *ie[VSIZE];
    It *iif[VSIZE];
    It *ig[VSIZE];
    It *ih[VSIZE];
    It *ii[VSIZE];
    It *ij[VSIZE];
    for (JoinT a(ia); a.InRange(); a.Next()) {
        AddOne(COUNTER_LOOP_0);
        ib[0] = new It(a.Child(0));
        ib[1] = new It(a.Child(1));
        for (JoinT b(ib); b.InRange(); b.Next()) {
            AddOne(COUNTER_LOOP_1);
            ic[0] = new It(b.Child(0));
            ic[1] = new It(b.Child(1));
            for (JoinT c(ic); c.InRange(); c.Next()) {
                AddOne(COUNTER_LOOP_2);
                id[0] = new It(c.Child(0));
                id[1] = new It(c.Child(1));
                for (JoinT d(id); d.InRange(); d.Next()) {
                    AddOne(COUNTER_LOOP_3);
                    ie[0] = new It(d.Child(0));
                    ie[1] = new It(d.Child(1));
                    for (JoinT e(ie); e.InRange(); e.Next()) {
                        AddOne(COUNTER_LOOP_4);
                        iif[0] = new It(e.Child(0));
                        iif[1] = new It(e.Child(1));
                        for (JoinT f(iif); f.InRange(); f.Next()) {
                            AddOne(COUNTER_LOOP_5);
                            ig[0] = new It(f.Child(0));
                            ig[1] = new It(f.Child(1));
                            for (JoinT g(ig); g.InRange(); g.Next()) {
                                AddOne(COUNTER_LOOP_6);
                                ih[0] = new It(g.Child(0));
                                ih[1] = new It(g.Child(1));
                                for (JoinT h(ih); h.InRange(); h.Next()) {
                                    AddOne(COUNTER_LOOP_7);
                                    ii[0] = new It(h.Child(0));
                                    ii[1] = new It(in[2]);
                                    for (JoinT i(ii); i.InRange(); i.Next()) {
                                        AddOne(COUNTER_LOOP_8);
                                        ij[0] = new It(i.Value(), h.Child(1)); // i<j
                                        ij[1] = new It(i.Child(1));
                                        for (JoinT j(ij); j.InRange();
                                                j.Next()) {
                                            AddOne(COUNTER_LOOP_9);
                                            node_i.Append(j.Value());
                                        }
                                        node_h.Append(i.Value(), node_i);
                                    }
                                    node_g.Append(h.Value(), node_h);
                                }
                                node_f.Append(g.Value(), node_g);
                            }
                            node_e.Append(f.Value(), node_f);
                        }
                        node_d.Append(e.Value(), node_e);
                    }
                    node_c.Append(d.Value(), node_d);
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(a.Value(), node_a);
    }
    return result->ReSize();
}

// share-trie
Node *s_abc_ab_ac_bc0__bc(node_1d_t &in) {
    /* use shared trie
     * ab and ac are the same
     */
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    // Iterator on attribute b
    It *ib[1];
    It *ib0[1];
    // Iterator on attribute c
    It *ic[1];
    It *ic1[1];
    for (It ia(in[0]); ia.InRange(); ia.Next()) {
        ib[0] = new It(ia.GetNode());  // ab.b
        ib0[0] = new It(in[1]); // bc0.b
        for (JoinS0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new It(b.Value(), ia.GetNode()); // abc.c, b<c
            ic1[0] = new It(b.Child0(0)); // bc0.c
            for (JoinS1S c(ic, ic1); c.InRange(); c.Next()) {
                node_b.Append(c.Value());
            }
            node_a.Append(b.Value(), node_b);
        }
        result->Append(ia.Value(), node_a);
    }
    return result->ReSize();
}

Node *s_abcd_abc_abd_cd0__cd(node_1d_t &in) {
    /* use shared trie
     * abc and abd are the same
     */
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    // Iterator on attribute c
    It *ic[1];
    It *ic0[1];
    // Iterator on attribute d
    It *id[1];
    It *id1[1];
    for (It ia(in[0]); ia.InRange(); ia.Next()) {
        for (It ib(ia.GetNode()); ib.InRange(); ib.Next()) {
            ic[0] = new It(ib.GetNode()); // abc.c
            ic0[0] = new It(in[1]); // cd.c
            for (JoinS0 c(ic, ic0, 1); c.InRange(); c.Next()) {
                id[0] = new It(c.Value(), ib.GetNode()); // abd.d, c<d
                id1[0] = new It(c.Child0(0)); // cd.d
                for (JoinS1S d(id, id1); d.InRange(); d.Next()) {
                    node_c.Append(d.Value());
                }
                node_b.Append(c.Value(), node_c);
            }
            node_a.Append(ib.Value(), node_b);
        }
        result->Append(ia.Value(), node_a);
    }
    return result->ReSize();
}

uint64_t c_s_abcd_abc_abd_cd0__cd(node_1d_t &in) {
    /* use shared trie
     * abc and abd are the same
     */
    uint64_t counter = 0;
    // Iterator on attribute c
    It *ic[1];
    It *ic0[1];
    // Iterator on attribute d
    It *id[1];
    It *id1[1];
    for (It ia(in[0]); ia.InRange(); ia.Next()) {
        for (It ib(ia.GetNode()); ib.InRange(); ib.Next()) {
            ic[0] = new It(ib.GetNode()); // abc.c
            ic0[0] = new It(in[1]); // cd.c
            for (JoinS0 c(ic, ic0, 1); c.InRange(); c.Next()) {
                id[0] = new It(c.Value(), ib.GetNode()); // abd.d, c<d
                id1[0] = new It(c.Child0(0)); // cd.d
                for (JoinS1S d(id, id1); d.InRange(); d.Next()) {
                    counter++;
                }
            }
        }
    }
    return counter;
}

uint64_t c_s_abcde_abcd_abce_de0__de(node_1d_t &in) {
    /* counting use shared trie
     * abcd and abce are the same
     */
    uint64_t counter = 0;
    // Iterator on attribute d
    It *id[1];
    It *id0[1];
    // Iterator on attribute e
    It *ie[1];
    It *ie1[1];
    for (It ia(in[0]); ia.InRange(); ia.Next()) {
        for (It ib(ia.GetNode()); ib.InRange(); ib.Next()) {
            for (It ic(ib.GetNode()); ic.InRange(); ic.Next()) {
                id[0] = new It(ic.GetNode()); // abcd.d
                id0[0] = new It(in[1]); // de0.d
                for (JoinS0 d(id, id0, 1); d.InRange(); d.Next()) {
                    ie[0] = new It(d.Value(), ic.GetNode()); // abce.e, d<e
                    ie1[0] = new It(d.Child0(0)); // de0.e
                    for (JoinS1S e(ie, ie1); e.InRange(); e.Next()) {
                        counter++;
                    }
                }
            }
        }
    }
    return counter;
}

void CountByShare(node_1d_t &in, const std::string &name,
        const std::string &expression) {
    if (not COUNTING_EXPRESSION.count(expression)) {
        PrintLCTX(name << " CountByShare not found: " << expression);
        return;
    }
    utility::InitializeLoopCounter();
    const timepoint_t &start = utility::GetTimepoint();
    auto count = COUNTING_EXPRESSION.at(expression)(in);
    auto duration = utility::GetDuration(start);
    PrintCTX(name << " CountByShare duration(s)=" << duration);
    Print(" match_count=" << count);
    Print(" expression=" << expression << " ");
    utility::PrintLoopCounter(true);
}

void CountQuery(node_1d_t &in, const std::string &name,
        const std::string &expression) {
    if (not COUNTING_EXPRESSION.count(expression)) {
        PrintLCTX(name << " CountQuery not found: " << expression);
        return;
    }
    utility::InitializeLoopCounter();
    const timepoint_t &start = utility::GetTimepoint();
    auto count = COUNTING_EXPRESSION.at(expression)(in);
    auto duration = utility::GetDuration(start);
    PrintCTX(name << " CountQuery duration(s)=" << duration);
    Print(" match_count=" << count);
    Print(" expression=" << expression << " ");
    utility::PrintLoopCounter(true);
}

counting_map_t InitializeCountingExpression() {
    // counter expression does not start with c_
    counting_map_t e_map;
    e_map["c_0_11"] = c_0_11;
    e_map["c_abc_ab_ac_bc__ab_bc"] = c_abc_ab_ac_bc__ab_bc;
    e_map["c_abcd_ab_ac_ad_bc_bd_cd__ab_bc_cd"] =
            c_abcd_ab_ac_ad_bc_bd_cd__ab_bc_cd;
    e_map["c_abcd_abc_abd_cd__cd"] = c_abcd_abc_abd_cd__cd;
    e_map["c_abcde_ab_ac_ad_ae_bc_bd_be_cd_ce_de__ab_bc_cd_de"] =
            c_abcde_ab_ac_ad_ae_bc_bd_be_cd_ce_de__ab_bc_cd_de;
    e_map["c_abcdef_ab_ac_ad_ae_af_bc_bd_be_bf_cd_ce_cf_de_df_ef__ab_bc_cd_de_ef"] =
            c_abcdef_ab_ac_ad_ae_af_bc_bd_be_bf_cd_ce_cf_de_df_ef__ab_bc_cd_de_ef;
    e_map["c_abcdefg_ab_ac_ad_ae_af_ag_bc_bd_be_bf_bg_cd_ce_cf_cg_de_df_dg_ef_eg_fg__ab_bc_cd_de_ef_fg"] =
            c_abcdefg_ab_ac_ad_ae_af_ag_bc_bd_be_bf_bg_cd_ce_cf_cg_de_df_dg_ef_eg_fg__ab_bc_cd_de_ef_fg;
    e_map["c_abcdefgh_ab_ac_ad_ae_af_ag_ah_bc_bd_be_bf_bg_bh_cd_ce_cf_cg_ch_de_df_dg_dh_ef_eg_eh_fg_fh_gh__ab_bc_cd_de_ef_fg_gh"] =
            c_abcdefgh_ab_ac_ad_ae_af_ag_ah_bc_bd_be_bf_bg_bh_cd_ce_cf_cg_ch_de_df_dg_dh_ef_eg_eh_fg_fh_gh__ab_bc_cd_de_ef_fg_gh;
    e_map["c_abcdefghi_ab_ac_ad_ae_af_ag_ah_ai_bc_bd_be_bf_bg_bh_bi_cd_ce_cf_cg_ch_ci_de_df_dg_dh_di_ef_eg_eh_ei_fg_fh_fi_gh_gi_hi__ab_bc_cd_de_ef_fg_gh_hi"] =
            c_abcdefghi_ab_ac_ad_ae_af_ag_ah_ai_bc_bd_be_bf_bg_bh_bi_cd_ce_cf_cg_ch_ci_de_df_dg_dh_di_ef_eg_eh_ei_fg_fh_fi_gh_gi_hi__ab_bc_cd_de_ef_fg_gh_hi;
    e_map["c_abcdefghij_ab_ac_ad_ae_af_ag_ah_ai_aj_bc_bd_be_bf_bg_bh_bi_bj_cd_ce_cf_cg_ch_ci_cj_de_df_dg_dh_di_dj_ef_eg_eh_ei_ej_fg_fh_fi_fj_gh_gi_gj_hi_hj_ij__ab_bc_cd_de_ef_fg_gh_hi_ij"] =
            c_abcdefghij_ab_ac_ad_ae_af_ag_ah_ai_aj_bc_bd_be_bf_bg_bh_bi_bj_cd_ce_cf_cg_ch_ci_cj_de_df_dg_dh_di_dj_ef_eg_eh_ei_ej_fg_fh_fi_fj_gh_gi_gj_hi_hj_ij__ab_bc_cd_de_ef_fg_gh_hi_ij;
    e_map["c_s_abcd_abc_abd_cd0__cd"] = c_s_abcd_abc_abd_cd0__cd;
    e_map["c_s_abcde_abcd_abce_de0__de"] = c_s_abcde_abcd_abce_de0__de;
    return e_map;
}

expression_map_t InitializeMatchingExpressionMap() {
    expression_map_t e_map;
    e_map["abc_ab_bc_ac__ac"] = abc_ab_bc_ac__ac;
    e_map["abc_ab_ac_bc__ab_bc"] = abc_ab_ac_bc__ab_bc;
    e_map["abc_ab_bc_ac__ab_bc"] = abc_ab_bc_ac__ab_bc;
    e_map["abc_ab_bc_ac0__ac"] = abc_ab_bc_ac0__ac;
    e_map["abcd_abc_abd_cd__cd"] = abcd_abc_abd_cd__cd;
    e_map["abcd_abc_bcd_ad"] = abcd_abc_bcd_ad;
    e_map["abcd_abc_bcd_ad__ab"] = abcd_abc_bcd_ad__ab;
    e_map["abcd_ab_ac_ad_bc_bd_cd__ab_bc_cd"] =
            abcd_ab_ac_ad_bc_bd_cd__ab_bc_cd;
    e_map["abcde_ab_ac_ad_ae_bc_bd_be_cd_ce_de__ab_bc_cd_de"] =
            abcde_ab_ac_ad_ae_bc_bd_be_cd_ce_de__ab_bc_cd_de;
    e_map["abcde_abc_abd_abe_cde"] = abcde_abc_abd_abe_cde;
    e_map["abcde_abcd_abce_de__de"] = abcde_abcd_abce_de__de;
    e_map["abcdef_ab_ac_ad_ae_af_bc_bd_be_bf_cd_ce_cf_de_df_ef__ab_bc_cd_de_ef"] =
            abcdef_ab_ac_ad_ae_af_bc_bd_be_bf_cd_ce_cf_de_df_ef__ab_bc_cd_de_ef;
    e_map["abcdef_abc_abd_abe_abf_cde_cdf_def"] =
            abcdef_abc_abd_abe_abf_cde_cdf_def;
    e_map["abcdef_abcd_abce_abcf_cdef"] = abcdef_abcd_abce_abcf_cdef;
    e_map["abcdef_abcde_abcdf_ef__ef"] = abcdef_abcde_abcdf_ef__ef;
    e_map["abcdefg_ab_ac_ad_ae_af_ag_bc_bd_be_bf_bg_cd_ce_cf_cg_de_df_dg_ef_eg_fg__ab_bc_cd_de_ef_fg"] =
            abcdefg_ab_ac_ad_ae_af_ag_bc_bd_be_bf_bg_cd_ce_cf_cg_de_df_dg_ef_eg_fg__ab_bc_cd_de_ef_fg;
    e_map["abcdefg_abc_abd_abe_abf_abg_cde_cdf_cdg_efg"] =
            abcdefg_abc_abd_abe_abf_abg_cde_cdf_cdg_efg;
    e_map["abcdefg_abcd_abce_abcf_abcg_defg"] =
            abcdefg_abcd_abce_abcf_abcg_defg;
    e_map["abcdefg_abcde_abcdf_abcdg_cdefg"] = abcdefg_abcde_abcdf_abcdg_cdefg;
    e_map["abcdefg_abcdef_abcdeg_fg__fg"] = abcdefg_abcdef_abcdeg_fg__fg;
    e_map["abcdefgh_ab_ac_ad_ae_af_ag_ah_bc_bd_be_bf_bg_bh_cd_ce_cf_cg_ch_de_df_dg_dh_ef_eg_eh_fg_fh_gh__ab_bc_cd_de_ef_fg_gh"] =
            abcdefgh_ab_ac_ad_ae_af_ag_ah_bc_bd_be_bf_bg_bh_cd_ce_cf_cg_ch_de_df_dg_dh_ef_eg_eh_fg_fh_gh__ab_bc_cd_de_ef_fg_gh;
    e_map["abcdefgh_abc_abd_abe_abf_abg_abh_cde_cdf_cdg_cdh_efg_efh_fgh"] =
            abcdefgh_abc_abd_abe_abf_abg_abh_cde_cdf_cdg_cdh_efg_efh_fgh;
    e_map["abcdefgh_abcd_abce_abcf_abcg_abch_defg_defh_efgh"] =
            abcdefgh_abcd_abce_abcf_abcg_abch_defg_defh_efgh;
    e_map["abcdefgh_abcde_abcdf_abcdg_abcdh_defgh"] =
            abcdefgh_abcde_abcdf_abcdg_abcdh_defgh;
    e_map["abcdefgh_abcdef_abcdeg_abcdeh_cdefgh"] =
            abcdefgh_abcdef_abcdeg_abcdeh_cdefgh;
    e_map["abcdefgh_abcdefg_abcdefh_gh__gh"] = abcdefgh_abcdefg_abcdefh_gh__gh;
    e_map["abcdefghi_ab_ac_ad_ae_af_ag_ah_ai_bc_bd_be_bf_bg_bh_bi_cd_ce_cf_cg_ch_ci_de_df_dg_dh_di_ef_eg_eh_ei_fg_fh_fi_gh_gi_hi__ab_bc_cd_de_ef_fg_gh_hi"] =
            abcdefghi_ab_ac_ad_ae_af_ag_ah_ai_bc_bd_be_bf_bg_bh_bi_cd_ce_cf_cg_ch_ci_de_df_dg_dh_di_ef_eg_eh_ei_fg_fh_fi_gh_gi_hi__ab_bc_cd_de_ef_fg_gh_hi;
    e_map["abcdefghi_abc_abd_abe_abf_abg_abh_abi_cde_cdf_cdg_cdh_cdi_efg_efh_efi_ghi"] =
            abcdefghi_abc_abd_abe_abf_abg_abh_abi_cde_cdf_cdg_cdh_cdi_efg_efh_efi_ghi;
    e_map["abcdefghi_abcd_abce_abcf_abcg_abch_abci_defg_defh_defi_fghi"] =
            abcdefghi_abcd_abce_abcf_abcg_abch_abci_defg_defh_defi_fghi;
    e_map["abcdefghi_abcde_abcdf_abcdg_abcdh_abcdi_efghi"] =
            abcdefghi_abcde_abcdf_abcdg_abcdh_abcdi_efghi;
    e_map["abcdefghi_abcdef_abcdeg_abcdeh_abcdei_defghi"] =
            abcdefghi_abcdef_abcdeg_abcdeh_abcdei_defghi;
    e_map["abcdefghi_abcdefg_abcdefh_abcdefi_cdefghi"] =
            abcdefghi_abcdefg_abcdefh_abcdefi_cdefghi;
    e_map["abcdefghi_abcdefgh_abcdefgi_hi__hi"] =
            abcdefghi_abcdefgh_abcdefgi_hi__hi;
    e_map["abcdefghij_ab_ac_ad_ae_af_ag_ah_ai_aj_bc_bd_be_bf_bg_bh_bi_bj_cd_ce_cf_cg_ch_ci_cj_de_df_dg_dh_di_dj_ef_eg_eh_ei_ej_fg_fh_fi_fj_gh_gi_gj_hi_hj_ij__ab_bc_cd_de_ef_fg_gh_hi_ij"] =
            abcdefghij_ab_ac_ad_ae_af_ag_ah_ai_aj_bc_bd_be_bf_bg_bh_bi_bj_cd_ce_cf_cg_ch_ci_cj_de_df_dg_dh_di_dj_ef_eg_eh_ei_ej_fg_fh_fi_fj_gh_gi_gj_hi_hj_ij__ab_bc_cd_de_ef_fg_gh_hi_ij;
    e_map["abcdefghij_abc_abd_abe_abf_abg_abh_abi_abj_cde_cdf_cdg_cdh_cdi_cdj_efg_efh_efi_efj_ghi_ghj_hij"] =
            abcdefghij_abc_abd_abe_abf_abg_abh_abi_abj_cde_cdf_cdg_cdh_cdi_cdj_efg_efh_efi_efj_ghi_ghj_hij;
    e_map["abcdefghij_abcd_abce_abcf_abcg_abch_abci_abcj_defg_defh_defi_defj_ghij"] =
            abcdefghij_abcd_abce_abcf_abcg_abch_abci_abcj_defg_defh_defi_defj_ghij;
    e_map["abcdefghij_abcde_abcdf_abcdg_abcdh_abcdi_abcdj_efghi_efghj_fghij"] =
            abcdefghij_abcde_abcdf_abcdg_abcdh_abcdi_abcdj_efghi_efghj_fghij;
    e_map["abcdefghij_abcdef_abcdeg_abcdeh_abcdei_abcdej_efghij"] =
            abcdefghij_abcdef_abcdeg_abcdeh_abcdei_abcdej_efghij;
    e_map["abcdefghij_abcdefg_abcdefh_abcdefi_abcdefj_defghij"] =
            abcdefghij_abcdefg_abcdefh_abcdefi_abcdefj_defghij;
    e_map["abcdefghij_abcdefgh_abcdefgi_abcdefgj_cdefghij"] =
            abcdefghij_abcdefgh_abcdefgi_abcdefgj_cdefghij;
    e_map["abcdefghij_abcdefghi_abcdefghj_ij__ij"] =
            abcdefghij_abcdefghi_abcdefghj_ij__ij;
    e_map["s_abc_ab_ac_bc0__bc"] = s_abc_ab_ac_bc0__bc;
    e_map["s_abcd_abc_abd_cd0__cd"] = s_abcd_abc_abd_cd0__cd;
    return e_map;
}

Node *MatchByShare(node_1d_t &in, const std::string &name,
        const std::string &expression) {
    if (not MATCHING_EXPRESSION.count(expression)) {
        PrintLCTX(name << " MatchQuery not found: " << expression);
        return nullptr;
    }
    utility::InitializeLoopCounter();
    const timepoint_t &start = utility::GetTimepoint();
    auto *result = MATCHING_EXPRESSION.at(expression)(in);
    auto duration = utility::GetDuration(start);
    auto count = result->CountLeaf();
    PrintCTX(name << " MatchByShare duration(s)=" << duration);
    Print(" match_count=" << count);
    Print(" expression=" << expression << " ");
    utility::PrintLoopCounter(true);
    return result;
}

Node *MatchQuery(node_1d_t &in, const std::string &name,
        const std::string &expression) {
    if (not MATCHING_EXPRESSION.count(expression)) {
        PrintLCTX(name << " MatchQuery not found: " << expression);
        return nullptr;
    }
    utility::InitializeLoopCounter();
    const timepoint_t &start = utility::GetTimepoint();
    auto *result = MATCHING_EXPRESSION.at(expression)(in);
    auto duration = utility::GetDuration(start);
    auto count = result->CountLeaf();
    PrintCTX(name << " MatchQuery duration(s)=" << duration);
    Print(" match_count=" << count);
    Print(" expression=" << expression << " ");
    utility::PrintLoopCounter(true);
    return result;
}

void SetDegreeSize(const vid_t max_degree, const vid_t vertex_size) {
    MAX_DEGREE = max_degree;
    VERTEX_SIZE = vertex_size;
}

counting_map_t COUNTING_EXPRESSION = InitializeCountingExpression();
expression_map_t MATCHING_EXPRESSION = InitializeMatchingExpressionMap();

} // namespace adhoc

} //namespace compile

} // namespace sorttrie
