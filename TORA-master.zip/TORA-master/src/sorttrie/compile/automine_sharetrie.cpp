/*
 * automine_sharetrie.cpp
 *
 *  Created on: Thursday 13:52 PM 2023-4-6
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <fstream>
#include <string>
#include <vector>

#include "include/common.hpp"
#include "include/sorttrie/compile/automine_sharetrie.hpp"
#include "include/sorttrie/graph.hpp"
#include "include/sorttrie/iterator.hpp"
#include "include/sorttrie/join/join.hpp"
#include "include/sorttrie/join/join0.hpp"
#include "include/sorttrie/join/join1s.hpp"
#include "include/sorttrie/join/joins.hpp"
#include "include/sorttrie/join/joins0.hpp"
#include "include/sorttrie/join/joins01s.hpp"
#include "include/sorttrie/join/joins01t.hpp"
#include "include/sorttrie/join/joins1.hpp"
#include "include/sorttrie/join/joins1s.hpp"
#include "include/sorttrie/join/joins1t.hpp"
#include "include/sorttrie/join/joint.hpp"
#include "include/sorttrie/join/joint0.hpp"
#include "include/sorttrie/join/joint01s.hpp"
#include "include/sorttrie/join/joint01t.hpp"
#include "include/sorttrie/join/joint1s.hpp"
#include "include/sorttrie/join/joint1t.hpp"
#include "include/sorttrie/node.hpp"
#include "include/utility/clock.hpp"
#include "include/utility/config.hpp"
#include "include/utility/logger.hpp"

namespace sorttrie {

namespace compile {

namespace automine_sharetrie {

// local typedef
typedef typename join::Join Join;
typedef typename join::Join0 Join0;
typedef typename join::Join1S Join1S;
typedef typename join::JoinS JoinS;
typedef typename join::JoinS0 JoinS0;
typedef typename join::JoinS01S JoinS01S;
typedef typename join::JoinS01T JoinS01T;
typedef typename join::JoinS1 JoinS1;
typedef typename join::JoinS1S JoinS1S;
typedef typename join::JoinS1T JoinS1T;
typedef typename join::JoinT JoinT;
typedef typename join::JoinT0 JoinT0;
typedef typename join::JoinT01S JoinT01S;
typedef typename join::JoinT1S JoinT1S;
typedef typename join::JoinT1T JoinT1T;

// local global variables used below. initialized on compile
uint64_t COUNTER = 0;
std::ofstream OUTPUT;

vid_t MAX_DEGREE;
vid_t VERTEX_SIZE;

/* https://stackoverflow.com/a/55020387 #ifdef condition
 * choose one of COUNTING, LISTING, MEMORY
 */
#if !defined(COUNTING) and defined(LISTING)
#define ResultAppendValueNode        (void (0))
#define NodeAppendValueNode(x, y, z) (void (0))
#define Inner3(a, b, c)              OUTPUT << a.Value() << " " << b.Value() << " " << c.Value() << std::endl
#define Inner4(a, b, c, d)           OUTPUT << a.Value() << " " << b.Value() << " " << c.Value() << " " << d.Value() << std::endl
#define Inner5(a, b, c, d, e)        OUTPUT << a.Value() << " " << b.Value() << " " << c.Value() << " " << d.Value() << " " << e.Value() << std::endl
#elif !defined(COUNTING) and defined(MEMORY)
#define ResultAppendValueNode        result->Append(a.Value(), node_a)
#define NodeAppendValueNode(x, y, z) x.Append(y.Value(), z)
#define Inner3(a, b, c)              node_b.Append(c.Value())
#define Inner4(a, b, c, d)           node_c.Append(d.Value())
#define Inner5(a, b, c, d, e)        node_d.Append(e.Value())
#else
// default COUNTING
#define ResultAppendValueNode        (void (0))
#define NodeAppendValueNode(x, y, z) (void (0))
#define Inner3(a, b, c)              COUNTER++
#define Inner4(a, b, c, d)           COUNTER++
#define Inner5(a, b, c, d, e)        COUNTER++
#endif

uint64_t After(Config &config, Node *result) {
#if !defined(COUNTING) and defined(LISTING)
    // counter lines in the output file
    std::ifstream in_file(config.SaveFile());
    return std::count(std::istreambuf_iterator<char>(in_file),
            std::istreambuf_iterator<char>(), '\n');
#elif !defined(COUNTING) and defined(MEMORY)
    return result->CountLeaf();
#endif
    return COUNTER;
}

bool Before(Config &config) {
    // return status. true: good. false: failure
#if !defined(COUNTING) and defined(LISTING)
    PrintLCTX("LISTING");
    const std::string &out_file = config.SaveFile();
    if (out_file.size()) {
        OUTPUT.open(out_file);
    } else {
        PrintLCTX("LISTING missing argument: " << Config::KeySaveFile);
        return false;
    }
#elif !defined(COUNTING) and defined(MEMORY)
    PrintLCTX("MEMORY");
#else
    PrintLCTX("Default: COUNTING");
    COUNTER = 0;
#endif
    return true;
}

// size 3
Node *Triangle_cba(std::vector<Node *> &in) {
    // also 3-clique, a-b-c-a, symmetry breaking c<b<a
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
#endif
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};// ab.a, ac.a
    // Iterator on b
    Iterator *ib[2];
    // Iterator on c
    Iterator *ic[2];
    for (JoinS a(ia); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b
        for (JoinT b(ib); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0), b.Value());// ac.c, c<b
            ic[1] = new Iterator(b.Child(1));// bc.c
            for (JoinT c(ic); c.InRange(); c.Next()) {
                Inner3(a, b, c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *TwoPath_cb(std::vector<Node *> &in) {
    // b-a-c, symmetry breaking c<b
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
#endif
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};// ab.a, ac.a
    // Iterator on b
    Iterator *ib[1];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[1];
    Iterator *ic1[1];
    for (JoinS a(ia); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0));// ab.b
        ib0[0] = new Iterator(in[1]);// bc.b
        for (JoinS0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0), b.Value());// ac.c, c<b
            ic1[0] = new Iterator(b.Child0(0));// bc.c
            for (JoinS1S c(ic, ic1); c.InRange(); c.Next()) {
                Inner3(a, b, c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

// size 4
Node *Diamond_ba_dc(std::vector<Node *> &in) {
    /* symmetry breaking b<a, d<c
     * a---c
     * | \ |
     * d---b
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // ab.a, ac.a, ad.a
    // Iterator on b
    Iterator *ib[2];
    // Iterator on c
    Iterator *ic[2];
    Iterator *ic0[1];
    // Iterator on d
    Iterator *id[2];
    Iterator *id1[1];
    for (JoinS a(ia); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b, bd.b
        for (JoinT b(ib); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic0[0] = new Iterator(in[1]);// cd.c
            for (JoinT0 c(ic, ic0, 1); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0), c.Value());// ad.d, d<c
                id[1] = new Iterator(b.Child(1));// bd.d
                id1[0] = new Iterator(c.Child0(0));// cd.d
                for (JoinT1S d(id, id1); d.InRange(); d.Next()) {
                    // leaf level
                    Inner4(a, b, c, d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    // call result->Resize() to save space
    // skip the call to save time
    return result;
#else
    return nullptr;
#endif
}

Node *FourClique_dcba(std::vector<Node *> &in) {
    /* symmetry breaking d<c<b<a
     * a----b
     * | \/ |
     * | /\ |
     * c----d
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // ab.a, ac.a, ad.a
    // Iterator on b
    Iterator *ib[2];
    // Iterator on c
    Iterator *ic[3];
    // Iterator on d
    Iterator *id[3];
    for (JoinS a(ia); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b, bd.b
        for (JoinT b(ib); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0), b.Value());// ac.c, c<b
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic[2] = new Iterator(in[0]);// cd.c
            for (Join c(ic, 3); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0), c.Value());// ad.d, d<c
                id[1] = new Iterator(b.Child(1));// bd.d
                id[2] = new Iterator(c.Child(2));// cd.d
                for (Join d(id, 3); d.InRange(); d.Next()) {
                    // leaf level
                    Inner4(a, b, c, d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    // call result->Resize() to save space
    // skip the call to save time
    return result;
#else
    return nullptr;
#endif
}

Node *FourCycle_cba_da(std::vector<Node *> &in) {
    /* a-b-d-c-a with symmetry breaking c<b<a, d<a
     * ib0: join on attribute b by negation at the root level
     * ic1: join on attribute c by negation at the leaf level
     *
     * a---b
     * |   |
     * c---d
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};// ab.a, ac.a
    Iterator *ia0[1] {new Iterator(in[1])};// ad.a
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];// attribute b is at the root level of negation
    // Iterator on c
    Iterator *ic[2];
    Iterator *ic1[1];// attribute c is at the leaf level of negation
    // Iterator on d
    Iterator *id[2];
    Iterator *id1[1];// attribute d is at the leaf level of negation
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bd.b
        ib0[0] = new Iterator(in[1]);// bc.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0), b.Value());// ac.c, c<b
            ic[1] = new Iterator(in[0]);// cd.c
            ic1[0] = new Iterator(b.Child0(0), b.Value());// bc.c
            for (JoinT1S c(ic, ic1); c.InRange(); c.Next()) {
                id[0] = new Iterator(b.Child(1), a.Value());// bd.d, d<a
                id[1] = new Iterator(c.Child(1));// cd.d
                id1[0] = new Iterator(a.Child0(0));// ad.d
                for (JoinT1S d(id, id1); d.InRange(); d.Next()) {
                    // leaf level
                    Inner4(a, b, c, d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    // call result->Resize() to save space
    // skip the call to save time
    return result;
#else
    return nullptr;
#endif
}

Node *TailedTriangle_ba(std::vector<Node *> &in) {
    /* symmetry breaking b<a
     * a---b
     *  \ /
     *   c
     *   |
     *   d
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};// ab.a, ac.a
    Iterator *ia0[1] {new Iterator(in[1])};// ad.a
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[3];
    // Iterator on d
    Iterator *id[1];
    Iterator *id1[2];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b
        ib0[0] = new Iterator(in[1]);// bd.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic[2] = new Iterator(in[0]);// cd.c
            for (Join c(ic, 3); c.InRange(); c.Next()) {
                id[0] = new Iterator(c.Child(2));// cd.d
                id1[0] = new Iterator(a.Child0(0));// ad.d
                id1[1] = new Iterator(b.Child0(0));// bd.d
                for (JoinS1T d(id, id1); d.InRange(); d.Next()) {
                    // leaf level
                    Inner4(a, b, c, d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    // call result->Resize() to save space
    // skip the call to save time
    return result;
#else
    return nullptr;
#endif
}

Node *ThreePath_ba(std::vector<Node *> &in) {
    /* a---b
     * |   |
     * c   d
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    Iterator *ia0[1] {new Iterator(in[1])};
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[1];
    Iterator *ic0[1];
    Iterator *ic1[1];
    // Iterator on d
    Iterator *id[1];
    Iterator *id1[2];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bd.b
        ib0[0] = new Iterator(in[1]);// bc.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic0[0] = new Iterator(in[1]);// cd.c
            ic1[0] = new Iterator(b.Child0(0));// bc.c
            for (JoinS01S c(ic, ic0, 1, ic1); c.InRange(); c.Next()) {
                id[0] = new Iterator(b.Child(1));// bd.d
                id1[0] = new Iterator(a.Child0(0));// ad.d
                id1[1] = new Iterator(c.Child0(0));// cd.d
                for (JoinS1T d(id, id1); d.InRange(); d.Next()) {
                    // leaf level
                    Inner4(a, b, c, d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    // call result->Resize() to save space
    // skip the call to save time
    return result;
#else
    return nullptr;
#endif
}

Node *ThreeStar_dcb(std::vector<Node *> &in) {
    /* a-b, a-c, a-d with symmetry breaking d<c<b
     *   b
     *   |
     *   a
     *  / \
     * c   d
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // ab.a, ac.a, ad.a
    // Iterator on b
    Iterator *ib[1];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[1];
    Iterator *ic0[1];
    Iterator *ic1[1];
    // Iterator on d
    Iterator *id[1];
    Iterator *id1[2];
    for (JoinS a(ia); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0));// ab.b
        ib0[0] = new Iterator(in[1]);// bc.b, bd.b
        for (JoinS0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0), b.Value());// ac.c, c<b
            ic0[0] = new Iterator(in[1]);// cd.c
            ic1[0] = new Iterator(b.Child0(0));// bc.c
            for (JoinS01S c(ic, ic0, 1, ic1); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0), c.Value());// ad.d, d<c
                id1[0] = new Iterator(b.Child0(0));// bd.d
                id1[1] = new Iterator(c.Child0(0));// cd.d
                for (JoinS1T d(id, id1); d.InRange(); d.Next()) {
                    // leaf level
                    Inner4(a, b, c, d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    // call result->Resize() to save space
    // skip the call to save time
    return result;
#else
    return nullptr;
#endif
}

// size 5
Node *AlmostFiveClique_cba_ed(std::vector<Node *> &in) {
    /* only (d, e) are not connected
     *   ---a---
     *  /  / \  \
     * b--/-- \--c
     * \ / \ / \ /
     *  d--/ \--e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // Iterator on b
    Iterator *ib[2];
    // Iterator on c
    Iterator *ic[3];
    // Iterator on d
    Iterator *id[3];
    Iterator *id0[1];
    // Iterator on e
    Iterator *ie[3];
    Iterator *ie1[1];
    for (JoinS a(ia); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b, bd.b, be.b
        for (JoinT b(ib); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0), b.Value());// ac.c, c<b
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic[2] = new Iterator(in[0]);// cd.c, ce.c
            for (Join c(ic, 3); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0));// ad.d
                id[1] = new Iterator(b.Child(1));// bd.d
                id[2] = new Iterator(c.Child(2));// cd.d
                id0[0] = new Iterator(in[1]);// de.d
                for (Join0 d(id, 3, id0, 1); d.InRange(); d.Next()) {
                    ie[0] = new Iterator(a.Child(0), d.Value());// ae.e, e<d
                    ie[1] = new Iterator(b.Child(1));// be.e
                    ie[2] = new Iterator(c.Child(2));// ce.e
                    ie1[0] = new Iterator(d.Child0(0));// de.e
                    for (Join1S e(ie, 3, ie1); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *Cobra_ba(std::vector<Node *> &in) {
    /*   c
     *  / \
     * a---b
     *  \ /
     *   d
     *   |
     *   e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // ab.a, ac.a, ad.a
    Iterator *ia0[1] {new Iterator(in[1])};// ae.a
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[2];
    Iterator *ic0[1];
    // Iterator on d
    Iterator *id[3];
    Iterator *id1[1];
    // Iterator on e
    Iterator *ie[1];
    Iterator *ie1[3];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b, bd.b
        ib0[0] = new Iterator(in[1]);// be.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic0[0] = new Iterator(in[1]);// cd.c, ce.c
            for (JoinT0 c(ic, ic0, 1); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0));// ad.d
                id[1] = new Iterator(b.Child(1));// bd.d
                id1[0] = new Iterator(c.Child0(0));// cd.d
                id[2] = new Iterator(in[0]);// de.d
                for (Join1S d(id, 3, id1); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie1[1] = new Iterator(b.Child0(0));// be.e
                    ie1[2] = new Iterator(c.Child0(0));// ce.e
                    ie[0] = new Iterator(d.Child(2));// de.e
                    for (JoinS1 e(ie, ie1, 3); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *DiamondWedgeCollision_ba_dc(std::vector<Node *> &in) {
    /*   a
     *  /|\
     * c-b-d
     *  \ /
     *   e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // ab.a, ac.a, ad.a
    Iterator *ia0[1] {new Iterator(in[1])};// ae.a
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[3];
    Iterator *ic0[1];
    // Iterator on d
    Iterator *id[3];
    Iterator *id1[1];
    // Iterator on e
    Iterator *ie[2];
    Iterator *ie1[2];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b, bd.b
        ib0[0] = new Iterator(in[1]);// be.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic0[0] = new Iterator(in[1]);// cd.c
            ic[2] = new Iterator(in[0]);// ce.c
            for (Join0 c(ic, 3, ic0, 1); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0), c.Value());// ad.d, d<c
                id[1] = new Iterator(b.Child(1));// bd.d
                id1[0] = new Iterator(c.Child0(0));// cd.d
                id[2] = new Iterator(in[0]);// de.d
                for (Join1S d(id, 3, id1); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie1[1] = new Iterator(b.Child0(0));// be.e
                    ie[0] = new Iterator(c.Child(2));// ce.e
                    ie[1] = new Iterator(d.Child(2));// de.e
                    for (JoinT1T e(ie, ie1); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *DoubleTailedTriangle_ba(std::vector<Node *> &in) {
    /*   c
     *  / \
     * a---b
     * |   |
     * d   e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // ab.a, ac.a, ad.a
    Iterator *ia0[1] {new Iterator(in[1])};// ae.a
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[2];
    Iterator *ic0[1];
    // Iterator on d
    Iterator *id[1];
    Iterator *id0[1];
    Iterator *id1[2];
    // Iterator on e
    Iterator *ie[1];
    Iterator *ie1[3];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b, be.b
        ib0[0] = new Iterator(in[1]);// bd.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic0[0] = new Iterator(in[1]);// cd.c, ce.c
            for (JoinT0 c(ic, ic0, 1); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0));// ad.d
                id1[0] = new Iterator(b.Child0(0));// bd.d
                id1[1] = new Iterator(c.Child0(0));// cd.d
                id0[0] = new Iterator(in[1]);// de.d
                for (JoinS01T d(id, id0, 1, id1); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie[0] = new Iterator(b.Child(1));// be.e
                    ie1[1] = new Iterator(c.Child0(0));// ce.e
                    ie1[2] = new Iterator(d.Child0(0));// de.e
                    for (JoinS1 e(ie, ie1, 3); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *FiveClique_edcba(std::vector<Node *> &in) {
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // ab.a, ac.a, ad.a, ae.a
    // Iterator on b
    Iterator *ib[2];
    // Iterator on c
    Iterator *ic[3];
    // Iterator on d
    Iterator *id[4];
    // Iterator on e
    Iterator *ie[4];
    for (JoinS a(ia); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b, bd.b, be.b
        for (JoinT b(ib); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0), b.Value());// ac.c, c<b
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic[2] = new Iterator(in[0]);// cd.c, ce.c
            for (Join c(ic, 3); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0), c.Value());// ad.d, d<c
                id[1] = new Iterator(b.Child(1));// bd.d
                id[2] = new Iterator(c.Child(2));// cd.d
                id[3] = new Iterator(in[0]);// de.d
                for (Join d(id, 4); d.InRange(); d.Next()) {
                    ie[0] = new Iterator(a.Child(0), d.Value());// ae.e, e<d
                    ie[1] = new Iterator(b.Child(1));// be.e
                    ie[2] = new Iterator(c.Child(2));// ce.e
                    ie[3] = new Iterator(d.Child(3));// de.e
                    for (Join e(ie, 4); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *FiveCycle_cba_da_ea(std::vector<Node *> &in) {
    /* a-----b
     * |     |
     * c--e--d
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};// ab.a, ac.a
    Iterator *ia0[1] {new Iterator(in[1])};// ad.a, ae.a
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[2];
    Iterator *ic0[1];
    Iterator *ic1[1];
    // Iterator on d
    Iterator *id[2];
    Iterator *id1[2];
    // Iterator on e
    Iterator *ie[2];
    Iterator *ie1[2];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib0[0] = new Iterator(in[1]);// bc.b, be.b
        ib[1] = new Iterator(in[0]);// bd.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0), b.Value());// ac.c, c<b
            ic1[0] = new Iterator(b.Child0(0));// bc.c
            ic0[0] = new Iterator(in[1]);// cd.c
            ic[1] = new Iterator(in[0]);// ce.c
            for (JoinT01S c(ic, ic0, 1, ic1); c.InRange(); c.Next()) {
                id1[0] = new Iterator(a.Child0(0));// ad.d
                id[0] = new Iterator(b.Child(1), a.Value());// bd.d, d<a
                id1[1] = new Iterator(c.Child0(0));// cd.d
                id[1] = new Iterator(in[0]);// de.d
                for (JoinT1T d(id, id1); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie1[1] = new Iterator(b.Child0(0));// be.e
                    ie[0] = new Iterator(c.Child(1), a.Value());// ce.e, e<a
                    ie[1] = new Iterator(d.Child(1));// de.e
                    for (JoinT1T e(ie, ie1); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *ForktailedTriangle_ba_ed(std::vector<Node *> &in) {
    /* a---b
     *  \ /
     *   c
     *  / \
     * d   e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};// ab.a, ac.a
    Iterator *ia0[1] {new Iterator(in[1])};// ad.a, ae.a
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[3];
    // Iterator on d
    Iterator *id[1];
    Iterator *id0[1];
    Iterator *id1[2];
    // Iterator on e
    Iterator *ie[1];
    Iterator *ie1[3];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b
        ib0[0] = new Iterator(in[1]);// bd.b, be.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic[2] = new Iterator(in[0]);// cd.c, ce.c
            for (Join c(ic, 3); c.InRange(); c.Next()) {
                id1[0] = new Iterator(a.Child0(0));// ad.d
                id1[1] = new Iterator(b.Child0(0));// bd.d
                id[0] = new Iterator(c.Child(2));// cd.d
                id0[0] = new Iterator(in[1]);// de.d
                for (JoinS01T d(id, id0, 1, id1); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie1[1] = new Iterator(b.Child0(0));// be.e
                    ie[0] = new Iterator(c.Child(2), d.Value());// ce.e, e<d
                    ie1[2] = new Iterator(d.Child0(0));// de.e
                    for (JoinS1 e(ie, ie1, 3); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *FourPath_cb(std::vector<Node *> &in) {
    // d-b-a-c-e
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};// ab.a, ac.a
    Iterator *ia0[1] {new Iterator(in[1])};// ad.a, ae.a
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[2];
    Iterator *ic0[1];
    Iterator *ic1[1];
    // Iterator on d
    Iterator *id[1];
    Iterator *id0[1];
    Iterator *id1[2];
    // Iterator on e
    Iterator *ie[1];
    Iterator *ie1[3];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0));// ab.b
        ib0[0] = new Iterator(in[1]);// bc.b, be.b
        ib[1] = new Iterator(in[0]);// bd.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0), b.Value());// ac.c, c<b
            ic1[0] = new Iterator(b.Child0(0));// bc.c
            ic0[0] = new Iterator(in[1]);// cd.c
            ic[1] = new Iterator(in[0]);// ce.c
            for (JoinT01S c(ic, ic0, 1, ic1); c.InRange(); c.Next()) {
                id1[0] = new Iterator(a.Child0(0));// ad.d
                id[0] = new Iterator(b.Child(1));// bd.d
                id1[1] = new Iterator(c.Child0(0));// cd.d
                id0[0] = new Iterator(in[1]);// de.d
                for (JoinS01T d(id, id0, 1, id1); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie1[1] = new Iterator(b.Child0(0));// be.e
                    ie[0] = new Iterator(c.Child(1));// ce.e
                    ie1[2] = new Iterator(d.Child0(0));// de.e
                    for (JoinS1 e(ie, ie1, 3); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *FourStar_edcb(std::vector<Node *> &in) {
    /*    c
     *    |
     * b--a--d
     *    |
     *    e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // Iterator on b
    Iterator *ib[1];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[1];
    Iterator *ic0[1];
    Iterator *ic1[1];
    // Iterator on d
    Iterator *id[1];
    Iterator *id0[1];
    Iterator *id1[2];
    // Iterator on e
    Iterator *ie[1];
    Iterator *ie1[3];
    for (JoinS a(ia); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0));// ab.b
        ib0[0] = new Iterator(in[1]);// bc.b, bd.b, be.b
        for (JoinS0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0), b.Value());// ac.c, c<b
            ic1[0] = new Iterator(b.Child0(0));// bc.c
            ic0[0] = new Iterator(in[1]);// cd.c, ce.c
            for (JoinS01S c(ic, ic0, 1, ic1); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0), c.Value());// ad.d, d<c
                id1[0] = new Iterator(b.Child0(0));// bd.d
                id1[1] = new Iterator(c.Child0(0));// cd.d
                id0[0] = new Iterator(in[1]);// de.d
                for (JoinS01T d(id, id0, 1, id1); d.InRange(); d.Next()) {
                    ie[0] = new Iterator(a.Child(0), d.Value());// ae.e, e<d
                    ie1[0] = new Iterator(b.Child0(0));// be.e
                    ie1[1] = new Iterator(c.Child0(0));// ce.e
                    ie1[2] = new Iterator(d.Child0(0));// de.e
                    for (JoinS1 e(ie, ie1, 3); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *FourWheel_dba_ea(std::vector<Node *> &in) {
    /*    a
     *  / | \
     * b--c--d
     *  \ | /
     *    e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    Iterator *ia0[1] {new Iterator(in[1])};
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[3];
    // Iterator on d
    Iterator *id[3];
    Iterator *id1[1];
    // Iterator on e
    Iterator *ie[3];
    Iterator *ie1[1];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b, be.b
        ib0[0] = new Iterator(in[1]);// bd.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic[2] = new Iterator(in[0]);// cd.c, ce.c
            for (Join c(ic, 3); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0), b.Value());// ad.d, d<b
                id1[0] = new Iterator(b.Child0(0));// bd.d
                id[1] = new Iterator(c.Child(2));// cd.d
                id[2] = new Iterator(in[0]);// de.d
                for (Join1S d(id, 3, id1); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie[0] = new Iterator(b.Child(1), a.Value());// be.e, e<a
                    ie[1] = new Iterator(c.Child(2));// ce.e
                    ie[2] = new Iterator(d.Child(2));// de.e
                    for (Join1S e(ie, 3, ie1); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *HattedFourClique_ba_ed(std::vector<Node *> &in) {
    /*   c
     *  / \
     * a---b
     * |\ /|
     * |/ \|
     * d---e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // ab.a, ac.a, ad.a, ae.a
    // Iterator on b
    Iterator *ib[2];
    // Iterator on c
    Iterator *ic[2];
    Iterator *ic0[1];
    // Iterator on d
    Iterator *id[3];
    Iterator *id1[1];
    // Iterator on e
    Iterator *ie[3];
    Iterator *ie1[1];
    for (JoinS a(ia); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b, bd.b, be.b
        for (JoinT b(ib); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic0[0] = new Iterator(in[1]);// cd.c, ce.c
            for (JoinT0 c(ic, ic0, 1); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0));// ad.d
                id[1] = new Iterator(b.Child(1));// bd.d
                id1[0] = new Iterator(c.Child0(0));// cd.d
                id[2] = new Iterator(in[0]);// de.d
                for (Join1S d(id, 3, id1); d.InRange(); d.Next()) {
                    ie[0] = new Iterator(a.Child(0), d.Value());// ae.e, e<d
                    ie[1] = new Iterator(b.Child(1));// be.e
                    ie1[0] = new Iterator(c.Child0(0));// ce.e
                    ie[2] = new Iterator(d.Child(2));// de.e
                    for (Join1S e(ie, 3, ie1); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *HattedFourCycle_ba(std::vector<Node *> &in) {
    /*   c
     *  / \
     * a---b
     * |   |
     * d---e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    Iterator *ia0[1] {new Iterator(in[1])};
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[2];
    Iterator *ic0[1];
    // Iterator on d
    Iterator *id[2];
    Iterator *id1[2];
    // Iterator on e
    Iterator *ie[2];
    Iterator *ie1[2];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b, be.b
        ib0[0] = new Iterator(in[1]);// bd.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic0[0] = new Iterator(in[1]);// cd.c, ce.c
            for (JoinT0 c(ic, ic0, 1); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0));// ad.d
                id1[0] = new Iterator(b.Child0(0));// bd.d
                id1[1] = new Iterator(c.Child0(0));// cd.d
                id[1] = new Iterator(in[0]);// de.d
                for (JoinT1T d(id, id1); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie[0] = new Iterator(b.Child(1));// be.e
                    ie1[1] = new Iterator(c.Child0(0));// ce.e
                    ie[1] = new Iterator(d.Child(1));// de.e
                    for (JoinT1T e(ie, ie1); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *Hourglass_ba_eda(std::vector<Node *> &in) {
    /* a---b
     *  \ /
     *   c
     *  / \
     * d---e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    Iterator *ia0[1] {new Iterator(in[1])};
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[3];
    // Iterator on d
    Iterator *id[2];
    Iterator *id1[2];
    // Iterator on e
    Iterator *ie[2];
    Iterator *ie1[2];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b
        ib0[0] = new Iterator(in[1]);// bd.b, be.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic[2] = new Iterator(in[0]);// cd.c, ce.c
            for (Join c(ic, 3); c.InRange(); c.Next()) {
                id1[0] = new Iterator(a.Child0(0));// ad.d
                id1[1] = new Iterator(b.Child0(0));// bd.d
                id[0] = new Iterator(c.Child(2), a.Value());// cd.d, d<a
                id[1] = new Iterator(in[0]);// de.d
                for (JoinT1T d(id, id1); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie1[1] = new Iterator(b.Child0(0));// be.e
                    ie[0] = new Iterator(c.Child(2), d.Value());// ce.e, e<d
                    ie[1] = new Iterator(d.Child(1));// de.e
                    for (JoinT1T e(ie, ie1); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *LongTailedTriangle_ba(std::vector<Node *> &in) {
    /* a---b
     *  \ /
     *   c
     *   |
     *   d
     *   |
     *   e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};// ab.a, ac.a
    Iterator *ia0[1] {new Iterator(in[1])};// ad.a, ae.a
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[3];
    Iterator *ic0[1];
    // Iterator on d
    Iterator *id[2];
    Iterator *id1[2];
    // Iterator on e
    Iterator *ie[1];
    Iterator *ie1[3];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b
        ib0[0] = new Iterator(in[1]);// bd.b, be.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic[2] = new Iterator(in[0]);// cd.c
            ic0[0] = new Iterator(in[1]);// ce.c
            for (Join0 c(ic, 3, ic0, 1); c.InRange(); c.Next()) {
                id1[0] = new Iterator(a.Child0(0));// ad.d
                id1[1] = new Iterator(b.Child0(0));// bd.d
                id[0] = new Iterator(c.Child(2));// cd.d
                id[1] = new Iterator(in[0]);// de.d
                for (JoinT1T d(id, id1); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie1[1] = new Iterator(b.Child0(0));// be.e
                    ie1[2] = new Iterator(c.Child0(0));// ce.e
                    ie[0] = new Iterator(d.Child(1));// de.e
                    for (JoinS1 e(ie, ie1, 3); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *Prong_dc(std::vector<Node *> &in) {
    /* c---a---d
     *     |
     *     b
     *     |
     *     e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // ab.a, ac.a, ad.a
    Iterator *ia0[1] {new Iterator(in[1])};// ae.a
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[1];
    Iterator *ic0[1];
    Iterator *ic1[1];
    // Iterator on d
    Iterator *id[1];
    Iterator *id0[1];
    Iterator *id1[2];
    // Iterator on e
    Iterator *ie[1];
    Iterator *ie1[3];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0));// ab.b
        ib0[0] = new Iterator(in[1]);// bc.b, bd.b
        ib[1] = new Iterator(in[0]);// be.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic1[0] = new Iterator(b.Child0(0));// bc.c
            ic0[0] = new Iterator(in[1]);// cd.c, ce.c
            for (JoinS01S c(ic, ic0, 1, ic1); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0), c.Value());// ad.d, d<c
                id1[0] = new Iterator(b.Child0(0));// bd.d
                id1[1] = new Iterator(c.Child0(0));// cd.d
                id0[0] = new Iterator(in[1]);// de.d
                for (JoinS01T d(id, id0, 1, id1); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie[0] = new Iterator(b.Child(1));// be.e
                    ie1[1] = new Iterator(c.Child0(0));// ce.e
                    ie1[2] = new Iterator(d.Child0(0));// de.e
                    for (JoinS1 e(ie, ie1, 3); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *Stingray_cb(std::vector<Node *> &in) {
    /*    a
     *  / | \
     * b  |  c
     *  \ | /
     *    d
     *    |
     *    e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // ab.a, ac.a, ad.a
    Iterator *ia0[1] {new Iterator(in[1])};// ae.a
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[2];
    Iterator *ic0[1];
    Iterator *ic1[1];
    // Iterator on d
    Iterator *id[4];
    // Iterator on e
    Iterator *ie[1];
    Iterator *ie1[3];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0));// ab.b
        ib0[0] = new Iterator(in[1]);// bc.b, be.b
        ib[1] = new Iterator(in[0]);// bd.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0), b.Value());// ac.c, c<b
            ic1[0] = new Iterator(b.Child0(0));// bc.c
            ic[1] = new Iterator(in[0]);// cd.c
            ic0[0] = new Iterator(in[1]);// ce.c
            for (JoinT01S c(ic, ic0, 1, ic1); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0));// ad.d
                id[1] = new Iterator(b.Child(1));// bd.d
                id[2] = new Iterator(c.Child(1));// cd.d
                id[3] = new Iterator(in[0]);// de.d
                for (Join d(id, 4); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie1[1] = new Iterator(b.Child0(0));// be.e
                    ie1[2] = new Iterator(c.Child0(0));// ce.e
                    ie[0] = new Iterator(d.Child(3));// de.e
                    for (JoinS1 e(ie, ie1, 3); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *TailedFourClique_cba(std::vector<Node *> &in) {
    /*    a
     *  / | \
     * b--|--c
     *  \ | /
     *    d
     *    |
     *    e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    Iterator *ia0[1] {new Iterator(in[1])};
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[3];
    Iterator *ic0[1];
    // Iterator on d
    Iterator *id[4];
    // Iterator on e
    Iterator *ie[1];
    Iterator *ie1[3];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b, bd.b
        ib0[0] = new Iterator(in[1]);// be.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0), b.Value());// ac.c, c<b
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic[2] = new Iterator(in[0]);// cd.c
            ic0[0] = new Iterator(in[1]);// ce.c
            for (Join0 c(ic, 3, ic0, 1); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0));// ad.d
                id[1] = new Iterator(b.Child(1));// bd.d
                id[2] = new Iterator(c.Child(2));// cd.d
                id[3] = new Iterator(in[0]);// de.d
                for (Join d(id, 4); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie1[1] = new Iterator(b.Child0(0));// be.e
                    ie1[2] = new Iterator(c.Child0(0));// ce.e
                    ie[0] = new Iterator(d.Child(3));// de.e
                    for (JoinS1 e(ie, ie1, 3); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *TailedFourCycle_ca(std::vector<Node *> &in) {
    /*   b
     *  / \
     * a   c
     *  \ /
     *   d
     *   |
     *   e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};// ab.a, ad.a
    Iterator *ia0[1] {new Iterator(in[1])};// ac.a, ae.a
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[2];
    Iterator *ic0[1];
    Iterator *ic1[1];
    // Iterator on d
    Iterator *id[3];
    Iterator *id1[1];
    // Iterator on e
    Iterator *ie[1];
    Iterator *ie1[3];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0));// ab.b
        ib[1] = new Iterator(in[0]);// bc.b
        ib0[0] = new Iterator(in[1]);// bd.b, be.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic1[0] = new Iterator(a.Child0(0));// ac.c
            ic[0] = new Iterator(b.Child(1), a.Value());// bc.c, c<a
            ic[1] = new Iterator(in[0]);// cd.c
            ic0[0] = new Iterator(in[1]);// ce.c
            for (JoinT01S c(ic, ic0, 1, ic1); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0));// ad.d
                id1[0] = new Iterator(b.Child0(0));// bd.d
                id[1] = new Iterator(c.Child(1));// cd.d
                id[2] = new Iterator(in[0]);// de.d
                for (Join1S d(id, 3, id1); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie1[1] = new Iterator(b.Child0(0));// be.e
                    ie1[2] = new Iterator(c.Child0(0));// ce.e
                    ie[0] = new Iterator(d.Child(2));// de.e
                    for (JoinS1 e(ie, ie1, 3); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *ThreeTriangleCollision_ba_edc(std::vector<Node *> &in) {
    /*     c
     *    / \
     *   / d \
     *  / / \ \
     * a ----- b
     *   \   /
     *     e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // ab.a, ac.a, ad.a, ae.a
    // Iterator on b
    Iterator *ib[2];
    // Iterator on c
    Iterator *ic[2];
    Iterator *ic0[2];
    // Iterator on d
    Iterator *id[2];
    Iterator *id0[1];
    Iterator *id1[1];
    // Iterator on e
    Iterator *ie[2];
    Iterator *ie1[2];
    for (JoinS a(ia); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b, bd.b, be.b
        for (JoinT b(ib); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic0[0] = new Iterator(in[1]);// cd.c
            ic0[1] = new Iterator(in[1]);// ce.c
            for (JoinT0 c(ic, ic0, 2); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0), c.Value());// ad.d, d<c
                id[1] = new Iterator(b.Child(1));// bd.d
                id1[0] = new Iterator(c.Child0(0));// cd.d
                id0[0] = new Iterator(in[1]);// de.d
                for (JoinT01S d(id, id0, 1, id1); d.InRange(); d.Next()) {
                    ie[0] = new Iterator(a.Child(0), d.Value());// ae.e, e<d
                    ie[1] = new Iterator(b.Child(1));// be.e
                    ie1[0] = new Iterator(c.Child0(1));// ce.e
                    ie1[1] = new Iterator(d.Child0(0));// de.e
                    for (JoinT1T e(ie, ie1); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *ThreeWedgeCollision_ca_edb(std::vector<Node *> &in) {
    /*
     * a---d
     * |\  |
     * | e |
     * |  \|
     * b---c
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // ab.a, ad.a, ae.a
    Iterator *ia0[1] {new Iterator(in[1])};// ac.a
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[2];
    Iterator *ic1[1];
    // Iterator on d
    Iterator *id[2];
    Iterator *id0[1];
    Iterator *id1[1];
    // Iterator on e
    Iterator *ie[2];
    Iterator *ie1[2];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0));// ab.b
        ib[1] = new Iterator(in[0]);// bc.b
        ib0[0] = new Iterator(in[1]);// bd.b, be.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic1[0] = new Iterator(a.Child0(0));// ac.c
            ic[0] = new Iterator(b.Child(1), a.Value());// bc.c, c<a
            ic[1] = new Iterator(in[0]);// cd.c, ce.c
            for (JoinT1S c(ic, ic1); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0), b.Value());// ad.d, d<b
                id1[0] = new Iterator(b.Child0(0));// bd.d
                id[1] = new Iterator(c.Child(1));// cd.d
                id0[0] = new Iterator(in[1]);// de.d
                for (JoinT01S d(id, id0, 1, id1); d.InRange(); d.Next()) {
                    ie[0] = new Iterator(a.Child(0), d.Value());// ae.e, e<d
                    ie1[0] = new Iterator(b.Child0(0));// be.e
                    ie[1] = new Iterator(c.Child(1));// ce.e
                    ie1[1] = new Iterator(d.Child0(0));// de.e
                    for (JoinT1T e(ie, ie1); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

Node *TriangleStrip_ba(std::vector<Node *> &in) {
    /*   a - b
     *  / \ / \
     * d - c - e
     */
#if !defined(COUNTING) and defined(MEMORY)
    Node *result = new Node(VERTEX_SIZE);
    Node node_a(MAX_DEGREE);
    Node node_b(MAX_DEGREE);
    Node node_c(MAX_DEGREE);
    Node node_d(MAX_DEGREE);
#endif
    // content inside this array of points are managed by Join
    // Iterator on a
    Iterator *ia[1] {new Iterator(in[0])};
    // ab.a, ac.a, ad.a
    Iterator *ia0[1] {new Iterator(in[1])};// ae.a
    // Iterator on b
    Iterator *ib[2];
    Iterator *ib0[1];
    // Iterator on c
    Iterator *ic[3];
    // Iterator on d
    Iterator *id[2];
    Iterator *id0[1];
    Iterator *id1[1];
    // Iterator on e
    Iterator *ie[2];
    Iterator *ie1[2];
    for (JoinS0 a(ia, ia0, 1); a.InRange(); a.Next()) {
        ib[0] = new Iterator(a.Child(0), a.Value());// ab.b, b<a
        ib[1] = new Iterator(in[0]);// bc.b, be.b
        ib0[0] = new Iterator(in[1]);// bd.b
        for (JoinT0 b(ib, ib0, 1); b.InRange(); b.Next()) {
            ic[0] = new Iterator(a.Child(0));// ac.c
            ic[1] = new Iterator(b.Child(1));// bc.c
            ic[2] = new Iterator(in[0]);// cd.c, ce.c
            for (Join c(ic, 3); c.InRange(); c.Next()) {
                id[0] = new Iterator(a.Child(0));// ad.d
                id1[0] = new Iterator(b.Child0(0));// bd.d
                id[1] = new Iterator(c.Child(2));// cd.d
                id0[0] = new Iterator(in[1]);// de.d
                for (JoinT01S d(id, id0, 1, id1); d.InRange(); d.Next()) {
                    ie1[0] = new Iterator(a.Child0(0));// ae.e
                    ie[0] = new Iterator(b.Child(1));// be.e
                    ie[1] = new Iterator(c.Child(2));// ce.e
                    ie1[1] = new Iterator(d.Child0(0));// de.e
                    for (JoinT1T e(ie, ie1); e.InRange(); e.Next()) {
                        // leaf level
                        Inner5(a, b, c, d, e);
                    }
                    NodeAppendValueNode(node_c, d, node_d);
                }
                NodeAppendValueNode(node_b, c, node_c);
            }
            NodeAppendValueNode(node_a, b, node_b);
        }
        ResultAppendValueNode;
    }
#if !defined(COUNTING) and defined(MEMORY)
    return result;
#else
    return nullptr;
#endif
}

// define here and compile only once
qname_set_t InitializeCliqueQuery() {
    // query that don't need non-edge
    qname_set_t q_set;
    q_set.insert("3-clique");
    q_set.insert("3-cycle");
    q_set.insert("triangle");
    q_set.insert("4-clique");
    q_set.insert("5-clique");
    q_set.insert("6-clique");
    return q_set;
}

expression_map_t InitializeQueryPlan() {
    /* hash key follows the GraphMiner.AutoMine repository
     * each query plan is executed in a,b,c,d,e,... order
     * vertex in the function name is the symmetry breaking, separated by _
     * cba_da means two symmetry breaking: c<b<a and d<a
     */
    expression_map_t e_map;
    e_map.reserve(100);
    // size 3
    e_map["triangle"] = Triangle_cba;
    e_map["2-path"] = TwoPath_cb;
    // size 4
    e_map["diamond"] = Diamond_ba_dc;
    e_map["4-clique"] = FourClique_dcba;
    e_map["4-cycle"] = FourCycle_cba_da;
    e_map["tailed-triangle"] = TailedTriangle_ba;
    e_map["3-path"] = ThreePath_ba;
    e_map["3-star"] = ThreeStar_dcb;
    // size 5
    e_map["almost-5-clique"] = AlmostFiveClique_cba_ed;
    e_map["cobra"] = Cobra_ba;
    e_map["diamond-wedge-collision"] = DiamondWedgeCollision_ba_dc;
    e_map["double-tailed-triangle"] = DoubleTailedTriangle_ba;
    e_map["5-clique"] = FiveClique_edcba;
    e_map["5-cycle"] = FiveCycle_cba_da_ea;
    e_map["forktailed-triangle"] = ForktailedTriangle_ba_ed;
    e_map["4-path"] = FourPath_cb;
    e_map["4-star"] = FourStar_edcb;
    e_map["4-wheel"] = FourWheel_dba_ea;
    e_map["hatted-4-clique"] = HattedFourClique_ba_ed;
    e_map["hatted-4-cycle"] = HattedFourCycle_ba;
    e_map["hourglass"] = Hourglass_ba_eda;
    e_map["long-tailed-triangle"] = LongTailedTriangle_ba;
    e_map["prong"] = Prong_dc;
    e_map["stingray"] = Stingray_cb;
    e_map["tailed-4-clique"] = TailedFourClique_cba;
    e_map["tailed-4-cycle"] = TailedFourCycle_ca;
    e_map["3-triangle-collision"] = ThreeTriangleCollision_ba_edc;
    e_map["3-wedge-collision"] = ThreeWedgeCollision_ca_edb;
    e_map["triangle-strip"] = TriangleStrip_ba;
    // alternative name
    e_map["house"] = HattedFourCycle_ba;
    e_map["pentagon"] = FiveCycle_cba_da_ea;
    e_map["rectangle"] = FourCycle_cba_da;
    return e_map;
}

// global variables used below. initialized on compile
qname_set_t CliqueQuery = InitializeCliqueQuery();
expression_map_t QUERY_PLAN = InitializeQueryPlan();

bool ExecuteByQueryName(Config &config, const Graph &g, Logger &logger) {
    // execute query by QueryName. pre-defined plans
    // return status. true: good, false: failure
    if (g.LabelSize() > 1) {
        if (config.IsLabeled()) {
            // non uniformly labeled graph (directed/undirected)
            PrintLCTX("not support labels. skip.");
        } else {
            // unlabeled directed graph
            PrintLCTX("not support directed graphs. skip.");
        }
        return false;
    }
    typedef utility::timepoint_t timepoint_t;
    const timepoint_t &start = utility::GetTimepoint();
    // initialize local global variable
    MAX_DEGREE = g.MaxDegree();
    VERTEX_SIZE = g.VertexSize();
    // create edge
    std::vector<Node *> in;
    in.push_back(g.Edge(0));
    // create non-edge if needed
    if (not CliqueQuery.count(config.QueryName())) {
        // not a clique query, then non-edge is needed
        std::vector<Node *> edge_1d;
        edge_1d.push_back(g.Edge(0));
        Node *non_edge = new Node(edge_1d, VERTEX_SIZE);
        in.push_back(non_edge);
    }
    if (QUERY_PLAN.count(config.QueryName())) {
        if (Before(config)) {
            Node *result = QUERY_PLAN[config.QueryName()](in);
            logger.DurationExecutionCompiled = utility::GetDuration(start);
            logger.MatchCount = After(config, result);
            PrintCTX("DurationExecutionCompiled(s)=");
            Print(logger.DurationExecutionCompiled << " MatchCount=");
            PrintLine(logger.MatchCount);
            return true;
        }
    } else {
        PrintLCTX("NotImplemented QueryName=" << config.QueryName());
    }
    return false;
}

} // namespace automine_sharetrie

} // namespace compile

} // namespace sorttrie

