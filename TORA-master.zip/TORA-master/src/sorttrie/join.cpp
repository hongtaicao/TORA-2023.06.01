/*
 * join.cpp
 *
 *  Created on: 10:39 AM Thursday 2023-3-2
 *      Author: Hongtai Cao
 */

#include <cassert>

#include "include/sorttrie/join.hpp"

namespace sorttrie {

#ifndef NDEBUG

namespace join {

// define global debug variable
vid_t VERTEX_SIZE;

} // namespace join

void AssertJoin0(Iterator **iterator0, vid_t size0) {
    // iterator0 should have size == VERTEX_SIZE
    for (vid_t ith = 0; ith < size0; ith++) {
        assert(iterator0[ith]->Size() == join::VERTEX_SIZE);
    }
}
#endif

} // namespace sorttrie
