/*
 * executejoin.cpp
 *
 *  Created on: 02:05 AM Saturday 2023-2-19
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <cassert>
#include <fstream>
#include <iostream>

#include "include/abstract/expression.hpp"
#include "include/abstract/operand.hpp"
#include "include/common.hpp"
#include "include/sorttrie/executejoin.hpp"
#include "include/sorttrie/iterator.hpp"
#include "include/sorttrie/join/join.hpp"
#include "include/sorttrie/join/join0.hpp"
#include "include/sorttrie/join/join01.hpp"
#include "include/sorttrie/join/join01s.hpp"
#include "include/sorttrie/join/join01t.hpp"
#include "include/sorttrie/join/join1.hpp"
#include "include/sorttrie/join/join1s.hpp"
#include "include/sorttrie/join/join1t.hpp"
#include "include/sorttrie/join/joins.hpp"
#include "include/sorttrie/join/joins0.hpp"
#include "include/sorttrie/join/joins01.hpp"
#include "include/sorttrie/join/joins01s.hpp"
#include "include/sorttrie/join/joins01t.hpp"
#include "include/sorttrie/join/joins1.hpp"
#include "include/sorttrie/join/joins1s.hpp"
#include "include/sorttrie/join/joins1t.hpp"
#include "include/sorttrie/join/joint.hpp"
#include "include/sorttrie/join/joint0.hpp"
#include "include/sorttrie/join/joint01.hpp"
#include "include/sorttrie/join/joint01s.hpp"
#include "include/sorttrie/join/joint01t.hpp"
#include "include/sorttrie/join/joint1.hpp"
#include "include/sorttrie/join/joint1s.hpp"
#include "include/sorttrie/join/joint1t.hpp"
#include "include/sorttrie/node.hpp"
#include "include/utility/utility.hpp"

namespace sorttrie {

// define local function
inline void AppendInternal(join_1d_t &join_1d, node_1d_t &node_1d) {
    /* should call the ReSize version that moves child into parent Node
     * used by Join and Rename
     * Append method guarantee non-empty
     * and it fails if Node has no child
     */
    DPrintCTX("append depth=" << join_1d.size() - 1 << " value=");
    DPrint(join_1d.back()->Value() << " child_size=");
    DPrintLine(node_1d[join_1d.size()]->Size());
    node_1d[join_1d.size() - 1]->Append(join_1d.back()->Value(),
            *(node_1d[join_1d.size()]));
    assert(node_1d[join_1d.size()]->HasChild() == false);
}

#ifdef NDEBUG
#define DPrintEdgeChildIterator(a, b, c, d, e, f)               (void (0))
#define DPrintEdgeInputIterator(a, b, c, d, e)                  (void (0))
#define DPrintJoin1d(a)                                         (void (0))
#define DPrintNonedgeChildIterator(a, b, c, d)                  (void (0))
#define DPrintNonedgeInputIterator(a, b, c)                     (void (0))
#else
void DPrintEdgeChildIterator(Iterator **iter, size_t iter_offset,
        size_t prev_index, vid_t low, size_t in_th, vid_t up) {
    DPrint("iter =" << iter + iter_offset << " [" << iter_offset);
    DPrint("]=new Iterator(" << low << ", " << "join_1d[" << prev_index);
    DPrintLine("]->Child("<< in_th << "), " << up << ");");
}

void DPrintEdgeInputIterator(Iterator **iter, size_t iter_offset, vid_t low,
        size_t in_th, vid_t up) {
    DPrint("iter =" << iter + iter_offset << " [" << iter_offset);
    DPrint("]=new Iterator(" << low << ", " << "in[" << in_th << "], "<< up);
    DPrintLine(");");
}

void DPrintJoin1d(const join_1d_t &join_1d) {
    if (join_1d.size()) {
        DPrintCTX("join_1d.size()=" << join_1d.size());
        DPrintLine(" back()->Value()=" << join_1d.back()->Value());
    }
}

void DPrintNonedgeChildIterator(Iterator **iter, size_t iter_offset,
        size_t prev_index, size_t in_th) {
    DPrint("iter1=" << iter + iter_offset << " [" << iter_offset);
    DPrint("]=new Iterator(join_1d[" << prev_index << "]" << "->Child0(");
    DPrintLine(in_th << ");");
}

void DPrintNonedgeInputIterator(Iterator **iter, size_t iter_offset,
        size_t in_th) {
    DPrint("iter0=" << iter + iter_offset << " [" << iter_offset);
    DPrintLine("]=new Iterator(in[" << in_th << "]);");
}
#endif

#if !defined(COUNTING) and defined(LISTING)

inline void CountResultInFile(const std::string &file_name, uint64_t &counter) {
    std::ifstream in_file(file_name);
    counter = std::count(std::istreambuf_iterator<char>(in_file),
            std::istreambuf_iterator<char>(), '\n');
}

#define ProcessInternal(a, b)               (void (0))
#define ProcessLeaf(a, b, c)                (void (0))

void SaveToFile(join_1d_t &join_1d, const value_t value,
        std::ofstream &outfile) {
    // save to file
    for (auto &join : join_1d) {
        outfile << join->Value() << " ";
    }
    outfile << value << std::endl;
}

#elif !defined(COUNTING) and defined(MEMORY)
// save to memory
#define CountResultInFile(a, b)             (void (0))
#define ProcessInternal(join_1d, node_1d)   AppendInternal(join_1d, node_1d)
#define ProcessLeaf(a, b, c)                c[b.size()]->Append(a->Value())
#define SaveToFile(a, b, c)                 (void (0))
#else
// default COUNTING
#define CountResultInFile(a, b)             (void (0))
#define ProcessInternal(a, b)               (void (0))
#define ProcessLeaf(a, b, c)                counter++
#define SaveToFile(a, b, c)                 (void (0))
#endif

void ExecuteJoin::Initialize(size_t parent_depth) {
    /* find none or all Join till the last attribute
     * return state: either join_1d_.empty() or join_1d_.size() == depth
     * pass parent_depth=0 will disable Append
     */
    assert(this->join_1d_.size());
    while (this->join_1d_.size() < this->depth_) {
        Join *next_join = this->InitializeIndex(this->join_1d_.size());
        if (next_join->InRange()) {
            this->join_1d_.push_back(next_join);
        } else {
            delete next_join;
            this->join_1d_.back()->Next();
            for (; not this->join_1d_.back()->InRange();
                    this->join_1d_.back()->Next()) {
                delete this->join_1d_.back();
                this->join_1d_.pop_back();
                if (this->join_1d_.empty()) {
                    /* explored all possible Join and no more result
                     * exit state join_1d_.empty()
                     */
                    return;
                }
                if (this->join_1d_.size() < parent_depth) {
                    /* Append subtree when a new parent Node is reached
                     * and is moving to Next()
                     * passing parent_depth = 0 can disable Append
                     * this is used for the initialization
                     */
                    parent_depth = this->join_1d_.size();
                    AppendInternal(this->join_1d_, this->node_1d_);
                }
            }
        }
    }
    // exit state join_1d_.size() == depth
}

Join *ExecuteJoin::InitializeIndex(size_t out_index) const {
    DPrintJoin1d(this->join_1d_);
    vid_t low = 0, up = this->vertex_size_;
    // guarantee that this->symbreak_low[out_index].empty() == true
    for (auto &index : this->symbreak_low_[out_index]) {
        low = std::max(low, this->join_1d_[index]->Value());
    }
    for (auto &index : this->symbreak_up_[out_index]) {
        up = std::min(up, this->join_1d_[index]->Value());
    }
    auto &join_vertex = this->join_vertex_1d_[out_index];
    auto iter = this->iterator_2d_ + this->offset_ * out_index;
    /* note the Iterator sequence, frequent goes first
     * iter, iter, iter ... repeat this->in_.size() times
     * iter0, iter0, iter0 ... repeat this->in_.size() times
     * iter1, iter1, iter1 ... repeat this->in_.size() times
     */
    DPrintCTX("out_index=" << out_index << " symbreak low=" << low);
    DPrint(" up=" << up << " offset=" << this->offset_ * out_index);
    DPrint(" join_1d.size()=" << this->join_1d_.size() << " size iter=");
    DPrint(join_vertex.iter_size << " iter0=" << join_vertex.iter0_size);
    DPrintLine(" iter1=" << join_vertex.iter1_size);
    for (auto &ti : join_vertex.type_index) {
        if (ti[0] == JoinVertex::Iter0_Type) {
            // Iterator over nonedge input Node
            iter[this->in_.size() + ti[1]] = new Iterator(this->in_[ti[3]]);
            DPrintNonedgeInputIterator(iter, this->in_.size() + ti[1], ti[3]);
        } else if (ti[0] == JoinVertex::Iter1_Type) {
            // Iterator over nonedge child Node
            iter[this->in_.size() + this->in_.size() + ti[1]] = new Iterator(
                    this->join_1d_[ti[4]]->Child0(ti[3]));
            DPrintNonedgeChildIterator(iter,
                    this->in_.size() + this->in_.size() + ti[1], ti[4], ti[3]);
        } else {
            // JoinVertex::IterIn_Type
            if (ti[2] == JoinVertex::IterIn_Type) {
                // edge input Node
                if (low > 0) {
                    if (up < this->vertex_size_) {
                        iter[ti[1]] = new Iterator(low, this->in_[ti[3]], up);
                    } else {
                        iter[ti[1]] = new Iterator(low, this->in_[ti[3]]);
                    }
                } else if (up < this->vertex_size_) {
                    iter[ti[1]] = new Iterator(this->in_[ti[3]], up);
                } else {
                    iter[ti[1]] = new Iterator(this->in_[ti[3]]);
                }
                DPrintEdgeInputIterator(iter, ti[1], low, ti[3], up);
            } else {
                // edge child Node
                auto node = this->join_1d_[ti[4]]->Child(ti[3]);
                if (low > 0) {
                    if (up < this->vertex_size_) {
                        iter[ti[1]] = new Iterator(low, node, up);
                    } else {
                        iter[ti[1]] = new Iterator(low, node);
                    }
                } else if (up < this->vertex_size_) {
                    iter[ti[1]] = new Iterator(node, up);
                } else {
                    iter[ti[1]] = new Iterator(node);
                }
                DPrintEdgeChildIterator(iter, ti[1], ti[4], low, ti[3], up);
            }
        }
    }
    // create new Join
    if (join_vertex.iter_size == 1) {
        if (join_vertex.iter0_size) {
            if (join_vertex.iter1_size == 0) {
                return new join::JoinS0(iter, iter + this->in_.size(),
                        join_vertex.iter0_size);
            } else if (join_vertex.iter1_size == 1) {
                auto iter0 = iter + this->in_.size();
                return new join::JoinS01S(iter, iter0, join_vertex.iter0_size,
                        iter0 + this->in_.size());
            } else if (join_vertex.iter1_size == 2) {
                auto iter0 = iter + this->in_.size();
                return new join::JoinS01T(iter, iter0, join_vertex.iter0_size,
                        iter0 + this->in_.size());
            } else {
                auto iter0 = iter + this->in_.size();
                return new join::JoinS01(iter, iter0, join_vertex.iter0_size,
                        iter0 + this->in_.size(), join_vertex.iter1_size);
            }
        }
        /* no root level negation
         * not possible to have iter_size=1, iter_size0=0 iter_size1=0
         */
        if (join_vertex.iter1_size == 1) {
            return new join::JoinS1S(iter,
                    iter + this->in_.size() + this->in_.size());
        } else if (join_vertex.iter1_size == 2) {
            return new join::JoinS1T(iter,
                    iter + this->in_.size() + this->in_.size());
        } else {
            assert(join_vertex.iter1_size > 2);
            return new join::JoinS1(iter,
                    iter + this->in_.size() + this->in_.size(),
                    join_vertex.iter1_size);
        }
    } else if (join_vertex.iter_size == 2) {
        if (join_vertex.iter0_size) {
            if (join_vertex.iter1_size == 0) {
                return new join::JoinT0(iter, iter + this->in_.size(),
                        join_vertex.iter0_size);
            } else if (join_vertex.iter1_size == 1) {
                auto iter0 = iter + this->in_.size();
                return new join::JoinT01S(iter, iter0, join_vertex.iter0_size,
                        iter0 + this->in_.size());
            } else if (join_vertex.iter1_size == 2) {
                auto iter0 = iter + this->in_.size();
                return new join::JoinT01T(iter, iter0, join_vertex.iter0_size,
                        iter0 + this->in_.size());
            } else {
                auto iter0 = iter + this->in_.size();
                return new join::JoinT01(iter, iter0, join_vertex.iter0_size,
                        iter0 + this->in_.size(), join_vertex.iter1_size);
            }
        }
        // no root level negation
        if (join_vertex.iter1_size == 0) {
            return new join::JoinT(iter);
        } else if (join_vertex.iter1_size == 1) {
            return new join::JoinT1S(iter,
                    iter + this->in_.size() + this->in_.size());
        } else if (join_vertex.iter1_size == 2) {
            return new join::JoinT1T(iter,
                    iter + this->in_.size() + this->in_.size());
        } else {
            return new join::JoinT1(iter,
                    iter + this->in_.size() + this->in_.size(),
                    join_vertex.iter1_size);
        }
    } else {
        // not possible to have join_vertex.iter_siz == 0
        assert(join_vertex.iter_size > 2);
        if (join_vertex.iter0_size) {
            if (join_vertex.iter1_size == 0) {
                return new join::Join0(iter, join_vertex.iter_size,
                        iter + this->in_.size(), join_vertex.iter0_size);
            } else if (join_vertex.iter1_size == 1) {
                auto iter0 = iter + this->in_.size();
                return new join::Join01S(iter, join_vertex.iter_size, iter0,
                        join_vertex.iter0_size, iter0 + this->in_.size());
            } else if (join_vertex.iter1_size == 2) {
                auto iter0 = iter + this->in_.size();
                return new join::Join01T(iter, join_vertex.iter_size, iter0,
                        join_vertex.iter0_size, iter0 + this->in_.size());
            } else {
                auto iter0 = iter + this->in_.size();
                return new join::Join01(iter, join_vertex.iter_size, iter0,
                        join_vertex.iter0_size, iter0 + this->in_.size(),
                        join_vertex.iter1_size);
            }
        }
        // no root level negation
        if (join_vertex.iter1_size == 0) {
            return new join::Join(iter, join_vertex.iter_size);
        } else if (join_vertex.iter1_size == 1) {
            return new join::Join1S(iter, join_vertex.iter_size,
                    iter + this->in_.size() + this->in_.size());
        } else if (join_vertex.iter1_size == 2) {
            return new join::Join1T(iter, join_vertex.iter_size,
                    iter + this->in_.size() + this->in_.size());
        } else {
            assert(join_vertex.iter1_size > 2);
            return new join::Join1(iter, join_vertex.iter_size,
                    iter + this->in_.size() + this->in_.size(),
                    join_vertex.iter1_size);
        }
    }
}

Node *ExecuteJoin::Result() {
    while (this->join_1d_.size()) {
        // Join recursion as a loop
        auto join = this->join_1d_.back();
        this->join_1d_.pop_back();
        for (; join->InRange(); join->Next()) {
            // append leaf value
            this->node_1d_[this->join_1d_.size()]->Append(join->Value());
            DPrintCTX("append (leaf) depth=" << this->join_1d_.size());
            DPrintLine(" value=" << join->Value());
        }
        delete join;
        /* the current Join is out of range and then move to next Join
         * before backtrack to upper join_1d, need to save current node
         * Append only non-empty Node
         */
        AppendInternal(this->join_1d_, this->node_1d_);
        this->join_1d_.back()->Next();
        for (; not this->join_1d_.back()->InRange();
                this->join_1d_.back()->Next()) {
            // pop out all out of range Join
            delete this->join_1d_.back();
            this->join_1d_.pop_back();
            if (this->join_1d_.empty()) {
                // Iterator * releases by when releasing Join
                return this->node_1d_[0];
            }
            /* only append non-empty Node
             * case 1: the join_1d.back() Join is in Range
             * then above for loop does not run
             * this case then finds its child Join and does not need Append Node
             * case 2: the join_1d.back() Join is out of Range
             * then above for loop backtracks to upper of the Join
             * this case needs Append Node because a subtree is completed
             * therefore case 2 condition is (join_1d.size() < depth - 1)
             * however, since empty node is not Append
             * therefore can just call AppendNewNode
             */
            AppendInternal(this->join_1d_, this->node_1d_);
        }
        this->Initialize(this->join_1d_.size());
    }
    return this->node_1d_[0];
}

Node *ExecuteJoin::Result(const std::string &file_name, uint64_t &counter) {
    // save result to the given file name. return result count
    counter = 0;
#if !defined(COUNTING) and defined(LISTING)
    std::ofstream outfile;
    if (file_name.size()) {
        utility::MkFileDir(file_name);
        outfile.open(file_name);
        PrintLCTX("write final result file: "<< file_name);
    }
#endif
    while (this->join_1d_.size()) {
        // Join recursion as a loop
        auto join = this->join_1d_.back();
        this->join_1d_.pop_back();
        for (; join->InRange(); join->Next()) {
            SaveToFile(this->join_1d_, join->Value(), outfile);
            ProcessLeaf(join, this->join_1d_, this->node_1d_);
            DPrintCTX("append (leaf) depth=" << this->join_1d_.size());
            DPrintLine(" value=" << join->Value());
        }
        delete join;
        /* the current Join is out of range and then move to next Join
         * before backtrack to upper join_1d, need to save current node
         * Append only non-empty Node
         */
        ProcessInternal(this->join_1d_, this->node_1d_);
        this->join_1d_.back()->Next();
        for (; not this->join_1d_.back()->InRange();
                this->join_1d_.back()->Next()) {
            // pop out all out of range Join
            delete this->join_1d_.back();
            this->join_1d_.pop_back();
            if (this->join_1d_.empty()) {
                // Iterator * releases by when releasing Join
                CountResultInFile(file_name, counter);
                return this->node_1d_[0];
            }
            /* only append non-empty Node
             * case 1: the join_1d.back() Join is in Range
             * then above for loop does not run
             * this case finds its child Join and does not need Append Node
             * case 2: the join_1d.back() Join is out of Range
             * then above for loop backtracks to upper of the Join
             * this case needs Append Node because a subtree is completed
             * therefore case 2 condition is (join_1d.size() < depth - 1)
             * however, since empty node is not Append
             * therefore can just call AppendNewNode
             */
            ProcessInternal(this->join_1d_, this->node_1d_);
        }
        this->Initialize(this->join_1d_.size());
    }
    CountResultInFile(file_name, counter);
    return this->node_1d_[0];
}

ExecuteJoin::ExecuteJoin(const Expression *expr, const node_1d_t &in,
        const node_set_t &nonedge_set, const vid_t vertex_size)
        : in_(in), offset_(this->in_.size() * 3), vertex_size_(vertex_size) {
    // nonedge_set: the set of input Node that is non-edge
    expr->SymBreakIndexToBindIndex(this->symbreak_low_, this->symbreak_up_);
    /* initialize Join context for execution
     * for each output vertex index, need for each input
     * 1. the Join type
     * 2. the Join type index in the previous output vertex
     * 3. previous output vertex index
     */
    // map out index to input i-th
    vec2_t oi_index;
    oi_index.resize(expr->output->out_index.size());
    size_t in_th = 0;
    DPrintCTX("expression=" << expr << " out_index->input_th=");
    for (auto &io_input : expr->io_vertex_index) {
        for (auto out_index : io_input) {
            oi_index[out_index].push_back(in_th);
            DPrint(out_index << "->" << in_th << " ");
        }
        in_th++;
    }
    DPrint(" in_1d=");
    DPrintArray(in, in.size());
    DPrint(" nonedge_set=");
    DPrintCollection(nonedge_set);
    DPrintLine("");
    // build input info for each output vertex index
    this->join_vertex_1d_.resize(oi_index.size());
    auto &join_vertex0 = this->join_vertex_1d_[0];
    for (auto in_th : oi_index[0]) {
        if (nonedge_set.count(in[in_th])) {
            join_vertex0.IterateNonedgeInput(in_th);
        } else {
            /* current input Node is an edge
             * and it is the in_th-th edge input
             */
            join_vertex0.IterateEdgeInput(in_th);
        }
        /* JoinTypeX indicates direct from input Node
         * and the 3th value=0 does not care because
         * no previous output vertex index
         */
    }
    DPrintCTX("");
    join_vertex0.DebugPrint(true);
    for (size_t out_index = 1; out_index < oi_index.size(); out_index++) {
        auto &join_vertex = this->join_vertex_1d_[out_index];
        for (auto &in_th : oi_index[out_index]) {
            // process in_th-th input Node
            auto &outindex_1d = expr->io_vertex_index[in_th];
            if (out_index == outindex_1d[0]) {
                // the first time that current input Node is used
                if (nonedge_set.count(in[in_th])) {
                    join_vertex.IterateNonedgeInput(in_th);
                } else {
                    join_vertex.IterateEdgeInput(in_th);
                }
            } else {
                // find out_index position
                auto out_it = std::lower_bound(outindex_1d.begin(),
                        outindex_1d.end(), out_index);
                auto prev_out_index = *(--out_it);
                Node *prev_node = nullptr;
                // previous in_th input Node
                size_t join_count = 0, join0_count = 0;
                for (auto &prev_in_th : oi_index[prev_out_index]) {
                    // input node
                    prev_node = in[prev_in_th];
                    if (prev_in_th == in_th) {
                        // find the same input for the previous output vertex
                        break;
                    } else {
                        // count other input
                        if (nonedge_set.count(prev_node)) {
                            if (expr->io_vertex_index[prev_in_th][0]
                                    == prev_out_index) {
                                join0_count++;
                            }
                        } else {
                            join_count++;
                        }
                    }
                }
                /* set JoinVertex for current output index
                 * previous output vertex index=*p_index
                 * previous Join type=
                 */
                // prev_node is now current input Node
                if (nonedge_set.count(prev_node)) {
                    /* current input Node is a non-edge
                     * current input vertex is not the first input vertex
                     * then current input vertex must be the second
                     */
                    assert(outindex_1d[0] == prev_out_index);
                    join_vertex.IterateNonedgeChild(join0_count,
                            prev_out_index);
                } else {
                    join_vertex.IterateEdgeChild(join_count, prev_out_index);
                }
            }
        }
        DPrintCTX("");
        join_vertex.DebugPrint(true);
    }
    // initialize state variable
    this->depth_ = this->join_vertex_1d_.size();
    if (this->depth_) {
        /* over allocate Iterator ** array
         * each output vertex needs at most 3 * this->in_.size() Iterator *
         * 3 is due to Iterator type for
         * edge, nonedge root (0) and nonedge leaf (1)
         * each input can contribute to at most 1 one them
         */
        this->iterator_2d_ = new Iterator*[this->offset_ * this->depth_];
        Join *next_join = this->InitializeIndex(0);
        if (next_join->InRange()) {
            this->join_1d_.push_back(next_join);
            InitializeNode1d(this->depth_, this->node_1d_, this->vertex_size_);
            this->Initialize(0);
        } else {
            this->iterator_2d_ = nullptr;
            delete next_join;
        }
        // this->join_1d_.size() should be either 0 or this->depth_
    } else {
        this->iterator_2d_ = nullptr;
    }
    // this Join has 0 result
    if (this->node_1d_.empty()) {
        this->node_1d_.push_back(new Node(0));
    }
}

ExecuteJoin::~ExecuteJoin() {
    delete[] this->iterator_2d_;
    for (auto &join : this->join_1d_) {
        delete join;
    }
    // the 0-th Node is the result Node and other Node should be released
    for (size_t ith = 1; ith < this->node_1d_.size(); ith++) {
        delete this->node_1d_[ith];
    }
}

#ifndef NDEBUG
void JoinVertex::DebugPrint(bool end_of_line) const {
    DPrint("JoinVertex=" << this << " iter_size=" << this->iter_size);
    DPrint(" iter0_size=" << this->iter0_size << " iter1_size=");
    DPrint(this->iter1_size << " (current_type,current_iter_index,prev_type");
    DPrint(",prev_index,prev_out_index)=");
    for (auto &info : this->type_index) {
        DPrint("(");
        DPrintArray(info, info.size());
        DPrint(") ");
    }
    if (end_of_line) {
        DPrintLine("");
    }
}
#endif

// initialize static variable
const size_t JoinVertex::Iter0_Type = 0;    // child 0 Iterator
const size_t JoinVertex::Iter1_Type = 1;    // child 1 Iterator
const size_t JoinVertex::IterN_Type = 2;    // normal Iterator
const size_t JoinVertex::IterIn_Type = 3;   // input Iterator

} // namespace sorttrie
