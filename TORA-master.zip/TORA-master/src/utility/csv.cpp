/*
 * csv.cpp
 *
 *  Created on: 9:01 AM Sunday 2023-2-26
 *      Author: Hongtai Cao
 */

#include <fstream>

#include "include/utility/csv.hpp"

namespace utility {

// Read CSV file, Excel dialect. Accept "quoted fields ""with quotes"""
std::vector<std::vector<std::string>> ReadCSV(const std::string &file_name) {
    std::ifstream in(file_name);
    std::vector<std::vector<std::string>> table;
    std::string row;
    while (!in.eof()) {
        std::getline(in, row);
        if (in.bad() || in.fail()) {
            break;
        }
        auto fields = ReadCSVRow(row);
        table.push_back(fields);
    }
    return table;
}

std::vector<std::string> ReadCSVRow(const std::string &line) {
    CSVState state = CSVState::UnquotedField;
    std::vector<std::string> fields { "" };
    size_t i = 0; // index of the current field
    for (char c : line) {
        switch (state) {
        case CSVState::UnquotedField:
            switch (c) {
            case ',': // end of field
                fields.push_back("");
                i++;
                break;
            case '"':
                state = CSVState::QuotedField;
                break;
            default:
                fields[i].push_back(c);
                break;
            }
            break;
        case CSVState::QuotedField:
            switch (c) {
            case '"':
                state = CSVState::QuotedQuote;
                break;
            default:
                fields[i].push_back(c);
                break;
            }
            break;
        case CSVState::QuotedQuote:
            switch (c) {
            case ',': // , after closing quote
                fields.push_back("");
                i++;
                state = CSVState::UnquotedField;
                break;
            case '"': // "" -> "
                fields[i].push_back('"');
                state = CSVState::QuotedField;
                break;
            default:  // end of quote
                state = CSVState::UnquotedField;
                break;
            }
            break;
        }
    }
    return fields;
}

} // namespace utility
