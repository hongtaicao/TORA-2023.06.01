/*
 * utility.cpp
 *
 *  Created on: Thursday 16:28 PM 2022-10-20
 *      Author: Hongtai Cao
 */

#include "include/utility/utility.hpp"

namespace utility {

uint64_t COUNTER_LOOP_0 = 0;
uint64_t COUNTER_LOOP_1 = 0;
uint64_t COUNTER_LOOP_2 = 0;
uint64_t COUNTER_LOOP_3 = 0;
uint64_t COUNTER_LOOP_4 = 0;
uint64_t COUNTER_LOOP_5 = 0;
uint64_t COUNTER_LOOP_6 = 0;
uint64_t COUNTER_LOOP_7 = 0;
uint64_t COUNTER_LOOP_8 = 0;
uint64_t COUNTER_LOOP_9 = 0;
uint64_t COUNTER_LOOP_10 = 0;
uint64_t COUNTER_LOOP_11 = 0;

void MkRecursiveDir(const std::string &directory) {
    size_t found = 0;
    do {
        found = directory.find_first_of("/\\", found + 1);
        MkDir(directory.substr(0, found));
    } while (found < std::string::npos);
}

std::string replace(const std::string &str, char a, char b) {
    std::string result;
    for (auto ch : str) {
        if (ch == a) {
            if (b != 0) {
                result += b;
            }
        } else {
            result += ch;
        }
    }
    return result;
}

} // namespace utility
