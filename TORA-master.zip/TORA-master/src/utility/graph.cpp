/*
 * graph.cpp
 *
 *  Created on: 16:09 Friday 2022-9-9
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <cstdlib>          // rand
#include <ctime>            // time

#include "include/optim/query.hpp"
#include "include/optim/query/labeled.hpp"
#include "include/optim/query/unlabeled.hpp"
#include "include/optim/topologytable.hpp"
#include "include/optim/type.hpp"
#include "include/utility/graph.hpp"

namespace utility {

namespace graph {

const eid_t DefaultLabel = 0;

/*
 * unconnected 0
 * bi-directed 1
 * in-coming 2
 * out-going 3
 */
const eid_t UnconnectedEdgeLabel = 0;
const eid_t BidirectedEdgeLabel = 1;
const eid_t IncomingEdgeLabel = 2;
const eid_t OutgoingEdgeLabel = 3;

// local function
bool LabelArrayComparator(const labelarray_t &a, const labelarray_t &b) {
    // sort in ascending order. return true if a < b
    if (a[0] < b[0]) {
        return true;
    } else if (a[0] > b[0]) {
        return false;
    }
    if (a[1] < b[1]) {
        return true;
    } else if (a[1] > b[1]) {
        return false;
    }
    if (a[2] < b[2]) {
        return true;
    } else if (a[2] > b[2]) {
        return false;
    }
    return a[3] < b[3];
}

// public function
void BuildLabelArray1d(const edge_to_labelarray_t &edge_to_labelarray,
        labelarray_1d_t &labelarray_1d) {
    // compute the label set. ignore unconnected label
    str_set_t label_set;
    for (auto it = edge_to_labelarray.begin(); it != edge_to_labelarray.end();
            it++) {
        auto l_str = LabelarrayToString(it->second);
        if (not label_set.count(l_str)) {
            label_set.insert(l_str);
            labelarray_1d.push_back(it->second);
        }
    }
    // assign label id to each label based on sorting order
    std::sort(labelarray_1d.begin(), labelarray_1d.end(), LabelArrayComparator);
    DPrintLCTX("label set count: " << label_set.size());
}

void ReadTextGraph(bool has_label, const std::string &in_file,
        edge_map_t &edge_map, edge_to_labelarray_t &edge_to_labelarray) {
    /* read text graph as edge list with label
     * output argument meaning
     * edge_map: store edges as neighbor set, without labels
     * edge_to_labelarray: edge -> labels (sl, dl, el, tl)
     * labelarray_1d: all unique labels as a tuple (sl, dl, el, tl)
     */
    // need to convert it to a c-string if not c++11 or later.
    std::ifstream in(in_file.c_str());
    // open as text file
    /*
     * graph.txt format
     * 5 columns space separated file, all should be numbers
     * source vertex
     * destination vertex
     * source vertex label
     * destination vertex label
     * edge label
     */
    // read data.txt
    vid_t src = 0, dst = 0;
    // src label, dst label, edge label
    vid_t sl = DefaultLabel, dl = DefaultLabel;
    eid_t el = DefaultLabel;
    if (has_label) {
        while ((not in.eof()) and (in >> src >> dst >> sl >> dl >> el)) {
            InsertEdge(src, dst, edge_map);
            edge_to_labelarray[ToString2(src, dst)] =
                    labelarray_t { sl, dl, el };
        }
    } else {
        vid_t src = 0, dst = 0;
        while ((not in.eof()) and (in >> src >> dst)) {
            InsertEdge(src, dst, edge_map);
            edge_to_labelarray[ToString2(src, dst)] =
                    labelarray_t { sl, dl, el };
        }
    }
    DPrintLCTX("vertex out degree > 0 count: " << edge_map.size());
    DPrintLCTX("edge count: " << edge_to_labelarray.size());
    in.close();
    // assign topology label
    for (auto imap = edge_map.begin(); imap != edge_map.end(); imap++) {
        auto src = imap->first;
        for (auto dst : edge_map[src]) {
            if (src != dst) {
                // self loops should be ignored
                std::string e_str = ToString2(src, dst);
                if (edge_map.count(dst) and edge_map[dst].count(src)) {
                    // bi-directed edge
                    edge_to_labelarray[e_str][3] = BidirectedEdgeLabel;
                } else {
                    // out-going edge
                    edge_to_labelarray[e_str][3] = OutgoingEdgeLabel;
                    auto &l_1d = edge_to_labelarray[e_str];
                    // in-coming edge
                    std::string in_str = ToString2(dst, src);
                    edge_to_labelarray[in_str] = labelarray_t { l_1d[1],
                            l_1d[0], l_1d[2], IncomingEdgeLabel };
                }
            } else {
                PrintLCTX("ignore self loop [" << src << "]");
            }
        }
    }
}

void ReadTextLabelFile(const std::string &label_file,
        labelstr_index_t &labelstr_index) {
    std::ifstream in(label_file.c_str());
    vid_t sl = 0, dl = 0;
    eid_t el = 0, tl = 0;
    while ((not in.eof()) and (in >> sl >> dl >> el >> tl)) {
        auto label_size = labelstr_index.size();
        labelstr_index[ToString4(sl, dl, el, tl)] = label_size;
    }
}

void SampleInducedSubgraph(Config &c) {
    /* using text data graph to create induced subgraph
     * work for both labeled and unlabeled
     */
    edge_map_t edge_map;
    typename optim::query::edge_label_t edge_label;
    typename optim::query::vertex_label_t vertex_label;
    // set random seed
    srand(time(NULL));
    std::ifstream in(c.DataFile().c_str());
    vid_t src = 0, dst = 0; // vertex are column index values
    // src label, dst label, edge label
    vid_t sl = DefaultLabel, dl = DefaultLabel;
    eid_t el = DefaultLabel;
    if (c.IsLabeled()) {
        // unlabeled text data has 5 columns
        while ((not in.eof()) and (in >> src >> dst >> sl >> dl >> el)) {
            edge_map[src].insert(dst);
            vertex_label[src] = sl;
            vertex_label[dst] = dl;
            edge_label[ToString2(src, dst)] = el;
        }
    } else {
        // unlabeled data has 2 columns
        while ((not in.eof()) and (in >> src >> dst)) {
            edge_map[src].insert(dst);
            vertex_label[src] = sl;
            vertex_label[dst] = dl;
        }
    }
    if (vertex_label.size() < c.SampleSubgraphSize()) {
        PrintLCTX("sample subgraph size is larger than the data graph. stop");
        SystemExit(-1);
    }
    // start sample
    optim::TopologyTable topology_table;
    int retry_count = 0;
    while ((topology_table.Size() < c.SampleCount())
            and (retry_count < c.SampleRetryCount())) {
        vid_set_t sampled_vertex;
        while (sampled_vertex.size() < c.SampleSubgraphSize()) {
            vid_1d_t vertex_pool;  // the same vertex can appear multiple times
            if (sampled_vertex.empty()) {
                /* the first vertex of the sample
                 * uniformly choose from the entire graph
                 */
                for (auto &pair : vertex_label) {
                    vertex_pool.push_back(pair.first);
                }
            } else {
                // choose from neighbors
                for (auto &v : sampled_vertex) {
                    for (auto &neighbor : edge_map[v]) {
                        if (not sampled_vertex.count(neighbor)) {
                            // only collect new vertexes
                            vertex_pool.push_back(neighbor);
                        }
                    }
                }
            }
            if (vertex_pool.empty()) {
                // not possible to sample
                break;
            }
            sampled_vertex.insert(vertex_pool[rand() % vertex_pool.size()]);
        }
        if (sampled_vertex.size() < c.SampleSubgraphSize()) {
            // cannot sample enough vertexes
            retry_count++;
            continue;
        }
        // create the induced subgraph
        optim::Query *query = nullptr;
        if (c.IsLabeled()) {
            query = new optim::query::Labeled(edge_label, vertex_label,
                    edge_map, sampled_vertex);
        } else {
            query = new optim::query::Unlabeled(edge_map, sampled_vertex);
        }
        // index the subgraph
        if (topology_table.Index(query)) {
            // owner of query
            // write query as a text file
            std::string dir, file, name, ext;
            utility::SplitDirFile(c.DataFile(), dir, file);
            utility::SplitExt(file, name, ext);
            std::string out_file = dir + "/" + name + "-query-"
                    + std::to_string(c.SampleSubgraphSize()) + "-"
                    + std::to_string(topology_table.Size()) + ".txt";
            utility::MkFileDir(out_file);
            std::ofstream out(out_file, std::ios::out);
            PrintLCTX("write a query file: "<< out_file);
            std::unordered_map<vid_t, vid_t> vertex_norm;
            for (auto &v : sampled_vertex) {
                auto normed = vertex_norm.size();
                vertex_norm[v] = normed;
            }
            if (c.IsLabeled()) {
                // write query as a 5 column text file
                for (auto &pair : query->VertexNeighbor()) {
                    auto src = vertex_norm[pair.first];
                    auto sl = vertex_label[pair.first];
                    for (auto &neighbor : pair.second) {
                        auto dst = vertex_norm[neighbor];
                        auto dl = vertex_label[neighbor];
                        auto el = edge_label[ToString2(pair.first, neighbor)];
                        out << ToString4(src, dst, sl, dl) << " " << el;
                        out << std::endl;
                    }
                }
            } else {
                // write query as a 2 column text file
                for (auto &pair : query->VertexNeighbor()) {
                    auto src = vertex_norm[pair.first];
                    for (auto &neighbor : pair.second) {
                        auto dst = vertex_norm[neighbor];
                        out << ToString2(src, dst) << std::endl;
                    }
                }
            }
        } else {
            // failure
            retry_count++;
            delete query;
        }
    }
    PrintCTX("sample topology count " << topology_table.Size() << " retry");
    PrintLine(" count/max " << retry_count << "/" << c.SampleRetryCount());
}

void WriteTextGraph(const std::string &out_file, const edge_map_t &edge_map,
        const str_map_t &edge_label_map) {
    // labeled or unlabeled depending on edge_label_map.size()
    utility::MkFileDir(out_file);
    std::ofstream out(out_file, std::ios::out);
    PrintCTX("edge count=" << edge_label_map.size());
    PrintLine(" write text file: "<< out_file);
    std::vector<vid_t> src_1d;
    for (auto it = edge_map.begin(); it != edge_map.end(); it++) {
        src_1d.push_back(it->first);
    }
    std::sort(src_1d.begin(), src_1d.end());
    for (vid_t src : src_1d) {
        auto neighbor = edge_map.at(src);
        std::vector<vid_t> dst_1d(neighbor.begin(), neighbor.end());
        std::sort(dst_1d.begin(), dst_1d.end());
        for (auto dst : dst_1d) {
            if (edge_label_map.empty()) {
                // unlabeled graph
                out << src << " " << dst << " " << std::endl;
            } else {
                // labeled graph
                std::string label = edge_label_map.at(ToString2(src, dst));
                label = label.substr(0, label.size() - 2);
                out << src << " " << dst << " " << label << std::endl;
            }
        }
    }
    out.close();
}

void BinaryToText::WriteTextGraph() {
    // labelstr_index: map label string to label_id
    labelstr_index_t labelstr_index;
    ReadTextLabelFile(this->label_file_, labelstr_index);
    str_map_t edge_label_map;
    /* CreateLabelMap
     * reverse labelstr_index mapping
     */
    std::string index_label[labelstr_index.size()];
    for (auto it = labelstr_index.begin(); it != labelstr_index.end(); it++) {
        index_label[it->second] = it->first;
    }
    for (auto it = this->edge_to_label_id.begin();
            it != this->edge_to_label_id.end(); it++) {
        edge_label_map[it->first] = index_label[it->second];
    }
    /* WriteTextGraph
     * write as edge list with vertex and edge
     * with labels if edge_label_map is not empty
     * labeled or unlabeled depending on edge_label_map.size()
     */
    utility::MkFileDir(this->out_file_);
    std::ofstream out(this->out_file_, std::ios::out);
    PrintCTX("edge count=" << edge_label_map.size());
    PrintLine(" write text file: "<< this->out_file_);
    std::vector<vid_t> src_1d;
    for (auto it = this->edge_map.begin(); it != this->edge_map.end(); it++) {
        src_1d.push_back(it->first);
    }
    std::sort(src_1d.begin(), src_1d.end());
    for (vid_t src : src_1d) {
        auto neighbor = this->edge_map.at(src);
        std::vector<vid_t> dst_1d(neighbor.begin(), neighbor.end());
        std::sort(dst_1d.begin(), dst_1d.end());
        for (auto dst : dst_1d) {
            if (edge_label_map.empty()) {
                // unlabeled graph
                out << src << " " << dst << " " << std::endl;
            } else {
                // labeled graph
                std::string label = edge_label_map.at(ToString2(src, dst));
                label = label.substr(0, label.size() - 2);
                out << src << " " << dst << " " << label << std::endl;
            }
        }
    }
    out.close();
}

void TextToBinary::ReadTextGraph(edge_map_1d_t &edge_map_1d,
        labelstr_index_t &labelstr_index, vid_t &max_vertex) {
    /* vertex is required to be in range [0, max_vertex]
     * therefore vertex_size = max_vertex + 1
     */
    edge_map_t edge_map;
    edge_to_labelarray_t edge_to_labelarray;
    labelarray_1d_t labelarray_1d;
    graph::ReadTextGraph(this->config_.IsLabeled(), this->config_.DataFile(),
            edge_map, edge_to_labelarray);
    BuildLabelArray1d(edge_to_labelarray, labelarray_1d);
    /* WriteTextLabelFile
     * write text label file
     */
    utility::MkFileDir(this->config_.LabelFile());
    std::ofstream out_label(this->config_.LabelFile(), std::ios::out);
    for (auto it = labelarray_1d.begin(); it != labelarray_1d.end(); it++) {
        // cannot combine into the same line
        lsize_t index = labelstr_index.size();
        labelstr_index[LabelarrayToString((*it))] = index;
        for (auto label : *it) {
            out_label << label << " ";
        }
        out_label << std::endl;
    }
    out_label.close();
    // create edge map per label id
    edge_map_1d.resize(labelstr_index.size());
    for (auto imap = edge_map.begin(); imap != edge_map.end(); imap++) {
        auto src = imap->first;
        max_vertex = std::max(max_vertex, src);
        for (auto dst : imap->second) {
            max_vertex = std::max(max_vertex, dst);
            auto l_str = LabelarrayToString(
                    edge_to_labelarray[ToString2(src, dst)]);
            InsertEdge(src, dst, edge_map_1d[labelstr_index[l_str]]);
            if (not (edge_map.count(dst) and (edge_map[dst].count(src)))) {
                // add in-coming edge
                auto in_str = LabelarrayToString(
                        edge_to_labelarray[ToString2(dst, src)]);
                InsertEdge(dst, src, edge_map_1d[labelstr_index[in_str]]);
            }
        }
    }
}

void TextToBinary::WriteBinHeader(const std::string &bin_file,
        const edge_map_1d_t &edge_map_1d,
        const labelstr_index_t &labelstr_index, const vid_t max_vertex) {
    // NO stream insertion/extraction (<< >>) operators for binary files
    MkFileDir(bin_file);
    this->out.open(bin_file, std::ios::binary | std::ios::out);
    this->vertex_size = max_vertex + 1; // this is the vertex count
    vid_t max_degree = 0;
    lsize_t label_size = labelstr_index.size();
    for (lsize_t i = 0; i < label_size; i++) {
        for (auto &pair : edge_map_1d[i]) {
            max_degree = std::max(max_degree, (vid_t) pair.second.size());
        }
    }
    out.write(reinterpret_cast<char *>(&this->vertex_size), sizeof(vid_t));
    out.write(reinterpret_cast<char *>(&max_degree), sizeof(max_degree));
    out.write(reinterpret_cast<char *>(&label_size), sizeof(label_size));
    DPrintCTX("write vertex_size=" << vertex_size << " max_degree=");
    DPrintLine(max_degree << " label_size=" << label_size);
}

} // namespace graph

} // namespace utility
