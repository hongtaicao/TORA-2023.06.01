/*
 * singlenode.cpp
 *
 *  Created on: 23:40 PM Saturday 2022-12-03
 *      Author: Hongtai Cao
 */

#include <cstdlib>          // size_t

#include "include/common.hpp"
#include "include/optim/symbreak/singlenode.hpp"

namespace optim {

namespace symbreak {

#ifndef NDEBUG
void SingleNode::DebugPrint(bool end_of_line) const {
    // print itself as " this=(smallest others)"
    DPrint(this << "=(");
    DPrintArray(this->rule_1d, this->rule_1d.size());
    if (end_of_line) {
        DPrintLine(")");
    } else {
        DPrint(")");
    }
}

void SingleNode::DebugPrintChain(bool end_of_line) const {
    // print itself and all of its parent as a single line
    auto head = this;
    DPrint("symmetry breaking SingleNode=(smallest, others)");
    while (head != nullptr) {
        DPrint(" ");
        head->DebugPrint(false);
        head = head->parent;
    }
    if (end_of_line) {
        DPrintLine("");
    }
}
#endif

} // namespace symbreak

} // namespace optim
