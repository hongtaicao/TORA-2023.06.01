/*
 * degreelabel.cpp
 *
 *  Created on: 2:05 AM Friday 2023-4-21
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <cstdlib>          // size_t

#include "include/algorithm/disjointset.hpp"
#include "include/common.hpp"
#include "include/optim/graph.hpp"
#include "include/optim/ordergenerator/degreelabel.hpp"
#include "include/optim/query.hpp"
#include "include/optim/query/base.hpp"
#include "include/utility/config.hpp"

namespace optim {

namespace ordergenerator {

// local function definition
void PermutationToLabelFrequency(const Graph &graph, Query &query,
        vid_1d_t &permute2frequency) {
    vid_map_t label_frequency;
    for (auto vertex : query.v_1d) {
        auto label = query.Label(vertex);
        if (not label_frequency.count(label)) {
            label_frequency[label] = graph.LabelFrequency(label);
        }
    }
    permute2frequency.resize(query.v_1d.size());
    for (size_t index = 0; index < query.v_1d.size(); index++) {
        permute2frequency[index] = label_frequency[query.Label(
                query.v_1d[index])];
    }
}

void Permutation2VertexOrbit(Query &query, vid_1d_t &permute2orbit) {
    // add permute into disjointset
    algorithm::DisjointSet<vid_t> djs;
    for (vid_t permute = 0; permute < query.v_1d.size(); permute++) {
        djs.Add(permute);
    }
    // union permute if there is an automorphic mapping
    for (size_t index = 1; index < query.mapping_1d.size(); index++) {
        /* mapping contains the permutation of vertex
         * such that v_1d[0] automorphic to v_1d[mapping[0]]
         */
        auto &mapping = query.mapping_1d[index];
        for (vid_t other = 0; other < mapping->size(); other++) {
            djs.Union(other, (*mapping)[other]);
        }
    }
    // save permute -> label (vertex orbit) into permute2orbit
    for (vid_t permute = 0; permute < query.v_1d.size(); permute++) {
        permute2orbit.push_back(djs.Find(permute));
    }
}

void UndirectedEdge(const Query &query, edge_map_t &undirected_edge) {
    undirected_edge.reserve(query.v_1d.size());
    for (const auto &pair : query.base->out_edge) {
        auto vset = undirected_edge[pair.first];
        for (auto vertex : pair.second) {
            vset.insert(vertex);
            undirected_edge[vertex].insert(pair.first);
        }
    }
}

void VertexToPermutation(const Query &query, vid_1d_t &v2p) {
    // requires v_1d in range [0, v_1d.size())
    v2p.resize(query.v_1d.size());
    for (size_t index = 0; index < query.v_1d.size(); index++) {
        v2p[query.v_1d[index]] = index;
    }
}

// public method
void DegreeLabel::Next() {
    while (this->group1d_index_.size()
            and (this->group1d_index_.back() == this->group1d_.back().size())) {
        /* already explored all vertex in this group
         * drop the group
         */
        this->group1d_index_.pop_back();
        this->group1d_.pop_back();
        this->select_permute_.erase(this->permutation.back());
        this->permutation.pop_back();
    }
    if (this->group1d_index_.empty()) {
        this->in_range_ = false;
        return;
    }
    auto to_remove = this->permutation.back();
    this->permutation.pop_back();
    this->select_permute_.erase(to_remove);
    auto index = this->group1d_index_.back();
    auto selected = this->group1d_.back()[index];
    this->group1d_index_[this->group1d_index_.size() - 1] = index + 1;
    this->permutation.push_back(selected);
    this->select_permute_.insert(selected);
    // generate the next permutation
    this->BuildGroup1d();
}

//private
void DegreeLabel::AddToGroup(const vid_t index, vid_1d_t &group) {
    // determine whether add index to group and add it
    if (this->config_.DisableSymmetryBreaking()) {
        group.push_back(index);
    } else {
        /* enable SymmetryBreaking
         * only push index when it is a new vertex orbit
         */
        auto orbit = this->permute2orbit_[index];
        bool is_new = true;
        for (auto x : group) {
            if (this->permute2orbit_[x] == orbit) {
                is_new = false;
                break;
            }
        }
        if (is_new) {
            group.push_back(index);
        }
    }
}

void DegreeLabel::BuildGroup1d() {
    while (this->permutation.size() < this->query_.v_1d.size()) {
        // find candidate connecting to previous groups
        this->group1d_.emplace_back();
        auto &group = this->group1d_.back();
        vid_t max_degree = 0, max_connectivity = 0;
        for (vid_t index = 0; index < this->query_.v_1d.size(); index++) {
            if (this->select_permute_.count(index)) {
                // skip already selected
                continue;
            }
            auto vertex = this->query_.v_1d[index];
            vid_t connectivity = 0;
            for (auto neighbor : this->undirected_edge_[vertex]) {
                if (this->select_permute_.count(
                        this->vertex2permute_[neighbor])) {
                    // connect to selected vertex
                    connectivity++;
                }
            }
            auto degree = this->undirected_edge_[vertex].size();
            if (connectivity > max_connectivity) {
                max_connectivity = connectivity;
                max_degree = degree;
                group.clear();
                group.push_back(index);
            } else if (connectivity == max_connectivity) {
                if (degree > max_degree) {
                    max_degree = degree;
                    group.clear();
                    group.push_back(index);
                } else if (degree == max_degree) {
                    this->AddToGroup(index, group);
                }
            }
        }
        /* group contains vertex, have the same
         * 1. connection to selected vertex
         * 2. overall degree
         */
        this->group1d_index_.push_back(1);          // 1 is index of the next
        this->select_permute_.insert(group[0]);
        this->permutation.push_back(group[0]);
    }
}

void DegreeLabel::MinLabelDegree(vid_1d_t &group) {
    /* compute a list of vertex permutation with lowest frequency/degree
     * save into min_ld
     */
    UndirectedEdge(this->query_, this->undirected_edge_);
    /* initialize min_value to be the max possible frequency/degree
     * which is the max frequency
     */
    double min_value = 0;
    for (auto freq : this->permute2freq_) {
        if (freq > min_value) {
            min_value = freq;
        }
    }
    group.reserve(this->undirected_edge_.size());
    for (size_t index = 0; index < this->query_.v_1d.size(); index++) {
        auto degree = this->undirected_edge_[this->query_.v_1d[index]].size();
        double value = 1.0 / degree * this->permute2freq_[index];
        if (value < min_value) {
            // clear previous permutation. save this permutation.
            group.clear();
            group.push_back(index);
            min_value = value;
        } else if (value == min_value) {
            // another permutation of the vertex of the same degree
            this->AddToGroup(index, group);
        }
    }
}

DegreeLabel::DegreeLabel(Config &config, const Graph &graph, Query &query)
        : in_range_(true), config_(config), query_(query) {
    /* create a vector for each query vertex to hold statistics and to rank
     * vertex, vertex permutation (index) of query.v_1d, degree, frequency
     */
    const auto query_size = query.v_1d.size();
    VertexToPermutation(query, this->vertex2permute_);
    if (config.IsLabeled()) {
        PermutationToLabelFrequency(graph, query, this->permute2freq_);
    } else {
        this->permute2freq_.resize(this->vertex2permute_.size(), query_size);
    }
    if (config.DisableSymmetryBreaking()) {
        // generate automorphic vertex order
        for (size_t index = 0; index < query_size; index++) {
            this->permute2orbit_.push_back(index);
        }
    } else {
        // does not generate automorphic vertex order
        Permutation2VertexOrbit(query, this->permute2orbit_);
    }
    /* segment query vertex into groups based on label-frequency / degree
     * explore different vertex order within each group
     * label-frequency comes from data graph
     * degree comes from query graph
     */
    this->group1d_.reserve(query_size);
    this->group1d_.emplace_back();
    this->MinLabelDegree(this->group1d_[0]);
    /* any permute in this->permute2d_[0] can be the first vertex
     * select one of them and add to output permutation
     */
    this->group1d_index_.push_back(1);
    this->permutation.reserve(query_size);
    auto selected = this->group1d_[0][0];
    this->permutation.push_back(selected);
    /* then build permute for remaining vertexes
     * they have to first connect to vertex in previous groups
     * then they should have high degree in the query
     * label frequency of data graph is not used because here needs
     * label frequency of a certain label, which is unknown
     */
    this->select_permute_.reserve(query_size);
    this->select_permute_.insert(selected);
    this->BuildGroup1d();
}

} // namespace ordergenerator

} // namespace optim
