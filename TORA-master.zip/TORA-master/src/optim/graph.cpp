/*
 * graph.cpp
 *
 *  Created on: 1:06 AM Saturday 2023-4-22
 *      Author: Hongtai Cao
 */

#include "include/optim/graph.hpp"

namespace optim {

string_1d_t &Graph::EdgeTopologyLabel(const std::string &vpair_label) {
    if (not this->et_labelstr_index_.count(vpair_label)) {
        auto &vec = this->et_labelstr_index_[vpair_label];
        for (auto &pair : this->labelstr_index_) {
            bool match = true;
            for (size_t i = 0; i < vpair_label.size(); i++) {
                if (pair.first[i] != vpair_label[i]) {
                    match = false;
                    break;
                }
            }
            if (match) {
                // save edge label and topology label
                vec.push_back(pair.first.substr(vpair_label.size()));
            }
        }
    }
    return this->et_labelstr_index_[vpair_label];
}

vid_t Graph::LabelFrequency(const vid_t label) const {
    vid_set_t vset;
    for (auto &pair : this->labelstr_index_) {
        /* check root vertex is enough
         * due to both direction are stored as edges
         */
        if (label == std::stoul(pair.first)) {
            auto edge_index = pair.second;
            for (vid_t ith = 0; ith < this->RootSize(edge_index); ith++) {
                auto va = this->RootVertex(edge_index, ith);
                // count vertex label for root
                vset.insert(va);
            }
        }
    }
    return vset.size();
}

} // namespace optim
