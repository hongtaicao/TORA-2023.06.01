/*
 * labeled.cpp
 *
 *  Created on: 20:28 PM 2022-10-28
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <fstream>
#include <functional>       // std::hash
#include <unordered_set>

#include "include/optim/query/labeled.hpp"
#include "include/utility/config.hpp"

namespace optim {

namespace query {

size_t Labeled::Hash(const Query *query) {
    // hash from Query
    auto key = Base::Hash(query);
    // add hash of vertex labels. edge labels are not added
    std::vector<vid_t> label_1d;
    label_1d.reserve(this->v_1d.size());
    for (auto &v : this->v_1d) {
        label_1d.push_back(this->vlabel_[v]);
    }
    std::sort(label_1d.begin(), label_1d.end());
    for (auto item : label_1d) {
        key = key * 31 + std::hash<vid_t>()(item);
    }
    return key;
}

Labeled::Labeled(Config &c)
        : Base() {
    this->base = this;
    std::ifstream in(c.QueryFile().c_str());
    vid_t src, dst, sl, dl;
    eid_t el;
    std::unordered_set<vid_t> v_set;
    while ((not in.eof()) and (in >> src >> dst >> sl >> dl >> el)) {
        v_set.insert(src);
        v_set.insert(dst);
        this->out_edge[src].insert(dst);
        this->vlabel_[src] = sl;
        this->vlabel_[dst] = dl;
        this->elabel_[ToString2(src, dst)] = el;
    }
    this->v_1d.assign(v_set.begin(), v_set.end());
    this->InitializeCounter();
}

Labeled::Labeled(edge_label_t &edge_label, vertex_label_t &vertex_label,
        edge_map_t &edge_map, vid_set_t &v_set)
        : Base(edge_map, v_set) {
    this->base = this;
    // edge label
    for (auto &src : v_set) {
        for (auto &dst : edge_map[src]) {
            if (v_set.count(dst)) {
                std::string key = ToString2(src, dst);
                this->elabel_[key] = edge_label[key];
            }
        }
    }
    // vertex label
    for (auto &v : v_set) {
        this->vlabel_[v] = vertex_label[v];
    }
    this->InitializeCounter();
}

} // namespace query

} // namespace optim
