/*
 * expression.cpp
 *
 *  Created on: 3:22 AM Saturday 2022-11-05
 *      Author: Hongtai Cao
 */

#include "include/common.hpp"
#include "include/optim/expression.hpp"
#include "include/optim/operand.hpp"

namespace optim {

void Expression::PopPending(operand_1d_t &result) {
    while (not this->pending.empty()) {
        result.push_back(this->pending.top());
        this->pending.pop();
    }
}

void Expression::PopPendingIsomorphic(operand_1d_t &result) {
    // retrieve the top Operand that are isomorphic and remove from pool
    // do not retrieve building block
    Operand *top = this->pending.top();
    result.push_back(top);
    this->pending.pop();
    while ((not this->pending.empty()) and top->Isomorphic(this->pending.top())) {
        result.push_back(this->pending.top());
        this->pending.pop();
    }
}

void Expression::PrintChain(bool end_of_line) const {
    // print itself and all of its parent as a single line
    auto head = this;
    Print("Expression=(output<-input ...)");
    while (head != nullptr) {
        Print(" " << head << "=(" << head->output << "<-");
        PrintArray(head->input, head->input.size());
        Print(")");
        head = head->parent;
    }
    if (end_of_line) {
        PrintLine("");
    }
}

void Expression::PrintDetail(bool end_of_line) const {
    // detailed print of a single expression as a block
    Print("Begin Expression=" << this << " output operand=" << this->output);
    if (this->IsJoin()) {
        // join operator
        Print(" join (index of input for one output vertex, ...)=");
        for (auto &operand_order : this->io_vertex_mapping) {
            for (size_t i = 0; i < operand_order.size(); i += 2) {
                Print(operand_order[i] << "_");
            }
            Print(",");
        }
    } else {
        if (this->IsRename()) {
            // rename
            Print(" rename");
        } else {
            // transpose
            Print(" transpose (index of query vertex)=");
            for (auto &order : this->io_vertex_mapping) {
                Print(order[0] << "_");
            }
        }
    }
    PrintLine("");
    this->output->PrintDetail(true);
    for (auto &input : this->input) {
        input->PrintDetail(true);
    }
    Print("End  Expression");
    if (end_of_line) {
        PrintLine("");
    }
}

void Expression::PushPending(const operand_1d_t &pending) {
    // pending should not contain building blocks
    for (auto &operand : pending) {
        this->pending.push(operand);
    }
}

} // namespace optim
