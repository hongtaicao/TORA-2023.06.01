/*
 * optimizer.cpp
 *
 *  Created on: 20:21 Thursday 2022-10-27
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <cassert>
#include <cstdlib>          // size_t
#include <fstream>
#include <unordered_map>

#include "include/abstract/execution.hpp"
#include "include/abstract/expression.hpp"
#include "include/abstract/operand.hpp"
#include "include/algorithm/combination.hpp"
#include "include/common.hpp"
#include "include/optim/costmodel.hpp"
#include "include/optim/costmodel/hypergeometric.hpp"
#include "include/optim/costmodel/powerlaw.hpp"
#include "include/optim/expression.hpp"
#include "include/optim/operand.hpp"
#include "include/optim/ordergenerator.hpp"
#include "include/optim/ordergenerator/adhoc.hpp"
#include "include/optim/ordergenerator/degreelabel.hpp"
#include "include/optim/ordergenerator/nonautomorphism.hpp"
#include "include/optim/query.hpp"
#include "include/optim/query/base.hpp"
#include "include/optim/symbreak/doublenode.hpp"
#include "include/optim/symbreak/symbreak.hpp"
#include "include/optim/topdown/decomposer.hpp"
#include "include/optim/topdown/optimizer.hpp"
#include "include/utility/clock.hpp"
#include "include/utility/config.hpp"
#include "include/utility/graph.hpp"
#include "include/utility/logger.hpp"
#include "include/utility/utility.hpp"

/* implementation flag
 * PostPopulateSymbreak:
 * symmetry breaking rules are not enumerated during decomposition,
 * but are pushed down using the best Expression that does not
 * consider symmetry breaking
 * the combined optimal Expression + push-down symmetry breaking is not
 * guarantee the optimal
 */
#define PostPopulateSymbreak true

namespace optim {

namespace topdown {

// forward declare
// local type
// map optim::Operand -> abstract::Operand
typedef std::unordered_map<Operand *, abstract::Operand *> operand_map_t;
typedef std::unordered_map<Operand *, Expression *> out_to_expr_t;
typedef std::unordered_map<order_t, order_set_t> order_to_orderset_t;
typedef std::unordered_set<Operand *> operand_set_t;
typedef std::vector<order_1d_t> vec_2d_t;

// local function (ordered alphabetically)
void GetSymBreakOtherOrder(const Operand *, const order_1d_t &,
        order_to_orderset_t &);
void MapOutputOrderToIndex(const Expression *, order_1d_t &);
void PrintCompletePlan(size_t, const Expression *);
void PrintOperandMap(operand_map_t &);

// implement
// local function
void BuildExeExprSymBreak(const Expression *expr, const order_1d_t &root_index,
        order_to_orderset_t &bind_set_map, order_2d_t &out_symbreak_index) {
    /* build abstract::Expression with symmetry breaking index
     * the symmetry is the output symmetry not covered by the input
     * bind_set_map: input Operand covered symmetry breaking rule set
     * out_symbreak_index: output, symmetry breaking rule during execution
     */
    // turn output order to i-th output vertex
    order_1d_t order_to_index;
    MapOutputOrderToIndex(expr, order_to_index);
    // map output i-th vertex to root Operand i-th vertex
    for (auto out_rule : expr->output->rule_1d) {
        /* for each output rule, remove index covered by input rule
         * local Expression, the local output Operand order (permutation)
         */
        order_1d_t join_rule;
        auto &other_order_set = bind_set_map[(*out_rule)[0]];
        for (size_t ith = 1; ith < out_rule->size(); ith++) {
            auto order = (*out_rule)[ith];
            if (not other_order_set.count(order)) {
                // no input carry this constraint
                join_rule.push_back(order);
            }
        }
        DPrintCTX("output rule (order)=");
        DPrintArray(*out_rule, out_rule->size());
        DPrint(" join_rule (order)=");
        DPrintArray(join_rule, join_rule.size());
        DPrintLine("");
        /* turn local output index to root Operand index
         * symmetry breaking representation changed order -> index
         * op_to_ph: local order (permutation) -> root index
         */
        if (not join_rule.empty()) {
            // find a join symmetry breaking rule
            auto *sym_index = new order_1d_t;
            out_symbreak_index.push_back(sym_index);
            /* rule bind order is (*out_rule)[0]
             * this is the k-th vertex of the current output Operand
             * k-th = order_to_index[(*out_rule)[0]]
             * the k-th current output vertex is
             * the root_index[k-th]-th output vertex of the root
             */
            /* add index=order_to_index[bind_order] for
             * bind_order=(*out_rule)[0]
             * turn index=order_to_index[bind_order] to root_index[index]
             */
            sym_index->push_back(root_index[order_to_index[(*out_rule)[0]]]);
            // add index for other order
            for (auto order : join_rule) {
                sym_index->push_back(root_index[order_to_index[order]]);
            }
        }
    }
}

inline void BuildExeOpEdgeIndex(Operand *operand, CostModel *costmodel,
        abstract::Operand *placeholder) {
    /* connect to data graph edge key
     * build edge index for abstract::Operand, for Operand size=2
     * build result into placeholder.edge_index
     */
    DPrintCTX("");
    operand->DebugPrint(true);
    if (not (operand->IsInput() and operand->rule_1d.empty()
            and placeholder->edge_index.empty())) {
        return;
    }
    /* the same input Operand maybe build multiple times
     * depending on the number of times it appear as input
     * however, it does not hurt if placeholder->edge_index.empty() == true
     */
    assert(operand->IsInput());
    assert(operand->rule_1d.empty());
    assert(placeholder->edge_index.empty());
    auto * const query = operand->query;
    auto va = query->v_1d[operand->order[0]];
    auto vb = query->v_1d[operand->order[1]];
    if (query->IsEmpty()) {
        /* a non-edge, need to find the complement
         * no symmetry breaking rule
         */
        placeholder->is_nonedge = true;
        costmodel->GetNonEdgeIndex(va, vb, placeholder->edge_index);
        /* this input Operand is not in the data graph
         * can leave as empty
         */
        DPrintCTX("(non-edge) edge_index_1d=");
        DPrintArray(placeholder->edge_index, placeholder->edge_index.size());
        DPrint(" if empty then all match.");
    } else {
        auto label_key = costmodel->LabelKey(va, vb);
        DPrintCTX("(edge) vertex-pair-edge-topology label_key=" << label_key);
        auto &graph = costmodel->GetGraph();
        if (graph.HasEdgeIndex(label_key)) {
            auto edge_index = graph.EdgeIndex(label_key);
            // data graph can match this edge Query
            placeholder->edge_index.push_back(edge_index);
        } else {
            // this input Operand is not in the data graph
            DPrint(" not in the data graph and therefore no match.");
        }
    }
    DPrintLine("");
}

#ifdef NDEBUG
#define DPrintBindSetMap(x)                                     (void (0))
#define DPrintCompletePlan(x, y)                                (void (0))
#define DPrintIOOrderMap(x)                                     (void (0))
#define DPrintOperandMap(x)                                     (void (0))
#define DPrintPending(x, y)                                     (void (0))
#else
void DPrintBindSetMap(order_to_orderset_t &bind_set_map) {
    DPrintCTX("output symmetry breaking rule covered by input ");
    DPrint("(bind order, other order ...)=");
    for (auto &pair : bind_set_map) {
        DPrint("(" << pair.first <<",");
        for (auto &other : pair.second) {
            DPrint(other << ",");
        }
        DPrint(")");
    }
    DPrintLine("");
}

inline void DPrintCompletePlan(size_t index, const Expression *expr) {
    PrintCompletePlan(index, expr);
}

void DPrintIOOrderMap(vec_2d_t &io_order_map_1d) {
    DPrintCTX("input to output order map (as vector)=");
    for (auto &map : io_order_map_1d) {
        DPrintArray(map, map.size());
        DPrint(";");
    }
    DPrintLine("");
}

inline void DPrintOperandMap(operand_map_t &map) {
    PrintOperandMap(map);
}

void DPrintPending(const operand_1d_t &todo, const operand_1d_t &pending) {
    DPrintLine("");
    DPrintCTX("find expression for operands: todo=");
    DPrintArray(todo, todo.size());
    DPrint("pending=");
    DPrintArray(pending, pending.size());
    DPrintLine("");
}
#endif

void FindJoinSymBreakAsRootVertexIndex(Expression *expr,
        const order_1d_t &root_index, order_2d_t &out_symbreak_index) {
    /* find rule that are not populated to input Operand
     * some symmetry breaking rules are not populated from output into input
     * therefore they should be identified and applied to Join Execution
     *
     * note that even later on input Operand are sorted
     * the sorting won't affect the symbreak_index
     * because they are based on output vertex index
     * which does not change when sorting input
     *
     * root_index: in parameter, Operand output order -> root vertex index
     * out_symbreak_index: out parameter, SymBreak rule should add to execution
     */
    DPrintLine("");
    DPrintLCTX("");
    expr->DebugPrint(true);
    /* io_order_map, for each input
     * map input order (permutation) to output order (permutation)
     */
    vec_2d_t io_order_map_1d;
    io_order_map_1d.resize(expr->input.size());
    size_t out_index = 0;
    for (auto &oo : expr->io_vertex_mapping) {
        /* oo is parsed into segment of pairs for Join Expression
         * oo[0] is the index of the input
         * oo[1] is the order (permutation) of input vertex, v_1d[oo[1]]
         */
        for (size_t ith = 1; ith < oo.size(); ith += 2) {
            /* this is the op_order[ith-1]-th input
             * input vertex = v_1d[op_order[ith]]
             * output vertex = v_1d[output->order[out_index]]
             * map input rule value to output rule value
             */
            auto in_th = oo[ith - 1];
            if (io_order_map_1d[in_th].empty()) {
                io_order_map_1d[in_th].resize(expr->input[in_th]->order.size());
            }
            io_order_map_1d[in_th][oo[ith]] = expr->output->order[out_index];
        }
        out_index++;
    }
    DPrintIOOrderMap(io_order_map_1d);
    /* for the given expression
     * find rule that are not populated to input Operand
     * since there is always checking whether a value exist in a rule (vector)
     * it is better to speedup and turn rule type from vector to set
     * therefore collect all input rule and compress them into set
     *
     * bind_set_map
     * key is the bind order, represented using output permutation
     * value is a set of other order, again using output permutation
     */
    order_to_orderset_t bind_set_map;
    for (size_t ith = 0; ith < expr->input.size(); ith++) {
        // get the ith-input io_order_map
        auto &io_order_map = io_order_map_1d[ith];
        GetSymBreakOtherOrder(expr->input[ith], io_order_map, bind_set_map);
    }
    DPrintBindSetMap(bind_set_map);
    BuildExeExprSymBreak(expr, root_index, bind_set_map, out_symbreak_index);
}

void GetSymBreakOtherOrder(const Operand *operand,
        const order_1d_t &io_order_map, order_to_orderset_t &bind_set_map) {
    // for each bind order, get all other interacting symmetry breaking order
    for (auto in_rule : operand->rule_1d) {
        // output bind order = io_order_map[(*in_rule)[0]]
        auto &other_order = bind_set_map[io_order_map[(*in_rule)[0]]];
        for (size_t jth = 1; jth < in_rule->size(); jth++) {
            other_order.insert(io_order_map[(*in_rule)[jth]]);
        }
    }
}

void KeepCommonSymBreak(Expression *expr) {
    std::unordered_map<tid_t, std::vector<Operand *>> tid_to_input;
    for (auto &input : expr->input) {
        tid_to_input[input->query->tid].push_back(input);
    }
    for (auto &pair : tid_to_input) {
        // find common rule for each pair of input of the same tid
        for (size_t jth = 1; jth < pair.second.size(); jth++) {
            auto &op_j = pair.second[jth];
            for (size_t ith = 0; ith < jth; ith++) {
                /* no need to check if transpose is needed between
                 * ith and jth in pair.second
                 *
                 * example
                 * Q_a.v_1d=[a-b-c], Operand_a.order=[1,0,2]
                 * rule_a={[0,2]}
                 *
                 * Q_b.v_1d=[d-e-f], Operand_b.order=[2,1,0]
                 * rule_b={[0,2]}
                 */
                op_j->KeepCommonSymBreak(pair.second[ith]);
            }
        }
    }
}

void MapOutputOrderToIndex(const Expression *expr, order_1d_t &order_to_index) {
    /* map output order (vertex permutation) to index, the i-th of the order
     * expr->output->order values are permutation in range [0, order.size())
     * therefore can use vector to do the reverse mapping
     */
    order_to_index.resize(expr->output->order.size());
    for (size_t ith = 0; ith < expr->output->order.size(); ith++) {
        order_to_index[expr->output->order[ith]] = ith;
    }
}

void PopulateJoin(Expression *expr) {
    // symmetry breaking rule is not populated to non-edge Operand
    order_1d_t order_to_index;
    MapOutputOrderToIndex(expr, order_to_index);
    for (auto out_rule : expr->output->rule_1d) {
        // for each output rule, generate rule for input
        // placeholder for input rule
        std::unordered_map<size_t, order_1d_t *> input_rule_1d;
        // create placeholder for input that match bind index
        auto out_index = order_to_index[(*out_rule)[0]];
        auto &op_order = expr->io_vertex_mapping[out_index];
        for (size_t ith = 1; ith < op_order.size(); ith += 2) {
            auto input_index = op_order[ith - 1];
            if (not (input_rule_1d.count(input_index)
                    or expr->input[input_index]->query->IsEmpty())) {
                /* 1. create rule placeholder for input that can have rules
                 * 2. do not create more rule for the same input
                 * 3. symmetry breaking cannot apply to non-edge (IsEmpty())
                 * because non-edge cannot apply symmetry breaking
                 * and its rule should be kept in the computation
                 */
                input_rule_1d[input_index] = new order_1d_t;
            }
        }
        // create input rule into placeholder
        for (auto &out_order : (*out_rule)) {
            /* out_order is the bind index
             * it is the out_index-th vertex in the output
             */
            auto out_index = order_to_index[out_order];
            // find input index and join order
            auto &op_order = expr->io_vertex_mapping[out_index];
            for (size_t ith = 1; ith < op_order.size(); ith += 2) {
                auto input_index = op_order[ith - 1];
                auto input_order = op_order[ith];
                if (input_rule_1d.count(input_index)) {
                    //  this input can have a rule
                    input_rule_1d[input_index]->push_back(input_order);
                }
            }
        }
        DPrintCTX("expression=" << expr << " output rule=");
        DPrintArray(*out_rule, out_rule->size());
        DPrint(" ith-input=rule");
        // populate rule from placeholder to input
        for (auto pair : input_rule_1d) {
            DPrint(" " << pair.first << "=");
            DPrintArray(*pair.second, pair.second->size());
            DPrint(";");
            if (pair.second->size() > 1) {
                // valid rule, populate to input
                expr->input[pair.first]->rule_1d.push_back(pair.second);
            } else {
                // not enough index in the rule. delete the rule
                delete pair.second;
            }
        }
        DPrintLine("");
    }
    // output rule are all populated to input
    for (auto &input : expr->input) {
        input->SortSymBreak();
    }
}

void PopulateSharing(const expression_1d_t &expr_1d, int &i_expr) {
    /* Rename or Transpose
     * 1. collect all Expression of the same topology
     * 2. start from Operand with the least number of rules
     * and keep only common symmetry breaking rules
     * 3. this is a conservative choice subquery result
     * whether keep only common or not does not change correctness
     */
    std::unordered_set<Operand *> op_set;
    for (; i_expr > -1; i_expr--) {
        auto expr = expr_1d[i_expr];
        if (expr->IsJoin()) {
            // this is a join, to be processed in the next loop
            break;
        } else {
            op_set.insert(expr->output);
            op_set.insert(expr->input[0]);
        }
    }
    std::vector<Operand *> op_1d(op_set.begin(), op_set.end());
    std::sort(op_1d.begin(), op_1d.end(), Operand::AscSymBreakRuleCount);
    // compute common rule and store in op_a
    DPrintLine("");
    DPrintLCTX("1st pass compute common SymBreak and save in the 1st Operand");
    auto op_a = op_1d[0];
    for (size_t ith = 1; ith < op_1d.size(); ith++) {
        op_a->KeepCommonSymBreak(op_1d[ith]);
    }
    // update all other Operand
    DPrintLine("");
    DPrintLCTX("2nd pass update SymBreak for all other Operand");
    for (size_t ith = 1; ith < op_1d.size(); ith++) {
        op_a->KeepCommonSymBreak(op_1d[ith]);
    }
}

void PrintCompletePlan(size_t index, const Expression *expr) {
    PrintCTX("complete plan=" << index << " as chain: ");
    expr->PrintChain(true);
    for (auto ptr = expr; ptr != nullptr; ptr = ptr->parent) {
        ptr->PrintDetail(true);
    }
    PrintLine("");
}

void PrintOperandMap(operand_map_t &map) {
    // Operand->Placeholder(out_index,function_name)
    Print("optim::Operand->abstract::Operand=");
    for (const auto &pair : map) {
        Print(pair.first << "->" << pair.second << " ");
    }
    PrintLine("");
}

double RuleScore(const expression_1d_t &expr_1d) {
    /* evaluate rule benefit
     * use the amount of computation reduction of the rule, as benefit
     *
     * based on how Expression are enumerated
     * edge Query are not enumerated with Expression that computing them
     * but we still want to check if SymBreak can be applied to edge Query
     * e.g., if all bi-directed edge are associated with the same rule
     */
    DPrintCTX("(Expression,cost,saved cost)=");
    double score = 0;
    // collect all edge Operand
    std::unordered_map<tid_t, std::vector<Operand *>> tid_to_edge;
    for (int i_expr = expr_1d.size() - 2; i_expr > -1; i_expr--) {
        auto expr = expr_1d[i_expr];
        if (expr->output->rule_1d.empty()) {
            // empty rule_1d does not save computation cost
            continue;
        }
        if (expr->IsRename()) {
            // Rename Expression does not have cost
            continue;
        }
        /* Expression cost = parent cost - output size + computation cost
         * + input size (exclude edge Query)
         * therefore
         * computation cost = E-cost - parent cost
         */
        double cost = expr->cost - expr_1d[i_expr + 1]->cost
                + expr->output->estimate_size;
        for (auto &input : expr->input) {
            if (input->IsInput()) {
                // Query of size 2, basic input
                tid_to_edge[input->query->tid].push_back(input);
            } else {
                // exclude edge
                cost -= input->estimate_size;
            }
        }
        size_t denominator = 1;
        for (auto &rule : expr->output->rule_1d) {
            /* if rule has 2 indexes, then reduce the size by half
             * if rule has 3 indexes, then reduce the size by 2/3
             * ...
             * therefore for each rule, the cost is reduced to 1/size
             */
            denominator *= rule->size();
        }
        DPrint("(" << expr << "," << cost << ",");
        DPrint((cost - cost / denominator) << ") ");
        // use saved cost as the score
        score += (cost - cost / denominator);
    }
    // adjust score if edge Operand share SymBreak
    DPrint(" (edge Operand, bonus)=");
    for (auto &pair : tid_to_edge) {
        auto &op_0 = pair.second[0];
        bool all_shared = true;
        if (op_0->query->mapping_1d.size() > 1) {
            // bi-directed edge or non-edge. can just check rule count
            auto rule_count = op_0->rule_1d.size();
            for (size_t ith = 1; ith < pair.second.size(); ith++) {
                if (pair.second[ith]->rule_1d.size() != rule_count) {
                    all_shared = false;
                    break;
                }
            }
        } else {
            // single directed edge or vertex with different labels
            /* Operand with the same topology share the same Query vertex_1d
             * symmetry breaking rules are index into vertex_1d
             * therefore can just compare rule count and rule content
             * check rule_1d content, can have either 0 or 1 rule
             */
            for (size_t ith = 1; ith < pair.second.size(); ith++) {
                auto total = op_0->rule_1d.size()
                        + pair.second[ith]->rule_1d.size();
                // total = 0 or 1 or 2
                if (total > 1) {
                    // total=2, size match, then check content
                    if (op_0->rule_1d[0][0]
                            != pair.second[ith]->rule_1d[0][0]) {
                        // first index does not match
                        all_shared = false;
                        break;
                    } else if (op_0->rule_1d[0][1]
                            != pair.second[ith]->rule_1d[0][1]) {
                        // second index does not match
                        all_shared = false;
                        break;
                    }
                } else if (total == 1) {
                    // rule size mismatch
                    all_shared = false;
                    break;
                }
            }
        }
        if (all_shared and (not op_0->rule_1d.empty())) {
            // increase rule score due to SymBreak on edge Query
            score += op_0->estimate_size / 2;
            DPrint("(" << op_0 << "," << op_0->estimate_size / 2 << ") ");
        }
    }
    DPrintLine(" rule score=" << score);
    return score;
}

// public function
void BuildExecution(Optimizer &optimizer, Expression *leaf,
        abstract::Execution &execution) {
    /* purpose:
     * generate function name or argument for abstract::Execution
     * Expression *leaf preserves the computation order
     * Execution is built following the Expression *leaf order
     * therefore Execution also preserves the computation order
     *
     * ExecuteCompiled uses function name
     * ExecuteDynamic uses function argument
     *
     * requirement:
     * should reduce materializing intermediate results, compress WCOJ
     * consider symmetry breaking into function name
     * should reduce the number of different function names
     * symmetry breaking cannot be applied to non-edge directly
     *
     * each final output vertex corresponds to an index 0, 1, 2, ...
     * the first output vertex corresponds to 0, ...
     *
     * the output function name is a list of input-to-output-index
     * the list size is the number of input
     *
     * the input-to-output-index is a list, the size is input vertex size
     * each element is an output index, the i-th output vertex
     *
     * compare two concepts: order v.s. index
     * order: Operand vertex order, Operand symmetry breaking rule
     * order is permutation of Query.v_1d, vertex=v_1d[order]
     *
     * index: used in function name, i-th output vertex
     * the i-th output vertex maps to i-th permutation order[i-th]
     * the output vertex is v_1d[order[i-th]]
     * therefore i-th output vertex = i-th of v_1d[order] = v_1d[order[i-th]]
     */
    expression_1d_t expr_1d;
    operand_set_t materialized_op;
    // index Expression to know how each output Operand is computed
    out_to_expr_t outop_to_expr;
    /* full name: operand to placeholder
     * map every optim::Operand -> abstract::Operand
     * abstract::Operand is first new here
     * then distributed to utility::Expression.input_1d if materialized
     */
    operand_map_t op_to_ph;
    size_t query_size = 0;
    DPrintCTX("materialized (Expression, Output Operand, Input Operand)=");
    while (leaf != nullptr) {
        expr_1d.push_back(leaf);
        if (not leaf->IsJoin()) {
            /* can be Rename, Select or Transpose
             * Rename case
             * both input and output Operand appear as Join input Operand
             * therefore both should be materialized
             *
             * Select case: apply symmetry breaking to edge Query
             * if there is such a case
             * then the output Operand is edge Query with symmetry breaking
             * the output must be used multiple times as input of others
             * otherwise this Expression should be pruned at the end of
             * Optimizer::PopulateSymmetryBreak()
             * edge Query without symmetry breaking rule is materialized
             * therefore Operand.IsInput() should always be materialized
             * but it may not appear in materialized_op if no Select
             * therefore need IsMaterialized() function
             *
             * Transpose case
             * output Operand is always materialized in order to Join
             * input Operand is also materialized because
             * it is used more than once as input, e.g, Join and Transpose
             */
            materialized_op.insert(leaf->output);
            materialized_op.insert(leaf->input[0]);
            assert(leaf->input.size() == 1);
            DPrint("(" << leaf << "," << leaf->output << ",");
            DPrint(leaf->input[0] << ") ");
        }
        // each Operand appears as output exactly once
        outop_to_expr[leaf->output] = leaf;
        // map optim::Expression.input Operand -> abstract::Operand
        if (leaf->parent == nullptr) {
            // final output Operand is a special case
            assert(leaf->input.size() == 1);
            op_to_ph[leaf->input[0]] = execution.output;
            query_size = leaf->input[0]->order.size();
        } else {
            // all other case
            for (auto *in_op : leaf->input) {
                // all Operand appears as input at least once
                if (not op_to_ph.count(in_op)) {
                    op_to_ph[in_op] = execution.NewOperand();
                }
            }
        }
        leaf = leaf->parent;
    }
    DPrintLine("");
    DPrintOperandMap(op_to_ph);
    /* to reduce intermediate results, need to replace it by its Expression
     * therefore should start from the largest Operand
     * therefore need to compute expr_1d
     * 1. if Join Expression input Operand is not materialized
     * then replace it by the Expression of the input, recursively
     * 2. if Join Expression input Operand is edge / non-edge
     * build input Operand as well
     *
     * why build input Operand:
     * only edge / non-edge are required to retrieve from data graph
     *
     * when to build:
     * if Join input Operand has 3 or more vertexes
     * then it must have a non-Join Expression to compute itself
     * therefore this Operand can be built in non-Join Expression
     *
     * if its input Operand has 2 vertexes
     * case 1: an edge that has symmetry breaking rule
     * then it must also be an output of Selection Expression
     *
     * case 2: an edge that does not have symmetry breaking rule
     * case 2.1: if there is no edge that has symmetry breaking rule
     * then it appears as input only in Join Expression
     * case 2.2: if there is another edge that has rule
     * then it also appears as input in a non-Join Expression
     *
     * case 3: a non-edge input Operand only appears here
     *
     * conclusion:
     * case 2.1 and 3 show that size=2 input may appear only here
     * therefore should build them here
     */
    auto costmodel = optimizer.GetCostModel();
    order_1d_t identity_map;
    for (size_t ith = 0; ith < query_size; ith++) {
        identity_map.push_back(ith);
    }
    std::unordered_set<Expression *> intermediate_join_set;
    for (int i_expr = expr_1d.size() - 2; i_expr > -1; i_expr--) {
        // skip the last Expression as it is not a useful Expression
        // constant pointer, pointer value cannot be changed
        auto * const root = expr_1d[i_expr];
        if (intermediate_join_set.count(root)) {
            // skip optim::Expression if it is already processed
            continue;
        }
        // create abstract::Expression for this Expression
        auto *root_out_ph = op_to_ph[root->output];
        auto *root_exe_expr = execution.NewExpression(root_out_ph);
        // initialize abstract::Operand for Expression.output
        auto &root_out_index = root_out_ph->out_index;
        root_out_index.clear();
        for (size_t ith = 0; ith < root->output->order.size(); ith++) {
            root_out_index.push_back(ith);
        }
        DPrintCTX("begin new mapping optim::Expression=" << root);
        DPrintLine(" -> abstract::Expression=" << root_exe_expr);
        root->DebugPrint(true);
        if (root->IsJoin()) {
            /* a Join Expression and its output is not intermediate result
             * step 1 map vertex index from input Operand to root Operand
             * build input and find symmetry breaking rules not populated
             * step 2 map index of intermediate input to root
             * build input and find symmetry breaking rules not populated
             * step 3 build Join into Execution
             * which can further build Join function name or Join argument
             * Join Execution is built at the end because
             * input out_index to final Join output out_index is required
             */
            expression_1d_t sub_expr_1d;
            sub_expr_1d.push_back(root);
            for (size_t ith = 0; ith < sub_expr_1d.size(); ith++) {
                Expression *expr = sub_expr_1d[ith];
                auto &out_index = op_to_ph[expr->output]->out_index;
                // step 1. build input.out_index to output index
                size_t index = 0;
                for (auto &oo : expr->io_vertex_mapping) {
                    /* join Expression
                     * oo=(input Operand index, Operand vertex order)
                     */
                    for (size_t ith = 0; ith < oo.size(); ith += 2) {
                        // op_order[0]-th input -> the index-th output vertex
                        op_to_ph[expr->input[oo[ith]]]->out_index.push_back(
                                out_index[index]);
                    }
                    index++;
                }
                if (expr->output->rule_1d.size()) {
                    /* step 2. output operand contains symmetry breaking rule
                     * when eliminate intermediate result of expr
                     * symmetry breaking not covered by input of expr
                     * should be transfered from execution of expr ->
                     * execution of root_expr, root abstract::Expression
                     */
                    FindJoinSymBreakAsRootVertexIndex(expr, out_index,
                            root_exe_expr->symbreak_index);
                }
                // distribute input placeholder
                for (auto &input : expr->input) {
                    assert(op_to_ph.count(input));
                    /* Operand of size=2 should always be materialized
                     * case 1: Operand size=2 is applied symmetry breaking
                     * then both input Operand (no symmetry breaking)
                     * and output Operand (with symmetry breaking)
                     * appear in materialized_op
                     * case 2: Operand size=2 without symmetry breaking
                     * then input Operand (no symmetry breaking)
                     * does not appear in materialized_op
                     * but it should still be viewed as materialied
                     */
                    if (materialized_op.count(input) or (input->IsInput())) {
                        /* all Operand in input_1d should be materialized one
                         * build edge_index for edge / non-edge input Operand
                         */
                        root_exe_expr->input_1d.push_back(op_to_ph[input]);
                        DPrintCTX("exe_expr=" << root_exe_expr << " input_1d");
                        DPrint(".size()=" << root_exe_expr->input_1d.size());
                        DPrint(" out_index=");
                        DPrintArray(op_to_ph[input]->out_index,
                                op_to_ph[input]->out_index.size());
                        DPrint(" add input ");
                        input->DebugPrint(true);
                        BuildExeOpEdgeIndex(input, costmodel, op_to_ph[input]);
                    } else {
                        /* not materialized, not an edge/non-edge Operand
                         * collect input of sub-Expression
                         */
                        auto sub_expr = outop_to_expr[input];
                        if (sub_expr->IsJoin()) {
                            /* 1. only Join allow to avoid materializing
                             * intermediate result
                             * Rename and Transpose has to materialize
                             * 2. don't build Execution for the same sub_expr
                             * more than once
                             */
                            // assert: each Operand has a unique Expression
                            assert(not intermediate_join_set.count(sub_expr));
                            intermediate_join_set.insert(sub_expr);
                            // recursively collect input of sub_expr
                            sub_expr_1d.push_back(sub_expr);
                        }
                    }
                }
            }
            /* already find all Expression that can execute together
             * step 3 build abstract::Expression for Join
             */
            root_exe_expr->BuildJoin();
        } else {
            /* Rename, Select, Transpose
             * their output Operand must be materialized
             * step 1: build abstract::Expression for Transpose
             * step 2: build symmetry breaking rule into abstract::Expression
             * step 3: build edge_index for edge / non-edge input Operand
             */
            // map input order to output order
            auto in_op = root->input[0];
            order_to_orderset_t bind_set_map;
            if (root->io_vertex_mapping.size()) {
                order_1d_t io_order_map(in_op->order.size());
                size_t out_index = 0;
                for (auto &oo : root->io_vertex_mapping) {
                    /* Transpose needs input output vertex mapping
                     *
                     * just direct copy oo
                     * according to Optimizer::BuildTranspose()
                     * oo[0]-th input vertex maps to 0-th output vertex
                     * the input vertex = Query.v_1d[Operand.order[oo[0]]]
                     */
                    root_exe_expr->io_vertex_index.push_back(oo);
                    /* step 2 map input order to output order (permutation)
                     * override [0, in_op->order.size()) if it is Transpose
                     */
                    io_order_map[oo[0]] = root->output->order[out_index];
                    out_index++;
                }
                GetSymBreakOtherOrder(in_op, io_order_map, bind_set_map);
            } else {
                /* Rename and Select case
                 * because their io_vertex_mapping is empty
                 */
                GetSymBreakOtherOrder(in_op, identity_map, bind_set_map);
            }
            BuildExeExprSymBreak(root, root_out_index, bind_set_map,
                    root_exe_expr->symbreak_index);
            // step 3 build edge_index for input Operand
            auto *placeholder = op_to_ph[in_op];
            root_exe_expr->input_1d.push_back(placeholder);
            BuildExeOpEdgeIndex(in_op, costmodel, placeholder);
            // Rename/Select/Transpose
        }
        DPrintCTX("end   new mapping optim::Expression=" << root);
        DPrintLine(" -> abstract::Expression=" << root_exe_expr);
        root_exe_expr->DebugPrint(true);
    }
    DPrintLine("");
    DPrintCTX("build abstract::Execution with intermediate results");
    DPrintLine(" eliminated");
    execution.DebugPrint(true);
    DPrintLine("");
    if (optimizer.config.SaveIntermediateFile().size()) {
        /* https://stackoverflow.com/a/10151286
         * redirect std::cout to file and then restore
         *
         * save op_to_ph and abstract::Expression to file
         * then it map optim::Operand -> abstract::Operand -> sorttrie::Node
         */
        utility::MkFileDir(optimizer.config.SaveIntermediateFile());
        std::ofstream out_file(optimizer.config.SaveIntermediateFile(),
                std::ios::app);
        auto coutbuf = std::cout.rdbuf(out_file.rdbuf()); //save and redirect
        PrintOperandMap(op_to_ph);
        PrintLine("");
        execution.PrintDetail(true);
        std::cout.rdbuf(coutbuf);   //reset to standard output again
    }
}

// public method
void Optimizer::BuildAllExpression() {
    Expression *top_expr = nullptr;
    if (this->complete_plan.empty()) {
        top_expr = this->BuildOneExpression();
    } else {
        top_expr = this->complete_plan[0];
    }
    while (not this->pool_.empty()) {
        if (this->pool_.top()->IsComplete()
                and this->pool_.top()->cost == top_expr->cost) {
            auto *leaf = this->pool_.top();
            if (PostPopulateSymbreak
                    and (not this->config.DisableSymmetryBreaking())) {
                leaf = this->PopulateSymmetryBreak(leaf);
            }
            leaf = this->ShareNonedge(leaf);
            DPrintCompletePlan(this->complete_plan.size(), leaf);
            this->complete_plan.push_back(leaf);
            this->pool_.pop();
        } else {
            break;
        }
    }
    this->logger.PlanCount = this->complete_plan.size();
}

Expression *Optimizer::BuildOneExpression() {
    const utility::timepoint_t &start_build = utility::GetTimepoint();
    Expression *top_expr = nullptr;
    while (not this->pool_.empty()) {
        auto pool_size = this->pool_.size();
        top_expr = this->pool_.top();
        this->pool_.pop();
        if (top_expr->IsComplete()) {
            break;
        }
        operand_1d_t pending, todo;
        top_expr->PopPendingIsomorphic(todo);
        top_expr->PopPending(pending);
        DPrintPending(todo, pending);
        if (not this->config.ShareSubquery()) {
            while (todo.size() > 1) {
                pending.push_back(todo.back());
                todo.pop_back();
            }
        }
        if (todo.size() > 1) {
            // sharing enumeration is new. build for multiple operands
            // enumerate direct sharing
            djs_group_t group;
            auto head_expr = this->BuildRename(top_expr, todo, group);
            /* enumerate incremental symmetry breaking
             * remove those from rename_group
             */
            if (not PostPopulateSymbreak) {
                head_expr = this->BuildSelection(head_expr, group);
            }
            if (group.size() > 1) {
                this->BuildTranspose(head_expr, group, pending);
            } else {
                head_expr->PushPending(head_expr->input[0]);
                head_expr->PushPending(pending);
                this->pool_.push(head_expr);
            }
        } else {
            // join enumeration is standard
            expression_1d_t buffer;
            buffer.push_back(top_expr);
            for (auto &join_expr : this->BuildJoin(buffer, todo[0])) {
                join_expr->PushPending(pending);
                this->pool_.push(join_expr);
            }
        }
        if (this->pool_.size() < pool_size) {
            // top_expr is dropped, can't be a parent of any Expression
            this->expression_set_.insert(top_expr);
            // some pending are Expression.input_, which are parent of top_e
            this->operand_set_.insert(pending.begin(), pending.end());
            this->operand_set_.insert(todo.begin(), todo.end());
            this->logger.BranchPrunedCount++;
        }
        this->logger.BranchTotalCount++;
    }
    this->logger.DurationBuildOne = utility::GetDuration(start_build);
    if (PostPopulateSymbreak and (not this->config.DisableSymmetryBreaking())) {
        const utility::timepoint_t &start_sym = utility::GetTimepoint();
        top_expr = this->PopulateSymmetryBreak(top_expr);
        this->logger.DurationSymbreakOne = utility::GetDuration(start_sym);
    }
    top_expr = this->ShareNonedge(top_expr);
    if (top_expr != nullptr) {
        DPrintCompletePlan(this->complete_plan.size(), top_expr);
        if (this->config.SaveIntermediateFile().size()) {
            /* https://stackoverflow.com/a/10151286
             * redirect std::cout to file and then restore
             *
             * save op_to_ph and abstract::Expression to file
             * then it map optim::Operand -> abstract::Operand ->
             * graph edge (csr edge / sorttrie::Node)
             */
            utility::MkFileDir(this->config.SaveIntermediateFile());
            std::ofstream out_file(this->config.SaveIntermediateFile(),
                    std::ios::app);
            auto coutbuf = std::cout.rdbuf(out_file.rdbuf()); //save and redirect
            PrintCompletePlan(this->complete_plan.size(), top_expr);
            std::cout.rdbuf(coutbuf);   //reset to standard output again
        }
        this->complete_plan.push_back(top_expr);
        this->logger.PlanCost = top_expr->cost;
    }
    // logger
    auto ptr = top_expr;
    while ((ptr != nullptr) and ptr->parent != nullptr) {
        ptr = ptr->parent;
    }
    if (ptr != nullptr) {
        for (auto &order : ptr->output->order) {
            auto vertex = ptr->output->query->v_1d[order];
            this->logger.MatchVertex += (std::to_string(vertex) + " ");
        }
    }
    this->logger.PoolRemainSize = this->pool_.size();
    if (this->pool_.empty()) {
        this->logger.CostMargin = 0;
    } else {
        this->logger.MultipleCompletePlan = this->pool_.top()->IsComplete();
        this->logger.CostMargin = this->pool_.top()->cost
                - this->logger.PlanCost;
    }
    return top_expr;
}

// private
expression_1d_t Optimizer::BuildJoin(const expression_1d_t &buffer,
        Operand *output) {
    /* best practice to just return the local variable
     * RVO will avoid copy or move
     * https://stackoverflow.com/a/4986802
     */
    expression_1d_t result;
    for (auto g_decomp = Decomposer::Generator(this->decomposer_,
            output->query); g_decomp.InRange(); g_decomp.Next()) {
        for (auto &expr : buffer) {
            // create a join expression with unknown input
            auto join_expr = new Expression(expr, output);
            if (g_decomp.SetDecomposition(join_expr)) {
                // set cost
                this->cost_bound_.SetJoinExpressionCost(join_expr);
                // has valid decomposition
                result.push_back(join_expr);
            } else {
                delete join_expr;
            }
        }
    }
    return result;
}

Expression *Optimizer::BuildRename(Expression *expr, const operand_1d_t &todo,
        djs_group_t &group) {
    /*
     * divide isomorphic Operand into groups based on Operand.Order and
     * Symmetry Breaking rules
     * choose an Operand from each group as head
     * use it to chain remaining Operand by Rename
     */
    djs_t ufs;
    for (auto &operand : todo) {
        ufs.Add(operand);
    }
    // group Operand based on equivalent Order and Symmetry Breaking
    for (size_t index = 1; index < todo.size(); index++) {
        for (size_t base = 0; base < index; base++) {
            if (todo[index]->IsDirectShare(todo[base])) {
                ufs.Union(todo[index], todo[base]);
                // can break because of transitivity of the relationship
                break;
            }
        }
    }
    // get one item from each group, as the head, indexed by a label
    ufs.GetUnionItem(group);
    DPrintCTX("isomorphic size=" << todo.size());
    DPrintLine(" group size=" << group.size());
    // connect Operand to the chosen item of its group
    for (auto &operand : todo) {
        djs_t::label_t label = ufs.Find(operand);
        if (operand != group[label]) {
            // skip chain self
            // 0 cost. a rename expression
            expr = new Expression(expr, operand);
            expr->input.push_back(group[label]);
            DPrintCTX("output(operand)=(" << operand << ") input(operand");
            DPrintLine(",label)=(" << group[label] << "," << label << ")");
            operand->DebugPrint(true);
            group[label]->DebugPrint(true);
        }
    }
    return expr;
}

void Optimizer::BuildTranspose(Expression *head_expr, djs_group_t &group,
        const operand_1d_t &pending) {
    /* chain head of all group together
     * enumerate plan for join
     */
    for (int share_count = group.size() - 1; share_count > -1; share_count--) {
        // the number of Operand will share other result
        Expression *expr = head_expr;
        for (auto gc = algorithm::Combination(group.size(), share_count);
                gc.InRange(); gc.Next()) {
            // suppose A, B, C compute from scratch, D share result
            // choose from A, B, C randomly to share with D
            // therefore transpose cost should be independent of input
            std::unordered_set<size_t> shared_index;
            for (auto &index : gc.combination) {
                shared_index.insert(index);
            }
            DPrintCTX("share combination ");
            DPrintArray(gc.combination, gc.combination.size());
            DPrintLine("");
            // find Operand to be compute from scratch
            auto it_scratch = group.begin();
            for (size_t index = 0; index < group.size(); index++) {
                if (not shared_index.count(index)) {
                    // randomly find the first Operand as scratch
                    break;
                }
                it_scratch++;
            }
            // use it_scratch to chain others by Transpose
            auto it_shared = group.begin();
            for (size_t index = 0; index < group.size(); index++) {
                if (shared_index.count(index)) {
                    // Transpose Expression
                    expr = new Expression(expr, it_shared->second);
                    expr->input.push_back(it_scratch->second);
                    /* compute Transpose vertex order
                     * input.order*transpose.order = output.order
                     * transpose.order = l-inv(input.order)*output.order
                     * l-inv = left-inverse
                     * apply permutation group computation
                     * e.g., order is index of Query.v_1d, therefore
                     * input.order  = (2,0,1) = (0->2, 1->0, 2->1)
                     * output.order = (1,0,2) = (0->1, 1->0, 2->2)
                     * inverse of order is just the reversed mapping
                     * l-inv(input.order)=(2->0,0->1,1->2)=(1,2,0)
                     * transpose.order = (1,2,0)*(1,0,2) = (2,1,0)
                     */
                    order_1d_t inverse(it_scratch->second->order.size());
                    for (size_t ith = 0; ith < it_scratch->second->order.size();
                            ith++) {
                        inverse[it_scratch->second->order[ith]] = ith;
                    }
                    for (auto &order : it_shared->second->order) {
                        // create an element (a vector) of size 0
                        expr->io_vertex_mapping.emplace_back(0);
                        expr->io_vertex_mapping.back().push_back(
                                inverse[order]);
                    }
                    this->cost_bound_.SetTransposeExpressionCost(expr);
                    DPrintCTX("Transpose: output(operand,label)=(");
                    DPrint(it_shared->second << "," << it_shared->first);
                    DPrint(") input(operand,label)=(" << it_scratch->second);
                    DPrintLine("," << it_scratch->first << ")");
                    it_shared->second->DebugPrint(true);
                    it_scratch->second->DebugPrint(true);
                }
                it_shared++;
            }
            // compute scratch by join Expression
            expression_1d_t buffer;
            buffer.push_back(expr);
            auto it_join = group.begin();
            for (size_t index = 0; index < group.size(); index++) {
                if (not shared_index.count(index)) {
                    // build join expression for scratch
                    buffer = this->BuildJoin(buffer, it_join->second);
                }
                it_join++;
            }
            // add Expression back to this->pool_
            for (auto exp : buffer) {
                exp->PushPending(pending);
                this->pool_.push(exp);
            }
        }
    }
}

Expression *Optimizer::BuildSelection(Expression *expr,
        djs_group_t &rename_group) {
    /* enumerate plan for symmetry breaking rules
     * if both plans for (a,b,c) and (a,b,c) a<b are required
     * then the best plan to compute both is to compute (a,b,c)
     * and perform Selection of a<b to get (a,b,c) a<b
     * 1. further group operand based on topology id
     * 2. chain Operand of the same order and super-sub symmetry breaking
     * 3. delete from rename_group if they are obtained from other groups
     */
    typedef algorithm::DisjointSet<djs_t::label_t> symmtry_group_t;
    symmtry_group_t symmetry_group;
    for (auto &label_op : rename_group) {
        symmetry_group.Add(label_op.first);
    }
    // group label of rename group based overlapping symmetry breaking
    auto it_g = rename_group.begin();
    for (it_g++; it_g != rename_group.end(); it_g++) {
        for (auto base = rename_group.begin(); base != it_g; base++) {
            if (it_g->second->IsSameOrder(base->second)) {
                symmetry_group.Union(it_g->first, base->first);
                break;
            }
        }
    }
    // collect rename group
    typedef typename symmtry_group_t::label_t symlabel_t;
    typedef std::vector<it_map_t> group_1d_t;
    std::unordered_map<symlabel_t, group_1d_t> group_map;
    for (it_map_t it_map = rename_group.begin(); it_map != rename_group.end();
            it_map++) {
        group_map[symmetry_group.Find(it_map->first)].push_back(it_map);
    }
    // chain incrementally overlapping symmetry breaking rule
    for (auto &sym_pair : group_map) {
        if (sym_pair.second.size() > 1) {
            std::sort(sym_pair.second.begin(), sym_pair.second.end(),
                    AscSymBreakRuleCount());
            // the first is the head with least number of symmetry breaking
            for (size_t index = sym_pair.second.size() - 1; index > 0;
                    index--) {
                // for each Operand, find its parent
                auto o_label_op = sym_pair.second[index];
                for (int jth = index - 1; jth > -1; jth--) {
                    // Select Expression
                    auto input = sym_pair.second[jth]->second;
                    if (o_label_op->second->ContainSymBreak(input)) {
                        expr = new Expression(expr, o_label_op->second);
                        expr->input.push_back(input);
                        this->cost_bound_.SetSelectExpressionCost(expr);
                        DPrint("Optimizer::BuildSelect(): output(operand,");
                        DPrint("label)=(" << o_label_op->second << ",");
                        DPrint(sym_pair.second[index]->first << ") input(");
                        DPrint("operand,label)=(" << input << ",");
                        DPrintLine(sym_pair.second[jth]->first << ")");
                        // all except the first should be removed
                        rename_group.erase(o_label_op->first);
                    }
                }
            }
        }
    }
    return expr;
}

void Optimizer::CollectExpressionOperand(Expression *expression) {
    this->expression_set_.insert(expression);
    while (expression != nullptr) {
        /* expression.output comes from parent.input
         * therefore no need to collect it
         */
        for (auto &operand : expression->input) {
            this->operand_set_.insert(operand);
        }
        while (not expression->pending.empty()) {
            this->operand_set_.insert(expression->pending.top());
            expression->pending.pop();
        }
        expression = expression->parent;
    }
}

Expression *Optimizer::PopulateSymmetryBreak(Expression * const leaf) {
    /* leaf: the input leaf Expression
     * new_leaf: additional Expression as child of leaf, can be leaf
     * Expression.output is the same pointer as input in another Expression
     * therefore can be used to populate symmetry breaking rules
     * in a top-down direction
     * the last Expression is dummy, output = input[0], input.size()=1
     */
    expression_1d_t expr_1d;
    std::unordered_map<Operand *, order_2d_t> operand_to_symbreak;
    // head is the expression of the Query with the smallest size
    Expression *expression = leaf;
    while (expression != nullptr) {
        expr_1d.push_back(expression);
        expression = expression->parent;
    }
    double best_score = -1;
    for (auto sg = symbreak::SymBreak::Generator(this->symbreak_); sg.InRange();
            sg.Next()) {
        // assign root Query symmetry breaking to input of dummy Expression
        DPrintLine("");
        expr_1d[expr_1d.size() - 1]->input[0]->BuildSymBreak(sg.Item());
        for (int ith = expr_1d.size() - 2; ith > -1;) {
            /* SymBreak should start from the Query of the largest size
             * therefore populate should start from the end of expr_1d
             * -2: skip the last expression (a dummy one)
             * according to how Expression are enumerated
             * Query of the same topology are enumerated together
             * first rename and then transpose and direct computation
             * should populate rules to both rename and transpose together
             */
            // populate rules based on different operator
            auto expr = expr_1d[ith];
            if (expr->IsJoin()) {
                // join
                PopulateJoin(expr);
                ith--;
            } else {
                /* either Rename or Transpose
                 * edge/non-edge cannot be Expression output Operand
                 * therefore edge/non-edge Operand symmetry breaking
                 * is populated in Join
                 */
                PopulateSharing(expr_1d, ith);
            }
        }
        /* at this point rules are already recursively populated to all input
         * estimate the quality of symmetry breaking rules sg.Item()
         */
        auto score = RuleScore(expr_1d);
        if (score > best_score) {
            DPrintCTX("find better symmetry breaking rule score=" << score);
            DPrintLine(" previous best score=" << best_score);
            best_score = score;
            // clear the cache
            for (auto &pair : operand_to_symbreak) {
                for (auto &rule : pair.second) {
                    delete rule;
                }
            }
            operand_to_symbreak.clear();
            // save the rule to cache
            for (auto &expr : expr_1d) {
                for (auto &op : expr->input) {
                    if (not operand_to_symbreak.count(op)) {
                        /* Rename, Transpose can make the same Operand
                         * appear as input more than once
                         * the second time should not override the first time
                         * as rule is already cleared
                         */
                        operand_to_symbreak[op] = op->rule_1d;
                        op->rule_1d.clear();
                    }
                }
            }
        } else {
            // release rule
            for (auto &expr : expr_1d) {
                for (auto &input : expr->input) {
                    input->ClearSymBreak();
                }
            }
        }
    }
    DPrintLine("");
    if (this->symbreak_.Size()) {
        DPrintLCTX("best score=" << best_score);
    } else {
        DPrintLCTX("no symmetry breaking rules");
    }
    this->logger.SymbreakScore = best_score;
    // apply best score SymBreak rule from op_to_sym to expr_1d
    /* 1. collect edge Operand
     * and build Expression to compute symmetry breaking involved
     * 2. need to find direct Rename, Transpose and Select (symmetry rule)
     */
    std::unordered_map<tid_t, operand_1d_t> tid_to_edge1d;
    if (not operand_to_symbreak.empty()) {
        for (int ith = expr_1d.size() - 1; ith > -1; ith--) {
            /* should loop from the top expression
             * because rule are copied to input
             * otherwise expr->DebugPrint(true); can print in-complete info
             */
            for (auto &op : expr_1d[ith]->input) {
                if (operand_to_symbreak.count(op) and op->rule_1d.empty()) {
                    /* some Operand may appear multiple times as input
                     * e.g., Rename and Transpose
                     * therefore
                     * there can be multiple copy into the same Operand
                     * it does not hurt logic
                     * for performance, only copy when rule_1d is empty
                     * i.e., when cache and actual Operand rule do not match
                     */
                    op->rule_1d = operand_to_symbreak[op];
                }
                // for edge Operand symmetry breaking Expression
                if (op->IsInput() and (not op->query->IsEmpty())
                        and op->rule_1d.size()) {
                    // collect only edge Operand with symmetry breaking
                    tid_to_edge1d[op->query->tid].push_back(op);
                }
            }
            expr_1d[ith]->DebugPrint(true);
        }
    }
    /* need further examine symmetry breaking rules on edge Operand
     * edge / non-edge are always materialized
     * but non-edge Operand cannot apply symmetry breaking
     * should determine edge Operand with symmetry breaking
     * is beneficial to materialize
     *
     * case 1:
     * if an edge with symmetry breaking rule is used more than once
     * then it is beneficial to materialize
     * therefore need to create an Expression (Rename / Select)
     *
     * case 2:
     * an edge with symmetry breaking rule is used only once
     * then it is not beneficial to materialize
     * should delete the symmetry breaking rule on the edge Query
     *
     * due to the design of PopulateSymmetryBreak()
     * edge Operand is populated in PopulateJoin
     * therefore need to address both case 1 and case 2
     */
    Expression *new_leaf = leaf;
    for (auto &pair : tid_to_edge1d) {
        // build Rename for directly shared edge Operand
        djs_group_t group_head;
        Expression *old_leaf = new_leaf;
        new_leaf = this->BuildRename(new_leaf, pair.second, group_head);
        /* group_head: each group contains directly share edge Operand
         * leaf: further use group head to chain Operands within the group
         * group head is not chained yet
         * if an edge Operand has symmetry breaking but cannot share
         * then drop its symmetry breaking and avoid materialization
         * should use Join Expression to handle symmetry breaking instead
         *
         * therefore for each head
         * if it contains symmetry breaking
         * and its group size is larger than 1
         * then build Select Expression
         */
        std::unordered_set<Operand *> shared_set;
        if (new_leaf != old_leaf) {
            // new_leaf is child of leaf
            for (auto ptr = new_leaf; ptr->parent != old_leaf; ptr =
                    ptr->parent) {
                /* group head is input to all direct share Operand
                 * therefore group head is shared if it is an input Operand
                 */
                shared_set.insert(ptr->input[0]);
            }
        }
        for (auto &pair : group_head) {
            assert(pair.second->rule_1d.size());
            if (shared_set.count(pair.second)) {
                /* shared, group head is used at least twice
                 * build Select for edge Operand
                 * copy the Operand and with no symmetry breaking rule
                 */
                auto *in_op = new Operand(pair.second->query);
                in_op->order = pair.second->order;
                new_leaf = new Expression(new_leaf, pair.second);
                new_leaf->input.push_back(in_op);
            } else {
                /* then it is an input edge Operand not shared
                 * move Operand symmetry breaking rule to join Expression
                 * there is no need for an Expression to materialize result
                 *
                 * join Expression symmetry breaking rule will be added
                 * when building abstract::Expression
                 */
                DPrintCTX("drop symmetry breaking rule of Operand=");
                DPrintLine(pair.second);
                for (auto rule : pair.second->rule_1d) {
                    delete rule;
                }
                pair.second->rule_1d.clear();
            }
        }
    }
    return new_leaf;
}

Expression *Optimizer::ShareNonedge(Expression * const leaf) {
    // build expression to share non-edge and avoid repeat computation
    std::unordered_map<tid_t, operand_1d_t> tid_to_edge1d;
    for (auto ptr = leaf; ptr != nullptr; ptr = ptr->parent) {
        // get all non-edge Operand
        for (auto &op : ptr->input) {
            if (op->IsInput() and op->query->IsEmpty()) {
                tid_to_edge1d[op->query->tid].push_back(op);
            }
        }
    }
    Expression *new_leaf = leaf;
    for (auto &pair : tid_to_edge1d) {
        // build Rename for direct shared non-edge Operand
        djs_group_t group_head;
        new_leaf = this->BuildRename(new_leaf, pair.second, group_head);
        // leave remaining group head
    }
    return new_leaf;
}

bool Optimizer::AscSymBreakRuleCount::operator()(const it_map_t &a,
        const it_map_t &b) const {
    return a->second->rule_1d.size() < b->second->rule_1d.size();
}

Optimizer::Optimizer(Config &config, Logger &logger, Graph &graph)
        : config(config), logger(logger), topology_table_(config), decomposer_(
                topology_table_) {
    /* note TopologyTable() in the class declaration
     * the declaration does not create a Topology Object
     * the object is created by TopologyTable(Config &)
     */
    auto query = this->topology_table_.GetRootQuery();
    if (config.PowerLaw()) {
        // preferred PowerLaw
        this->cost_bound_.costmodel = new costmodel::PowerLaw(config, graph,
                query, this->symbreak_);
    } else if (config.HyperGeometry()) {
        this->cost_bound_.costmodel = new costmodel::HyperGeometric(config,
                graph, query, this->symbreak_);
    } else {
        PrintLCTX("unknown cost model");
        throw;
    }
    if (not this->cost_bound_.costmodel->edge_match) {
        // Expression does not exist. skip
        return;
    }
    this->symbreak_.Initialize(this->config, query->mapping_1d);
    // initialize pool
    const utility::timepoint_t &start = utility::GetTimepoint();
    OrderGenerator *og = nullptr;
    if (config.OGAdhoc()) {
        og = new ordergenerator::Adhoc(config, *query);
    } else if (config.OGDegreeLabel()) {
        og = new ordergenerator::DegreeLabel(config, graph, *query);
    } else if (config.OGNonAutomorphism()) {
        og = new ordergenerator::NonAutomorphism(query->mapping_1d);
    } else {
        PrintLCTX("unknown OrderGenerator [" << config.OrderGenerator() << "]");
        SystemExit(-1);
    }
    for (; og->InRange(); og->Next()) {
        // build order for operands using non-isomorphic orders only
        DPrintCTX("generate query vertex permutation=");
        DPrintArray(og->permutation, og->permutation.size());
        DPrintLine("");
        if (PostPopulateSymbreak) {
            auto operand = new Operand(query);
            operand->order = og->permutation;               // should copy
            auto expr = new Expression(operand);
            expr->input.push_back(operand);
            expr->pending.push(operand);
            this->cost_bound_.SetInputExpressionCost(expr);
            this->pool_.push(expr);
        } else {
            PrintLine("NotImplemented: enumerate SymBreak in Decomposer");
            SystemExit(-1);
            for (auto sg = symbreak::SymBreak::Generator(this->symbreak_);
                    sg.InRange(); sg.Next()) {
                // for each order, build symmetry breaking rule
                auto operand = new Operand(query);
                operand->order = og->permutation;           // should copy
                operand->BuildSymBreak(sg.Item());
                auto expr = new Expression(operand);
                expr->input.push_back(operand);
                expr->pending.push(operand);
                this->cost_bound_.SetInputExpressionCost(expr);
                this->pool_.push(expr);
            }
        }
    }
    this->logger.DurationInitialPool = utility::GetDuration(start);
    this->logger.PoolInitialSize = this->pool_.size();
    this->logger.AutomorphismCount = query->mapping_1d.size();
    this->logger.SymbreakCount = this->symbreak_.Size();
    DPrintCTX("Initial Pool Size=");
    DPrintLine(this->pool_.size());
}

Optimizer::~Optimizer() {
    /* clear pool
     * a parent Expression * is shared by its children Expression *
     * Operand * are shared among children Expression *
     * clean up complete_plan
     */
    DPrintLine("~Optimizer::Optimizer() " << this);
    for (auto expression : this->complete_plan) {
        this->CollectExpressionOperand(expression);
    }
    // clean up this->pool_
    while (not this->pool_.empty()) {
        Expression *expression = this->pool_.top();
        this->CollectExpressionOperand(expression);
        // This calls the removed element's destructor.
        // destructor of a pointer does nothing
        this->pool_.pop();
    }
    // release resource
    for (auto &item : this->expression_set_) {
        delete item;
    }
    this->expression_set_.clear();
    for (auto &item : this->operand_set_) {
        delete item;
    }
    this->operand_set_.clear();
}

/* https://stackoverflow.com/a/9090656 #undef undefined macro
 * https://stackoverflow.com/a/3504359 #undef function-like macro
 * https://stackoverflow.com/a/33826987 pointless to #undef in source file
 * #undef DPrintBindSetMap
 * #undef PostPopulateSymbreak
 */

} // namespace topdown

} // namespace optim
