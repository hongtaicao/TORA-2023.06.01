/*
 * costbound.cpp
 *
 *  Created on: 10:36 AM Tuesday 2022-11-08
 *      Author: Hongtai Cao
 */

#include <cassert>
#include <unordered_set>

#include "include/common.hpp"
#include "include/optim/costmodel.hpp"
#include "include/optim/expression.hpp"
#include "include/optim/operand.hpp"
#include "include/optim/query.hpp"
#include "include/optim/topdown/costbound.hpp"
#include "include/utility/config.hpp"

namespace optim {

namespace topdown {

void CostBound::SetInputExpressionCost(Expression *expression) const {
    this->costmodel->SetOperandSize(expression->input[0]);
    expression->cost = expression->input[0]->estimate_size;
    DPrintCTX("Expression=" << expression << " parent=" << expression->parent);
    DPrint(" output operand size=" << expression->output->estimate_size);
    DPrint(" cost=" << expression->cost << " input cost lower bound=");
    DPrint(expression->input[0]->estimate_size << " cost change->");
    DPrintLine(expression->cost);
    assert(expression->parent == nullptr);
    // very small double value can lead to negative cost
    // assert(expression->cost >= 0);
}

void CostBound::SetJoinExpressionCost(Expression *expression) const {
    /* estimate Join Expression cost lower bound
     * if there are isomorphic input operand, then only include topology cost
     * don't count cost of Operand.IsInput()
     */
    std::unordered_set<tid_t> topo_set;             // topology_set
    double lower_bound = 0;
    for (auto &operand : expression->input) {
        this->costmodel->SetOperandSize(operand);
        if (not (topo_set.count(operand->query->tid) or operand->IsInput())) {
            /* skip input operand (edge / non-edge)
             * under-estimate transpose cost by ignoring it
             * lower_bound only include (topology_id, constraint_id) once
             */
            topo_set.insert(operand->query->tid);
            lower_bound += operand->estimate_size;
        }
    }
    // should set input operand size first
    double join_cost = this->costmodel->JoinCost(expression);
    /* note there is a dummy head expression
     * nullptr check on expression->parent can be saved
     * expression->cost is initialized as expression->parent->cost
     * therefore should add the cost difference
     * cost increase = join_cost + lower_bound
     * cost decrease = expression->output->estimate_size
     */
    expression->cost += join_cost + lower_bound
            - expression->output->estimate_size;
    DPrintCTX("Expression=" << expression << " parent=" << expression->parent);
    DPrint(" output operand size=" << expression->output->estimate_size);
    DPrint(" join cost=" << join_cost << " input cost lower bound=");
    DPrint(lower_bound << " cost change=" << expression->parent->cost << "->");
    DPrintLine(expression->cost);
    // not always satisfied
    // assert(expression->parent->cost <= expression->cost);
}

void CostBound::SetSelectExpressionCost(Expression *expression) const {
    double select_cost = this->costmodel->SelectCost(expression);
    /* expression->cost is initialized as expression->parent->cost
     * therefore should add the cost difference
     * cost increase = transpose_cost + expression->input[0]->estimate_size
     * cost decrease = expression->output->estimate_size
     */
    expression->cost += select_cost + expression->input[0]->estimate_size
            - expression->output->estimate_size;
    DPrintCTX("Expression=" << expression << " parent=" << expression->parent);
    DPrint(" output operand size=" << expression->output->estimate_size);
    DPrint(" select cost=" << select_cost << " input cost lower bound=");
    DPrint(expression->input[0]->estimate_size << " cost change=");
    DPrintLine(expression->parent->cost << "->" << expression->cost);
    assert(expression->parent->cost <= expression->cost);
}

void CostBound::SetTransposeExpressionCost(Expression *expression) const {
    double transpose_cost = this->costmodel->TransposeCost(expression);
    /* expression->cost is initialized as expression->parent->cost
     * therefore should add the cost difference
     * cost increase = transpose_cost + expression->input[0]->estimate_size
     * cost decrease = expression->output->estimate_size
     */
    expression->cost += transpose_cost + expression->input[0]->estimate_size
            - expression->output->estimate_size;
    DPrintCTX("Expression=" << expression << " parent=" << expression->parent);
    DPrint(" output operand size=" << expression->output->estimate_size);
    DPrint(" transpose cost=" << transpose_cost << " input cost lower bound=");
    DPrint(expression->input[0]->estimate_size << " cost change=");
    DPrintLine(expression->parent->cost << "->" << expression->cost);
    assert(expression->parent->cost <= expression->cost);
}

} // namespace topdown

} // namespace optim
