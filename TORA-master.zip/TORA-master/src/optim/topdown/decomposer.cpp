/*
 * decomposer.cpp
 *
 *  Created on: 16:07 PM Saturday 2022-10-29
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <assert.h>
#include <string>
#include <unordered_set>
#include <utility>          // std::move

#include "include/optim/expression.hpp"
#include "include/optim/operand.hpp"
#include "include/optim/query.hpp"
#include "include/optim/topologytable.hpp"
#include "include/optim/topdown/decomposition.hpp"
#include "include/optim/topdown/decomposer.hpp"

namespace optim {

namespace topdown {

/* how to implement this class. what value should be computed and cached
 * example: a 3-path Query Topology a-b-c-d, abcd.v_1d = [abcd]
 * a decomposition (abc, bcd, ad)
 * representation (note the index is against abcd)
 * abcd.abc.order=[0,1,2], abcd.bcd.order=[1,2,3], abcd.ad.order=[0,3]
 *
 * now consider an Operand as:
 * a 3-path Query b-c-d-e with bcde.order=[1,2,0,3] (cdbe)
 * with known parameters
 * a-b-c-d[iso] <=> b-c-d-e, where iso=[[3,2,1,0],[0,1,2,3]]
 * both iso and Operand.order are index of Query.v_1d
 *
 * b-c-d-e = a-b-c-d[iso], then
 * bcde.order=[1,2,0,3] => abcd[iso].order=[1,2,0,3]
 * if iso=[3,2,1,0], then b-c-d-e = d-c-b-a
 * bcde.order=[1,2,0,3] = cdbe <=> cbda
 * decompose bcde with bcde.order=[1,2,0,3]
 * = decompose abcd with abcd.order=[iso][1,2,0,3]
 * = decompose abcd with abcd.order=[3,2,1,0][1,2,0,3] => [2,1,3,0]
 *
 * then for each decomposed query topology
 * 1. abcd.abc is indexed by abcd.abc.order=[0,1,2]
 * [0,1,2] appears in abcd.order=[2,1,3,0] as [2,1,0]
 * therefore [0,1,2][abcd.abc.order] = [2,1,0]
 * therefore abcd.abc.order=[2,1,0]
 * 2. abcd.bcd is indexed by abcd.bcd.order=[1,2,3]
 * [1,2,3] appears in abcd.order=[2,1,3,0] as [2,1,3]
 * therefore [1,2,3][abcd.bcd.order] = [2,1,3]
 * therefore abcd.bcd.order=[1,0,2]
 * 3. abcd.ad is indexed by abcd.ad.order=[0,3]
 * [0,3] appears in abcd.order=[2,1,3,0] as [3,0]
 * therefore [0,3][abcd.ad.order] = [3,0]
 * therefore abcd.ad.order=[1,0]
 *
 * to compute decomposed operand.order
 * find the index of abcd.abc.order in the abcd.abcd.order
 * then shift into the range
 * abcd.abc.order=[0,1,2], index=[3,1,0] in abcd.abcd.order=[2,1,3,0]
 * shift into consecutive integers, index=[2,1,0]
 *
 * therefore decomposition (abc, bcd, ad) => (cba, cbd, da)
 * need to make order consistent => swap cba and cbd => (cbd, cba, da)
 * sort them based on abcd.order=[2,1,3,0], need un-shifted order
 * need [2,1,3,0] to position index, a reverse mapping
 * position index is the sorting key
 */

inline void DeleteDecomposedQuery(bool is_new, Query *query) {
    if (not is_new) {
        delete query;
    }
}

void Decomposer::DecomposeMaxOverlap(Query *topology,
        decomp_2d_t *decomposition_2d) {
    // decompose a topology with K vertexes -> K-1, K-1 and 2
    // find valid query decomposition for the given topology, the base query
    // create a new decomposition entry in the table and return it
    DPrintLine("");
    DPrintCTX("decompose ");
    topology->DebugPrint(true);
    for (size_t j = 1; j < topology->v_1d.size(); j++) {
        auto vj = topology->v_1d[j];
        for (size_t i = 0; i < j; i++) {
            // generate decomposition
            auto vi = topology->v_1d[i];
            vid_1d_t v_1d_i, v_1d_j, v_1d_ij;
            v_1d_ij.push_back(vi);
            v_1d_ij.push_back(vj);
            for (auto &v : topology->v_1d) {
                if (v == vi) {
                    v_1d_i.push_back(v);
                } else if (v == vj) {
                    v_1d_j.push_back(v);
                } else {
                    v_1d_i.push_back(v);
                    v_1d_j.push_back(v);
                }
            }
            /* create decomposed Query for the given Topology
             * delete them if they are not new Topology later
             */
            DPrintCTX("decompose vertexes q_i=");
            DPrintArray(v_1d_i, v_1d_i.size());
            DPrint(" q_j=");
            DPrintArray(v_1d_j, v_1d_j.size());
            DPrint(" q_ij=");
            DPrintArray(v_1d_ij, v_1d_ij.size());
            DPrintLine("");
            Query *q_i = new Query(topology, std::move(v_1d_i));
            if (not q_i->IsConnected()) {
                DPrintCTX("skip not connected q_i ");
                q_i->DebugPrint(true);
                delete q_i;
                continue;
            }
            Query *q_j = new Query(topology, std::move(v_1d_j));
            if (not q_j->IsConnected()) {
                // skip unconnected subquery
                DPrintCTX("skip not connected q_j ");
                q_j->DebugPrint(true);
                delete q_j;
                continue;
            }
            // this is an edge or a non-edge
            Query *q_ij = new Query(topology, std::move(v_1d_ij));
            // check if they are new topology
            auto is_new_i = this->topology_table_.Index(q_i);
            auto is_new_j = this->topology_table_.Index(q_j);
            auto is_new_ij = this->topology_table_.Index(q_ij);
            /* should not form an ordered tid as key to prune decomposition
             * although decomposed Query topology set can be equivalent
             * in fact they assemble vertexes differently
             * therefore should not prune such decomposition
             */
            // need to transform Topology.v_1d to decomposed Query.v_1d
            decomp_1d_t *decomp_ptr = new decomp_1d_t;
            auto &decomp_1d = *decomp_ptr;
            /* all Query are represented by the topology
             * topology -> Query transform is kept in Query.mapping_1d
             */
            // push back argument is a r-value
            decomp_1d.push_back(
                    new Decomposition(this->topology_table_[q_i->tid]));
            decomp_1d.push_back(
                    new Decomposition(this->topology_table_[q_j->tid]));
            decomp_1d.push_back(
                    new Decomposition(this->topology_table_[q_ij->tid]));
            /* generate index to topology->v_1d
             * need to transform topology.v_1d order to subquery.v_1d
             * if Query is a new Topology, then identity transformation
             * if Query.mapping_1d contains [0,1,2, ...]
             * then identity transformation
             */
            for (size_t k = 0; k < topology->v_1d.size(); k++) {
                if (k == i) {
                    decomp_1d[0]->MapParentIndex(k, q_i);
                    decomp_1d[2]->MapParentIndex(k, q_ij);
                } else if (k == j) {
                    decomp_1d[1]->MapParentIndex(k, q_j);
                    decomp_1d[2]->MapParentIndex(k, q_ij);
                } else {
                    decomp_1d[0]->MapParentIndex(k, q_i);
                    decomp_1d[1]->MapParentIndex(k, q_j);
                }
            }
            DPrintLine("");
            DPrintCTX("find tid=" << topology->tid << " decomposition=");
            DPrintLine(decomposition_2d->size());
            decomp_1d[0]->DebugPrint(false);
            q_i->DebugPrint(true);
            decomp_1d[1]->DebugPrint(false);
            q_j->DebugPrint(true);
            decomp_1d[2]->DebugPrint(false);
            q_ij->DebugPrint(true);
            DPrintLine("");
            decomposition_2d->push_back(decomp_ptr);
            // delete decomposed Query
            DeleteDecomposedQuery(is_new_i, q_i);
            DeleteDecomposedQuery(is_new_j, q_j);
            DeleteDecomposedQuery(is_new_ij, q_ij);
        }
    }
    DPrintLine("");
}

// cannot inline in source file. otherwise
// undefined reference to `optim::topdown::Decomposer::Generator::InRange()
bool Decomposer::Generator::InRange() {
    return this->ith_ < this->decomposition_->size();
}

bool Decomposer::Generator::SetDecomposition(Expression *expression) {
    /* map topology decomposition to expression.output (Operand)
     * both iso mappings and Operand.order are permutations of Topology.v_1d
     * therefore permutation index can be viewed as vertex directly
     */
    /* there is no need to do such transformation to transform
     * topology -> iso -> query -> operand.order
     * where topology_order = iso->query->operand.order
     *
     * because every query is represented by the topology
     * using the current design of topology table
     * therefore operand.order is directly viewed as order on Topology.v_1d
     */
    /* vid_1d_t topology_order; // this is index of Topology.v_1d
     * for (auto index : expression->output->order) {
     *     topology_order.push_back((*this->iso_mapping_)[index]);
     * }
     */
    // create decomposed operand using cached decomposition over topology
    auto decomp_1d = (*this->decomposition_)[this->ith_];
    // sort decomposition such that the order is consistent with output order
    std::sort(decomp_1d->begin(), decomp_1d->end(),
            Decomposition::Comparator(expression->output->order));
    expression->io_vertex_mapping.resize(expression->output->order.size());
    vid_t i_index = 0;          // the index of input operand to join
    for (auto dec : (*decomp_1d)) {
        auto input_operand = new Operand(dec->topology);
        vid_t o_index = 0;     // the index of output vertex
        for (auto order : expression->output->order) {
            if (dec->HasParentIndex(order)) {
                // find the input operand order
                auto i_order = dec->p_to_sub_index[order];
                input_operand->order.push_back(i_order);
                /* the o_index-th output vertex is the join result of the
                 * i_index-th input operand and its i_order-th query vertex
                 *
                 * the o_index-th output vertex =
                 * output query->v_1d[output operand->order[o_index]]
                 *
                 * the i_order-th query vertex =
                 * input query->v_1d[i_order]
                 */
                // used to generate operand and attribute to join
                expression->io_vertex_mapping[o_index].push_back(i_index);
                // used to populate symmetry breaking rule
                expression->io_vertex_mapping[o_index].push_back(i_order);
            }
            o_index++;
        }
        expression->input.push_back(input_operand);
        if (not input_operand->IsInput()) {
            expression->PushPending(input_operand);
        }
        i_index++;
    }
    DPrintLCTX("decomposition=" << this->ith_);
    expression->DebugPrint(true);
    return not decomp_1d->empty();
}

Decomposer::Generator::Generator(Decomposer &decomposer, Query *query)
        : ith_(0) {
    assert(query->tid > 0);
    if (not decomposer.tid_to_decomp_.count(query->tid)) {
        // a new query topology. does not have a decomposition yet
        auto topology = decomposer.topology_table_.GetTopology(query->tid);
        auto decomposition_2d = new decomp_2d_t;
        decomposer.tid_to_decomp_[query->tid] = decomposition_2d;
        // support switch to different decomposition methods
        decomposer.DecomposeMaxOverlap(topology, decomposition_2d);
    }
    this->decomposition_ = decomposer.tid_to_decomp_[query->tid];
    this->iso_mapping_ = query->mapping_1d[0]; // choose a random one
}

Decomposer::~Decomposer() {
    // delete this->tid_to_decomp_
    for (auto &pair : this->tid_to_decomp_) {
        for (auto decomp_1d : (*pair.second)) {
            for (auto decomposition : (*decomp_1d)) {
                delete decomposition;
            }
            delete decomp_1d;
        }
        delete pair.second;
    }
}

} // namespace topdown

} // namespace optim
