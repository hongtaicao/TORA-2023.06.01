/*
 * powerlaw.cpp
 *
 *  Created on: 10:46 AM Monday 2022-11-07
 *      Author: Hongtai Cao
 */

#include <cassert>
#include <cmath>            // std::pow

#include "include/optim/costmodel/powerlaw.hpp"
#include "include/optim/expression.hpp"
#include "include/optim/graph.hpp"
#include "include/optim/operand.hpp"
#include "include/optim/query.hpp"

namespace optim {

namespace costmodel {

// private
void PowerLaw::InitializeSizeTable(Operand *operand,
        trie_size_1d_t &size_table) {
    // set operand.size_table and operand.estimate_size
    /* case 1: add a new vertex -> gamma_[i]
     * case 2: add a new edge -> rho * gamma_[i] * gamma_[j]
     */
    // should initialize TrieSize1d
    DPrintCTX("operand=" << operand << " (permutation, size)=");
    size_table.resize(operand->order.size());
    // get the edge size
    order_t a = operand->order[0], b = operand->order[1];
    vid_t va = operand->query->v_1d[a], vb = operand->query->v_1d[b];
    double estimate_size = this->EdgeSize(va, vb);
    // these two are accurate and already consider vertex label
    size_table[a] = this->RootSize(va, vb);
    size_table[b] = this->AverageOutNeighborSize(va, vb);
    DPrint("(" << a << "," << size_table[a] << ") ");
    DPrint("(" << b << "," << size_table[b] << ") ");
    // set up degree sequence for each subgraph
    vid_map_t degree_map;
    if (operand->query->HasEdge(va, vb)) {
        degree_map[va]++;
        degree_map[vb]++;
    }
    if (operand->query->HasEdge(vb, va)) {
        degree_map[va]++;
        degree_map[vb]++;
    }
    // starting from the 3rd vertex, whose index=2
    for (size_t j = 2; j < operand->order.size(); j++) {
        // case 1: add a new vertex
        vid_t vj = operand->query->v_1d[operand->order[j]];
        size_t skip_order = 0;
        double factor = this->graph_.VertexSize();
        for (; skip_order < j; skip_order++) {
            vid_t vs = operand->query->v_1d[operand->order[skip_order]];
            if (operand->query->HasEdge(vs, vj)
                    or operand->query->HasEdge(vj, vs)) {
                factor = this->gamma_1d_[degree_map[va]];
                break;
            }
        }
        // consider vertex label
        estimate_size *=
                (factor * this->label_ratio_[operand->query->Label(vj)]);
        // case 2: add new edges connecting to the new vertex
        for (size_t i = 0; i < j; i++) {
            if (i == skip_order) {
                // this edge is already added
                continue;
            }
            vid_t vi = operand->query->v_1d[operand->order[i]];
            // case 2 should skip unknown edges
            /*
             * if (operand->query->HasUnknownEdge(vi, vj)) {
             *     continue;
             * }
             */
            auto out_edge = operand->query->HasEdge(vi, vj);
            auto in_edge = operand->query->HasEdge(vj, vi);
            if (out_edge || in_edge) {
                estimate_size *= (this->rho_ * this->gamma_1d_[degree_map[vi]]
                        * this->gamma_1d_[degree_map[vj]]);
                // update degree after adding a new edge
                if (out_edge and in_edge) {
                    // bi-directed edge
                    degree_map[vi] += 2;
                    degree_map[vj] += 2;
                } else {
                    // a single directed edge
                    degree_map[vj]++;
                    degree_map[vi]++;
                }
            }
        }
        size_table[operand->order[j]] = estimate_size
                / size_table[operand->order[j - 1]];
        DPrint("(" << operand->order[j] << ",");
        DPrint(size_table[operand->order[j]] << ") ");
    }
    DPrintLine("");
}

PowerLaw::PowerLaw(Config &config, Graph &graph, Query *query, SymBreak &sb)
        : CostModel(config, graph, query, sb), rho_(1.0) {
    if (not this->edge_match) {
        /* skip initialization
         * should guarantee below won't run into 0 denominator issue
         */
        this->gamma_1d_ = nullptr;
        return;
    }
    // find data graph vertex degree
    vid_map_t vertex_degree;
    // find data vertex label
    vid_vset_map_t label_to_vertex;
    // assume vertex degree and vertex label are independent
    for (auto &v_neighbor : query->VertexNeighbor()) {
        auto &label_a_vset = label_to_vertex[query->Label(v_neighbor.first)];
        for (auto &b : v_neighbor.second) {
            // only edges match the query label set matter
            auto label_key = this->LabelKey(v_neighbor.first, b);
            if (not graph.HasEdgeIndex(label_key)) {
                // data graph does not match such a query edge
                continue;
            }
            auto edge_index = graph.EdgeIndex(label_key);
            auto &label_b_vset = label_to_vertex[query->Label(b)];
            for (vid_t ith = 0; ith < graph.RootSize(edge_index); ith++) {
                auto va = graph.RootVertex(edge_index, ith);
                // count vertex degree
                vertex_degree[va] += graph.OutDegree(edge_index, va);
                // count vertex label for root
                label_a_vset.insert(va);
                for (eid_t jth = 0; jth < graph.OutDegree(edge_index, ith);
                        jth++) {
                    // count vertex label for leaf
                    label_b_vset.insert(graph.OutVertex(edge_index, ith, jth));
                }
            }
        }
    }
    vid_map_t label_counter;
    for (auto &pair : label_to_vertex) {
        label_counter[pair.first] = pair.second.size();
    }
    vid_map_t degree_count;
    for (auto &pair : vertex_degree) {
        if (degree_count.count(pair.second)) {
            degree_count[pair.second] += 1;
        } else {
            degree_count[pair.second] = 1;
        }
    }
    // compute gamma and rho
    DPrintLine("");
    DPrintCTX("gamma_1d_");
    /* valgrind reports
     * Invalid write of size 8
     * Address 0xb4b42d0 is 0 bytes after a block of size 32 alloc'd
     *
     * this means access this->gamma_1d_ out of bound
     */
    auto gamma_size = query->v_1d.size() * 2;
    this->gamma_1d_ = new double[gamma_size];
    for (size_t i = 0; i < gamma_size; i++) {
        double numerator = 0.0, denominator = 0.0;
        for (auto &pair : degree_count) {
            /*
             * degree: pair.first
             * count: pair.second
             * degree**(i+1) * count = (degree**i * count) * degree
             * degree**i * count
             */
            double subresult = std::pow(pair.first, i) * pair.second;
            numerator += (subresult * pair.first);
            denominator += subresult;
        }
        assert(numerator > denominator);
        assert(denominator > 0);
        /* this is case 1 gamma, where a new vertex is added
         * use the power of the denominator as the key
         */
        this->gamma_1d_[i] = numerator / denominator;
        DPrint(" [" << i << "]=" << this->gamma_1d_[i]);
        /* see Power-Law Random (PR) Graph Model of its Technical Report
         * page 6
         */
        if (i == 0) {
            // rho = 1.0 / sum(vertex degree)
            this->rho_ = 1.0 / numerator;
        }
    }
    DPrintLine("");
    DPrintLCTX("rho=" << this->rho_);
    // compute vertex label ratio
    size_t vertex_counter = 0;
    for (auto &pair : label_counter) {
        vertex_counter += pair.second;
    }
    DPrintCTX("label_ratio_");
    for (auto &pair : label_counter) {
        this->label_ratio_[pair.first] = 1.0 * pair.second / vertex_counter;
        DPrint(" [" << pair.first << "]=" << this->label_ratio_[pair.first]);
    }
    DPrintLine("");
}

} // namespace costmodel

} // namespace optim
