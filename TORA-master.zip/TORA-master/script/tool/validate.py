#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '16:39 PM Tuesday Feb 7 2022'
__doc__ = '''validate.py
validate computation result
'''


import copy, math


def table_size(size_table):
    print('order size')
    total = 1
    for order, size in size_table:
        print(order, size)
        total *= size
    print('total table size=', total)


def qrqc_5star():
    # table size can be the output size, but not useful for cost bound
    table_size([(0,5241),(1,5241),(2,5241),(3,5241),(5,5241),(4,3.89392e-007)])
    table_size([(0,5241),(1,5241),(2,5241),(4,0.00438529),(3,49.3866),(5,49.3866)])
    table_size([(0,5241),(4,49.3866),(1,49.3866),(2,49.3866),(3,49.3866),(5,49.3866)])



path6_bad_plan = {
    'io_vertex_mapping': '0_1_,0_2_,1_2_,0_1_,0_1_,0_1_,',
    'output_table' : [(1,5241), (0,49.3866), (3,5241), (4,49.3866), (5,49.3866), (2,0.465376)],
    'size_table' : [
        [(0,5241), (3,5241), (4,49.3866), (2,49.3866), (1,0.465376)],
        [(1,5241), (0,49.3866), (3,5241), (4,49.3866), (2,0.465376)],
        [(0,5241), (1,5241)],
    ],
}


path6_good_plan = {
    'io_vertex_mapping' : '0_1_,0_2_,0_2_,0_2_,0_2_,1_2_,',
    'output_table' : [(0,5241), (1,49.3866), (2,49.3866), (5,49.3866), (4,49.3866), (3,49.3866)],
    'size_table' : [
        [(0,5241), (1,49.3866), (2,49.3866), (4,49.3866), (3,49.3866)],
        [(0,5241), (1,5241) ],
        [(0,5241), (1,49.3866), (2,49.3866), (4,49.3866), (3,49.3866)],
    ],
}


def hashtrie_joincost_v1(parameter_dic):
    # cost += parent_trie_width * hash_loop_size * oo.size() / 2;
    print('======= start hashtrie_joincost_v1 ======')
    print('min_size * (1 + std::log(max_size / min_size))')
    parameter_dic = copy.deepcopy(parameter_dic)
    io_vertex_mapping = parameter_dic['io_vertex_mapping']
    output_table = parameter_dic['output_table']
    size_table = parameter_dic['size_table']
    cost = 0
    out_index = 0
    parent_trie_width = 1
    for input_1d in io_vertex_mapping.split(','):
        if not input_1d:
            continue
        counter = 0
        hash_loop_size = -1
        result_size = output_table[out_index][1]
        for index in input_1d.split('_'):
            if not index:
                continue
            table = size_table[int(index)]
            ith = 0
            while ith < len(table):
                if table[ith]:
                    break
                ith += 1
            size = table[ith][1]
            # erase data as it is used
            table[ith] = tuple()
            print('relation index=', index, 'ith=', ith, 'size=', size)
            if hash_loop_size == -1:
                hash_loop_size = size
            else:
                hash_loop_size = min(hash_loop_size, size)
            counter += 1
        join_cost = hash_loop_size * counter
        cost_inc = parent_trie_width * join_cost
        print('out_index=', out_index,
            'parent_trie_width=%e' % (parent_trie_width),
            'result_size=%e' % (result_size))
        print('join_cost=%e' % (join_cost), 'cost_inc=%e' % (cost_inc))
        cost += cost_inc
        parent_trie_width *= result_size
        out_index += 1
    print('hashtrie_joincost_v1=%e' % (cost))
    return cost


def hashtrie_joincost_v1_path6():
    plan_bad = hashtrie_joincost_v1(path6_bad_plan)
    plan_good = hashtrie_joincost_v1(path6_good_plan)
    print('====== comparison ======')
    print('bad  plan 4 2-1-0-5 3 cost=%e' % (plan_bad))
    print('good plan 4-5-0-1-2-3 cost=%e' % (plan_good))
    print('works for this query')


def sorttrie_joincost_v1(parameter_dic):
    # cost += parent_trie_width * min_size * (1 + std::log(max_size / min_size));
    print('======= start sorttrie_joincost_v1 ======')
    print('min_size * (1 + std::log(max_size / min_size))')
    parameter_dic = copy.deepcopy(parameter_dic)
    io_vertex_mapping = parameter_dic['io_vertex_mapping']
    output_table = parameter_dic['output_table']
    size_table = parameter_dic['size_table']
    cost = 0
    out_index = 0
    parent_trie_width = 1
    for input_1d in io_vertex_mapping.split(','):
        if not input_1d:
            continue
        min_size = -1
        max_size = -1
        result_size = output_table[out_index][1]
        for index in input_1d.split('_'):
            if not index:
                continue
            table = size_table[int(index)]
            ith = 0
            while ith < len(table):
                if table[ith]:
                    break
                ith += 1
            size = table[ith][1]
            # erase data as it is used
            table[ith] = tuple()
            print('relation index=', index, 'ith=', ith, 'size=', size)
            if min_size < 0:
                min_size = size
            else:
                min_size = min(min_size, size)
            if max_size < 0:
                max_size = size
            else:
                max_size = max(max_size, size)
        min_size = max(min_size, result_size) # does not matter
        join_cost = min_size * (1 + math.log(max_size / min_size))
        cost_inc = parent_trie_width * join_cost
        print('out_index=', out_index,
            'parent_trie_width=%e' % (parent_trie_width),
            'max_size=', max_size, 'min_size=', min_size,
            'result_size=%e' % (result_size))
        print('join_cost=%e' % (join_cost), 'cost_inc=%e' % (cost_inc))
        cost += cost_inc
        parent_trie_width *= result_size
        out_index += 1
    print('sorttrie_joincost_v1=%e' % (cost))
    return cost


def sorttrie_joincost_v1_path6():
    plan_bad = sorttrie_joincost_v1(path6_bad_plan)
    plan_good = sorttrie_joincost_v1(path6_good_plan)
    print('====== comparison ======')
    print('bad  plan 4 2-1-0-5 3 cost=%e' % (plan_bad))
    print('good plan 4-5-0-1-2-3 cost=%e' % (plan_good))
    print('bad  plan has a lower cost is due to'
        ' the leaf level join cost_inc is low')


def sorttrie_joincost_v2(parameter_dic):
    # with some bounds
    print('======= start sorttrie_joincost_v2 ======')
    print('min_size * (1 + max(1, math.log(max_size / min_size))) * max(1, math.log(counter))')
    parameter_dic = copy.deepcopy(parameter_dic)
    io_vertex_mapping = parameter_dic['io_vertex_mapping']
    output_table = parameter_dic['output_table']
    size_table = parameter_dic['size_table']
    cost = 0
    out_index = 0
    parent_trie_width = 1
    for input_1d in io_vertex_mapping.split(','):
        if not input_1d:
            continue
        counter = 0
        join_cost = 0
        max_size = -1
        min_size = -1
        result_size = output_table[out_index][1]
        for index in input_1d.split('_'):
            if not index:
                continue
            table = size_table[int(index)]
            ith = 0
            while ith < len(table):
                if table[ith]:
                    break
                ith += 1
            size = table[ith][1]
            # erase data as it is used
            table[ith] = tuple()
            print('relation index=', index, 'ith=', ith, 'size=', size)
            if min_size < 0:
                min_size = size
            else:
                min_size = min(min_size, size)
            if max_size < 0:
                max_size = size
            else:
                max_size = max(max_size, size)
            counter += 1
        join_cost = min_size * (1 + max(1, math.log(max_size / min_size))) * max(1, math.log(counter))
        cost_inc = parent_trie_width * join_cost
        print('out_index=', out_index,
            'parent_trie_width=%e' % (parent_trie_width))
        print('min_size=', min_size, 'result_size=%e' % (result_size))
        print('join_cost=%e' % (join_cost), 'cost_inc=%e' % (cost_inc))
        cost += cost_inc
        parent_trie_width *= result_size
        out_index += 1
    print('sorttrie_joincost_v2=%e' % (cost))
    return cost


def sorttrie_joincost_v2_path6():
    plan_bad = sorttrie_joincost_v2(path6_bad_plan)
    plan_good = sorttrie_joincost_v2(path6_good_plan)
    print('====== comparison ======')
    print('bad  plan 4 2-1-0-5 3 cost=%e' % (plan_bad))
    print('good plan 4-5-0-1-2-3 cost=%e' % (plan_good))
    print('works for this query')

def sorttrie_joincost_v3(parameter_dic):
    # cost += parent_trie_width * sum(size * (1 + std::log(size / result_size)));
    print('======= start sorttrie_joincost_v3 ======')
    print('size * (1 + std::log(size / result_size))')
    parameter_dic = copy.deepcopy(parameter_dic)
    io_vertex_mapping = parameter_dic['io_vertex_mapping']
    output_table = parameter_dic['output_table']
    size_table = parameter_dic['size_table']
    cost = 0
    out_index = 0
    parent_trie_width = 1
    for input_1d in io_vertex_mapping.split(','):
        if not input_1d:
            continue
        join_cost = 0
        result_size = output_table[out_index][1]
        for index in input_1d.split('_'):
            if not index:
                continue
            table = size_table[int(index)]
            ith = 0
            while ith < len(table):
                if table[ith]:
                    break
                ith += 1
            size = table[ith][1]
            # erase data as it is used
            table[ith] = tuple()
            print('relation index=', index, 'ith=', ith, 'size=', size)
            join_cost += size * (1 + math.log(size / result_size))
        cost_inc = parent_trie_width * join_cost
        print('out_index=', out_index,
            'parent_trie_width=%e' % (parent_trie_width))
        print('result_size=%e' % (result_size))
        print('join_cost=%e' % (join_cost), 'cost_inc=%e' % (cost_inc))
        cost += cost_inc
        parent_trie_width *= result_size
        out_index += 1
    print('sorttrie_joincost_v3=%e' % (cost))
    return cost


def sorttrie_joincost_v3_path6():
    plan_bad = sorttrie_joincost_v3(path6_bad_plan)
    plan_good = sorttrie_joincost_v3(path6_good_plan)
    print('====== comparison ======')
    print('bad  plan 4 2-1-0-5 3 cost=%e' % (plan_bad))
    print('good plan 4-5-0-1-2-3 cost=%e' % (plan_good))
    print('bad  plan has a lower cost is due to'
        ' the leaf level join cost_inc is low')


def sorttrie_joincost_v4(parameter_dic):
    # with some bounding
    print('======= start sorttrie_joincost_v4 ======')
    print('min_size * max(1, math.log(min_size)) * max(1, math.log(counter))')
    parameter_dic = copy.deepcopy(parameter_dic)
    io_vertex_mapping = parameter_dic['io_vertex_mapping']
    output_table = parameter_dic['output_table']
    size_table = parameter_dic['size_table']
    cost = 0
    out_index = 0
    parent_trie_width = 1
    for input_1d in io_vertex_mapping.split(','):
        if not input_1d:
            continue
        counter = 0
        join_cost = 0
        min_size = -1
        result_size = output_table[out_index][1]
        for index in input_1d.split('_'):
            if not index:
                continue
            table = size_table[int(index)]
            ith = 0
            while ith < len(table):
                if table[ith]:
                    break
                ith += 1
            size = table[ith][1]
            # erase data as it is used
            table[ith] = tuple()
            print('relation index=', index, 'ith=', ith, 'size=', size)
            if min_size < 0:
                min_size = size
            else:
                min_size = min(min_size, size)
            counter += 1
        join_cost = min_size * max(1, math.log(min_size)) * max(1, math.log(counter))
        cost_inc = parent_trie_width * join_cost
        print('out_index=', out_index,
            'parent_trie_width=%e' % (parent_trie_width))
        print('min_size=', min_size, 'result_size=%e' % (result_size))
        print('join_cost=%e' % (join_cost), 'cost_inc=%e' % (cost_inc))
        cost += cost_inc
        parent_trie_width *= result_size
        out_index += 1
    print('sorttrie_joincost_v4=%e' % (cost))
    return cost


def sorttrie_joincost_v4_path6():
    plan_bad = sorttrie_joincost_v4(path6_bad_plan)
    plan_good = sorttrie_joincost_v4(path6_good_plan)
    print('====== comparison ======')
    print('bad  plan 4 2-1-0-5 3 cost=%e' % (plan_bad))
    print('good plan 4-5-0-1-2-3 cost=%e' % (plan_good))
    print('bad  plan has a lower cost is due to'
        ' the leaf level join cost_inc is low')


def sorttrie_logvalue():
    for max_size, min_size in [(5241, 4.938660e+01), (4.653760e-01, 4.653760e-01)]:
        f1 = min_size * max(1, math.log(max_size / min_size))
        f2 = min_size * math.log(min_size)
        print(f1, f2)


if __name__ == '__main__':
    # qrqc_5star()
    sorttrie_joincost_v1_path6()
    sorttrie_joincost_v2_path6()
    sorttrie_joincost_v3_path6()
    sorttrie_joincost_v4_path6()
    hashtrie_joincost_v1_path6() # this works
