#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '17:56 PM Tuesday April 11 2023'
__doc__ = '''compare_directory.py
'''

import filecmp, os, sys


def _get_name_set(in_path):
    for file_path in _walk_dir(in_path):
        yield file_path.split(in_path)[-1]


def _walk_dir(in_path):
    if os.path.isdir(in_path):
        for name in os.listdir(in_path):
            for file_path in _walk_dir(in_path + '/' + name):
                yield file_path
    elif os.path.isfile(in_path):
        yield in_path
    else:
        print('error. neither directory or file:', in_path)


def compare_directory(dir1, dir2):
    name1_set = set(x for x in _get_name_set(dir1))
    name2_set = set(x for x in _get_name_set(dir2))
    for name in sorted(name1_set & name2_set):
        if filecmp.cmp(dir1 + '/' + name, dir2 + '/' + name):
            continue
        print('find different files:', name)


if __name__ == '__main__':
    compare_directory(sys.argv[1], sys.argv[2])
