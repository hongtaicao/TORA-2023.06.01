#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '15:1 PM Friday March 3 2022'
__doc__ = '''rename.py
rename file names
'''


import os


def rename_file(directory, callback):
    for path in walk_directory(directory):
        dirname = os.path.dirname(path)
        basename = callback(os.path.basename(path))
        os.rename(path, dirname + os.path.sep + basename)


def rename_underscore_to_dash(directory):
    # rename all file recursively in directory
    for path in walk_directory(directory):
        rename_file(path, underscore_to_dash)


def underscore_to_dash(name):
    return name.replace('_', '-')


def walk_directory(path):
    if os.path.isfile(path):
        yield path
    else:
        for item in os.listdir(path):
            for new_path in walk_directory(path + os.path.sep + item):
                yield new_path


if __name__ == '__main__':
    rename_underscore_to_dash('../../dataset')
