#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '1:02 PM Thursday April 20 2023'
__doc__ = '''log_to_spreadsheet.py
read its screen output and create a csv file


example:

start command line at 2023_04_19-17_46_12
compilation time: Apr 19 2023 17:46:04
compiler (g++) version: 7.5.0
compile flag priority: COUNTING > LISTING > MEMORY
-DNDEBUG, debug mode disabled
-DCOUNTING, counting
program version: v0.1
./release.exe -algorithm AutoMineCSR -cost-model HyperGeometry -execute dynamic -graph-storage CSR -is-labeled 0 -data-file /home/hongtai2/project/TORA/dataset//unlabeled-grqc.txt -query-file /home/hongtai2/project/TORA/dataset//unlabeled-query//u-3-triangle-collision.txt -query-name 3-triangle-collision

============ Program Argument Begin ============
Int [-automorphism=0]
Int [-is-labeled=0]
Int [-sample-count=100]
Int [-sample-retry-count=100]
Int [-sample-subgraph-size=6]
Int [-share-subquery=1]
String [-algorithm=AutoMineCSR]
String [-binary-directory=/home/hongtai2/project/TORA/dataset//unlabeled-grqc]
String [-cost-model=HyperGeometry]
String [-data-file=/home/hongtai2/project/TORA/dataset//unlabeled-grqc.txt]
String [-execute=dynamic]
String [-graph-storage=CSR]
String [-label-file=/home/hongtai2/project/TORA/dataset//unlabeled-grqc/label.txt]
String [-operand-size=TrieSize]
String [-query-file=/home/hongtai2/project/TORA/dataset//unlabeled-query//u-3-triangle-collision.txt]
String [-query-name=3-triangle-collision]
String [-save-file=]
String [-save-intermediate-file=]
String [-symmetry-breaking=SymBreak2007]
String [DateTime=2023_04_19-17_46_12]
============ Program Argument End   ============

DurationReadBinaryGraph(s)=0
Default: COUNTING
automine_csr DurationExecutionCompiled(s)=0.025 MatchCount=52669
stop command line at 2023_04_19-17_46_12
total_seconds=0.03,max_Kbytes=4296

start command line at 2023_04_19-17_46_12
...
DurationReadBinaryGraph(s)=0.01
DurationBuildOne(s)=0.025 DurationSymbreakOne(s)=0
AutomorphismCount=6 MatchVertex=5 4 3 2 1 0  SymbreakCount=6 SymbreakScore=5.35328e+09
DurationExecutionDynamic(s)=22.847 MatchCount=5672
append result summary file=v0.1-log.csv
stop command line at 2023_04_15-19_04_18
total_seconds=23.08,max_Kbytes=3411300

'''

HasPandas = True
try:
    import pandas as pd
except:
    HasPandas = False

import os, sys


# define configuration to write to out_file
COLUMNS = {
    'automorphism=': '',
    'is-labeled=': '',
    'sample-count=': '',
    'sample-retry-count=': '',
    'sample-subgraph-size=': '',
    'share-subquery=': '',
    'algorithm=': '',
    'binary-directory=': '',
    'cost-model=': '',
    'data-file=': '',
    'execute=': '',
    'label-file=': '',
    'operand-size=': '',
    'query-file=': '',
    'query-name=': '',
    'save-file=': '',
    'save-intermediate-file=': '',
    'symmetry-breaking=': '',
    'DateTime=': '',
    'DurationReadBinaryGraph(s)=': '',
    'DurationBuildOne(s)=': '',
    'DurationSymbreakOne(s)=': '',
    'AutomorphismCount=': '',
    'MatchVertex=': '',
    'SymbreakCount=': '',
    'SymbreakScore=': '',
    'DurationExecutionCompiled(s)=': '',
    'DurationExecutionDynamic(s)=': '',
    'MatchCount=': '',
    'total_seconds=': '',
    'max_Kbytes=': '',
}

PROGRAM = 'TopDown'
RECORD_BEGIN = 'start command line at '


def log_to_spreadsheet(log_file, out_file):
    data = [logger for logger in segment_log(log_file)]
    if not HasPandas:
        print('cannot import pandas. use csv file instead.')
        out_file += '.csv'
    if os.path.isfile(out_file):
        print('abort. out_file exists:', out_file)
        exit(-1)
    if out_file[-5:] == '.xlsx':
        print('write log_file:', log_file, 'to xlsx file:', out_file)
        df = pd.DataFrame(data)
        df.to_excel(out_file, index=False)
    else:
        print('write log_file:', log_file, 'to csv file:', out_file)
        header = sorted(COLUMNS.keys())
        with open(out_file, 'a', encoding='utf-8') as w:
            # write header
            for key in header:
                w.write(key + ',')
            w.write('\n')
            for logger in data:
                for key in header:
                    w.write(logger[key] + ',')
                w.write('\n')


def segment_log(log_file):
    print('read', PROGRAM, 'log file:', log_file)
    logger = dict(COLUMNS)
    with open(log_file, 'r', encoding='utf-8') as r:
        for line in r:
            if (RECORD_BEGIN in line) and (logger['DateTime=']):
                # the second condition can avoid the first empty record
                yield logger
                logger = dict(COLUMNS)
            for key in logger:
                if key in line:
                    value = line.strip().split(key)[-1].strip()
                    if ']' in value:
                        logger[key] = value.split(']')[0]
                    elif (' ' in value) and ('=' in value):
                        # multiple key in the same line
                        if key == 'MatchVertex=':
                            logger[key] = value.split('  SymbreakCount=')[0]
                        else:
                            logger[key] = value.split(' ')[0]
                    elif key == 'total_seconds=':
                        # total_seconds=0.19,max_Kbytes=30908
                        logger[key] = value.split(',max_Kbytes=')[0]
                    else:
                        logger[key] = value
    # return the last record
    yield logger

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("usage: ./log_to_spreadsheet.py log_file output_file")
        exit()
    log_to_spreadsheet(sys.argv[1], sys.argv[2])
