#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '18:24 PM Thursday Oct 20 2022'
__doc__ = '''compare_subgraph.py
given two lists of subgraph, one tuple for a graph
compare the difference
'''


import functools


def compare_subgraph(file_a, file_b):
    diff = read_subgraph(file_a) - read_subgraph(file_b)
    for row_1d in sorted(diff, key=functools.cmp_to_key(cmp_int_1d)):
        print(row_1d)


def cmp_int_1d(a, b):
    '''
    first sort by length ascending order
    then sort by element ascending order
    '''
    diff = len(a) - len(b)
    # print('diff', diff)
    if diff:
        return diff
    min_length = min(len(a), len(b))
    for i in range(min_length):
        if a[i] == b[i]:
            continue
        else:
            # print('i', i, 'a[i]', a[i], 'b[i]', b[i], 'a[i] < b[i]', a[i] < b[i])
            return a[i] - b[i]
    return diff


def reorder_3_path(relation):
    # (a, b, c, d) -> (b, c, a, d) and c<b
    result = list()
    for row_1d in relation:
        reorder = [row_1d[1], row_1d[2], row_1d[0], row_1d[3]]
        if row_1d[2] < row_1d[1]:
            result.append(reorder)
    return sorted(result, key=functools.cmp_to_key(cmp_int_1d))


def reorder_bifan(relation):
    result = list()
    for row_1d in relation:
        reorder = [row_1d[2], row_1d[3], row_1d[0], row_1d[1]]
        if (reorder[2] < reorder[1]) and (reorder[3] < reorder[0]):
            result.append(reorder)
    return sorted(result, key=functools.cmp_to_key(cmp_int_1d))


def reorder_d_cycle_4(relation):
    result = list()
    for row_1d in relation:
        reorder = [row_1d[3], row_1d[2], row_1d[1], row_1d[0]]
        if ((reorder[1] < reorder[0]) and (reorder[2] < reorder[0])
            and (reorder[3] < reorder[0])):
            result.append(reorder)
    return sorted(result, key=functools.cmp_to_key(cmp_int_1d))


def reorder_forktailed_tri(relation):
    # (a, b, c, d) -> (c, d, b, a) and d<c
    result = list()
    for row_1d in relation:
        reorder = [row_1d[2], row_1d[3], row_1d[1], row_1d[0]]
        if row_1d[3] < row_1d[2]:
            result.append(reorder)
    return sorted(result, key=functools.cmp_to_key(cmp_int_1d))


def reorder_tailed_triangle(relation):
    # (a, b, c, d, e) -> (c, e, b, a, d) and e<c, d<a
    result = list()
    for row_1d in relation:
        reorder = [row_1d[2], row_1d[4], row_1d[1], row_1d[0], row_1d[3]]
        if (row_1d[4] < row_1d[2]) and (row_1d[3] < row_1d[0]):
            result.append(reorder)
    return sorted(result, key=functools.cmp_to_key(cmp_int_1d))


def read_subgraph(in_file):
    relation = list()
    with open(in_file, 'r', encoding='utf-8') as r:
        for line in r:
            row_1d = list(map(int, line.strip().split()))
            relation.append(row_1d)
        return relation


def save_file_as_sorted_list(in_file, filter, out_file):
    with open(out_file, 'w', encoding='utf-8') as w:
        for row_1d in filter(read_subgraph(in_file)):
            for item in row_1d:
                w.write('%s ' % (item))
            w.write('\n')


###############################################################################
def compare_result():
    file_a = '../../adjacency-cpp/_dataset-labeled_grqctxt-_query-labeled_Undirected4_1txt'
    file_b = '../grqc-3-path.txt'
    compare_subgraph(file_a, file_b)


def debug_3_path():
    file_a = '../../adjacency-cpp/_dataset-labeled_grqctxt-_query-labeled_Undirected4_1txt'
    save_file_as_sorted_list(file_a, reorder_3_path, 'out_file_a.txt')


def debug_bifan():
    truth = '../../unlabeled-p2p-d-bifan-truth.txt'
    save_file_as_sorted_list(truth, reorder_bifan, '../../truth.txt')


def debug_d_cycle_4():
    truth = '../../unlabeled-p2p-d-cycle-4-truth.txt'
    save_file_as_sorted_list(truth, reorder_d_cycle_4, '../../truth.txt')


def debug_forktailed_tri():
    file_a = '../../adjacency-cpp/_dataset-labeled_grqctxt-_query-labeled_Undirected5_8txt'
    save_file_as_sorted_list(file_a, reorder_tailed_triangle, 'out_file_a.txt')


def debug_tailed_triangle():
    file_a = '../../adjacency-cpp/_dataset-labeled_grqctxt-_query-labeled_Undirected4_4txt'
    save_file_as_sorted_list(file_a, reorder_tailed_triangle, 'out_file_a.txt')


if __name__ == '__main__':
    debug_d_cycle_4()
