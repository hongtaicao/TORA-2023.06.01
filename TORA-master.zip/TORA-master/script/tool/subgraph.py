#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '18:51 PM Tuesday April 4 2022'
__doc__ = r'''subgraph.py
verify intermediate result
    join intermediate relations produced in debug
    relation format
        \([\d+ ]+\)

brute-force subgraph matching
    use edgelist.txt file as input
    each line can be one of the following
        5 integers
            from_vertex to_vertex from_label to_label edge label
        2 integers
            from_vertex to_vertex
'''


import sys


def _add_vertex_label(label_to_vertex, vlabel, vertex):
    if vlabel not in label_to_vertex:
        label_to_vertex[vlabel] = set()
    label_to_vertex[vlabel].add(vertex)


def _join_patent_subcatagory_3_0():
    # manually created op1.txt, op2.txt, op3.txt
    r1 = read_relation('op1.txt')
    r2 = read_relation('op2.txt')
    r3 = read_relation('op3.txt')
    for a in sorted(r1.keys()):
        print('a=%s ' % (a), end='')
        r2_c = r2[a]
        for b in sorted(r1[a]):
            print('b=%s ' % (b), end='')
            if b in r3:
                for c in sorted(r3[b]):
                    if c not in r2.c:
                        print('c=%d ' % (c), end='')
        print('')


def _read_edgelist_file(in_path):
    edge_map = dict()
    label_to_vertex = dict()
    edge_label = dict()
    print('read graph edge list file:', in_path)
    with open(in_path, 'r', encoding='utf-8') as r:
        la, lb, le = '', '', ''
        for line in r:
            row = line.strip().split()
            if len(row) == 2:
                a, b = row
            elif len(row) == 5:
                a, b, la, lb, le = row
            else:
                print('abort. cannot parse line:', line)
                print('parsed row:', row)
                exit(-1)
            a = int(a)
            b = int(b)
            if a not in edge_map:
                edge_map[a] = set()
            edge_map[a].add(b)
            _add_vertex_label(label_to_vertex, la, a)
            _add_vertex_label(label_to_vertex, lb, b)
            edge_label[(a, b)] = le
    return edge_map, label_to_vertex, edge_label


def _read_label_file(in_path):
    print('read label file:', in_path)
    label_index = dict()
    with open(in_path, 'r', encoding='utf-8') as r:
        for line in r:
            value = len(label_index)
            label_index[line.strip()] = value
    return label_index


def _read_relation(in_path):
    counter = 0
    relation = dict()
    with open(in_path, 'r', encoding='utf-8') as r:
        for line in r:
            line = line.strip()
            if not (('(' in line) and (line[0] == '(') and (')' in line) \
                and (line[-1] == ')')):
                continue
            # remove head and tail ()
            line = line.split('(')[-1].split(')')[0]
            row = line.strip().split()
            if len(row) == 2:
                a, b = row
                a = int(a)
                b = int(b)
                if a not in relation:
                    relation[a] = set()
                relation[a].add(b)
                counter += 1
            else:
                print('read a relation tuple:', row)
                print('abort. the number of attribute is not support.')
                exit(-1)
    print('read file:', in_path, 'tuple count:', counter)
    return relation


def _reverse_map(in_map):
    # in_map value should be iterable
    reverse_map = dict()
    for va, neighbor in in_map.items():
        for vb in neighbor:
            if vb not in reverse_map:
                reverse_map[vb] = set()
            reverse_map[vb].add(va)
    return reverse_map


def _subgraph_patent_subcatagory_3_0(in_path):
    edge_map, label_to_vertex, edge_label = _read_edgelist_file(in_path)
    reverse_map = _reverse_map(edge_map)
    # path pattern: (a:19)<-[]-(b:52)<-[]-(c:52)
    for a in sorted(label_to_vertex['19']):
        if a not in reverse_map:
            # a has no in-coming neighbor
            continue
        a_in = reverse_map[a]
        a_out = edge_map.get(a, set())
        for b in sorted(a_in):
            if b not in label_to_vertex['52']:
                # b label not match
                continue
            if b in a_out:
                # has additional edge a->b
                continue
            if b not in reverse_map:
                # b has no in-coming neighbor
                continue
            b_in = reverse_map[b]
            b_out = edge_map.get(b, set())
            for c in sorted(b_in):
                if c not in label_to_vertex['52']:
                    # c label not match
                    continue
                if (c in a_in) or (c in a_out):
                    # has a <- c or a->c
                    continue
                if c in b_out:
                    # has b->c
                    continue
                print('%s %s %s' % (a, b, c))


def run_command():
    if sys.argv[1:]:
        command = sys.argv[1]
        if command == 'join':
            return verify_join()
        elif command == 'subgraph':
            if sys.argv[2:]:
                return verify_subgraph(sys.argv[2])
        else:
            print('unknown command:', command)
    return False


def verify_join():
    _join_patent_subcatagory_3_0()
    return True


def verify_subgraph(in_path):
    _subgraph_patent_subcatagory_3_0(in_path)
    return True


if __name__ == '__main__':
    if not run_command():
        print('usage: <command> <path-to-edgelist-text-file>')
        print('abort. not enough arguments')
