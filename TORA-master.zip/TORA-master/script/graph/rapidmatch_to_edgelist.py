#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '15:51 PM Oct 2 2022'
__doc__ = '''rapidmatch_to_edgelist.py
process rapidmatch_dataset, rapid_match_dataset.zip
convert a graph from RapidMatch format to  edgelist format

input RapidMatch dataset format:
    downloaded from 2020 RapidMatch published dataset

    Both the query and data graphs are vertex-labeled undirected.

    Each graph starts with 't N M' where N is the number of vertices and
    M is the number of edges. A vertex and an edge are formatted as
    'v VertexID LabelId Degree' and 'e VertexId VertexId' respectively.
    Note that we require that the vertex id is started from 0 and
    the range is [0,N - 1] where V is the vertex set.

    Example:

    t 5 6
    v 0 0 2
    v 1 1 3
    v 2 2 3
    v 3 1 2
    v 4 2 2
    e 0 1 0
    e 0 2 0
    e 1 2 0
    e 1 3 0
    e 2 4 0
    e 3 4 0


output edge list format:
    output graph is stored as directed graphs
    an undirected edge is stored as two directed edges
    one line contains 5 integers
        from_vertex to_vertex from_label to_label 0
'''

import os, sys


PROJECT_ROOT = '../../'
DATASET_DIRECTORY = PROJECT_ROOT + '../RapidMatch/rapid_match_dataset/'
OUT_DIRECTORY = PROJECT_ROOT + 'dataset/'


def add_edge(edge_map, source, target):
    if source not in edge_map:
        edge_map[source] = set()
    edge_map[source].add(target)


def read_rapid_dataset(in_file):
    # labeled undirected graphs
    print('read file:', in_file)
    edge_map = dict()
    vertex_label = dict()
    with open(in_file, encoding='utf-8', newline='') as r:
        _, v_count, e_count = next(r).strip().split(' ')
        v_count = int(v_count)
        e_count = int(e_count)
        print('vertex count:', v_count, 'edge count:', e_count)
        while v_count > 0:
            v_count -= 1
            symbol, vertex, vlabel, degree = next(r).strip().split(' ')
            assert(symbol == 'v')
            vertex_label[vertex] = vlabel
        while e_count > 0:
            e_count -= 1
            segment = next(r).strip().split(' ')
            if len(segment) == 3:
                symbol, source, target = segment
            elif len(segment) == 4:
                symbol, source, target, _ = segment
            else:
                print('cannot parse segment:', segment)
                assert(False)
            assert(symbol == 'e')
            add_edge(edge_map, source, target)
            add_edge(edge_map, target, source)
    return edge_map, vertex_label


def write_labeled_graph(out_file, edge_map, vertex_label):
    # write as 5 column datasets, directed graph
    # source, target, source label, target label, edge label
    print('write file:', out_file)
    dirname = os.path.dirname(out_file)
    if dirname:
        os.makedirs(dirname, exist_ok=True)
    with open(out_file, 'w', encoding='utf-8') as w:
        for vi in sorted(edge_map):
            for vj in sorted(edge_map[vi]):
                w.write(vi + ' ' + vj + ' ')
                w.write(vertex_label[vi] + ' ' + vertex_label[vj])
                w.write(' 0\n')


def convert_patents_data():
    in_file = DATASET_DIRECTORY
    in_file += 'large_query/patents/data_graph/patents.graph'
    edge_map, vertex_label = read_rapid_dataset(in_file)
    out_file = OUT_DIRECTORY + 'labeled-patents-rapidmatch.txt'
    write_labeled_graph(out_file, edge_map, vertex_label)


def convert_patents_query():
    in_file = DATASET_DIRECTORY
    in_file += 'large_query/patents/query_graph/query_dense_%s_%s.graph'
    for size in [4, 8]: # dense [4, 8, 16, 24, 32], sparse [8, 16, 24, 32]
        for ith in range(1, 11): # min 1, max 201
            edge_map, vertex_label = read_rapid_dataset(in_file % (size, ith))
            out_file = OUT_DIRECTORY + 'labeled-patents-rapidmatch-query/'
            out_file += 'dense-%s-%s.txt' % (size, ith)
            write_labeled_graph(out_file, edge_map, vertex_label)


def convert_wordnet_data():
    in_file = DATASET_DIRECTORY
    in_file += 'large_query/wordnet/data_graph/wordnet.graph'
    edge_map, vertex_label = read_rapid_dataset(in_file)
    out_file = OUT_DIRECTORY + 'labeled-wordnet-rapidmatch.txt'
    write_labeled_graph(out_file, edge_map, vertex_label)


def convert_wordnet_query():
    in_file = DATASET_DIRECTORY
    in_file += 'large_query/wordnet/query_graph/query_dense_%s_%s.graph'
    for size in [4, 8]: # dense [4, 8, 12, 16, 20], sparse [8, 12, 16, 20]
        for ith in range(1, 11): # min 1, max 201
            edge_map, vertex_label = read_rapid_dataset(in_file % (size, ith))
            out_file = OUT_DIRECTORY + 'labeled-wordnet-rapidmatch-query/'
            out_file += 'dense-%s-%s.txt' % (size, ith)
            write_labeled_graph(out_file, edge_map, vertex_label)


if __name__ == '__main__':
    '''
    read file: ../../../RapidMatch/rapid_match_dataset/large_query/wordnet/data_graph/wordnet.graph
    vertex count: 76853 edge count: 120399
    write file: ../../dataset/labeled-wordnet-rapidmatch.txt
    read file: ../../../RapidMatch/rapid_match_dataset/large_query/wordnet/query_graph/query_dense_4_1.graph
    vertex count: 4 edge count: 3
    write file: ../../dataset/labeled-wordnet-rapidmatch-query/dense-4-1.txt
    ...
    read file: ../../../RapidMatch/rapid_match_dataset/large_query/patents/data_graph/patents.graph
    vertex count: 3774768 edge count: 16518947
    write file: ../../dataset/labeled-patents-rapidmatch.txt
    read file: ../../../RapidMatch/rapid_match_dataset/large_query/patents/query_graph/query_dense_4_1.graph
    vertex count: 4 edge count: 3
    write file: ../../dataset/labeled-patents-rapidmatch-query/dense-4-1.txt
    ...
    '''
    # the first argument can override the directory of rapid_match_dataset
    if len(sys.argv) > 1:
        DATASET_DIRECTORY = sys.argv[1]
    for name in sys.argv[2:]:
        if name == 'convert_patents_data':
            convert_patents_data()
        elif name == 'convert_patents_query':
            convert_patents_query()
        elif name == 'convert_wordnet_data':
            convert_wordnet_data()
        elif name == 'convert_wordnet_query':
            convert_wordnet_query()
        else:
            print('skip unrecognized sample command:', name)
