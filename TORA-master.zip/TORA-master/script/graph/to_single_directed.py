#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '10:45 AM Sunday April 2 2023'
__doc__ = '''to_single_directed.py
change a bidrected edges to a single directed edge
this preserves the original graph degree, edge density

graphflow does not support bi-directed edge
therefore move a bidirected edge to create a single directed edge

output edge list format
    each line is an edge, using one of the following format
        5 integers: from_vertex to_vertex from_label to_label edgedge_label
        2 integers: from_vertex to_vertex

'''


import os, random, sys

from sampler import sample_query_set


CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(os.path.dirname(CURRENT_DIR))
DATASET_DIR = PROJECT_DIR + '/dataset/'
SD_SUFFIX = '-single-directed'

ALL_LABELED_DATASET = [
    'labeled-wordnet-rapidmatch.txt',
    'labeled-patents-rapidmatch.txt',
    'labeled-patent-subcategory.txt',
]


ALL_DATASET = [
    'unlabeled-grqc.txt',
    'unlabeled-email.txt',
    'unlabeled-gowa.txt',
    'unlabeled-roadca.txt',
    'unlabeled-facebook.txt',
    'unlabeled-p2p.txt',
    'unlabeled-amazon.txt',
    'unlabeled-NotreDame.txt',
    'unlabeled-comlj.txt',
] + ALL_LABELED_DATASET


def _add_label(v_label, vertex, label):
    if vertex not in v_label:
        v_label[vertex] = label
    elif v_label[vertex] != label:
        print('vertex', vertex, 'has inconsistent vertex label:', \
            v_label[vertex], label)
        raise


def _move_bidirected_edge(edge_map, edge_label):
    # it is not allowed to modify container while iterating it
    # first collect edge to be moved
    o_count = 0
    max_vertex = 0
    to_move = list()
    for from_vertex, neighbor in edge_map.items():
        o_count += len(neighbor)
        max_vertex = max(max_vertex, from_vertex)
        max_vertex = max(max_vertex, max(neighbor))
        for to_vertex in neighbor:
            if from_vertex < to_vertex:
                if (from_vertex in edge_map.get(to_vertex, set())):
                    # find a bidirected edge
                    # choose either direction to be moved
                    if random.random() < 0.5:
                        to_move.append((from_vertex, to_vertex))
                    else:
                        to_move.append((to_vertex, from_vertex))
    # first remove one direction of the bidirected edge
    for from_vertex, to_vertex in to_move:
        edge_map[from_vertex].remove(to_vertex)
    # for each deleted edge, connect another pair of vertexes
    if max_vertex:
        # graph has at least 2 vertexes
        # a graph with max_vertex vertexes can have at most k edges
        # exclude self-loops
        k = int((max_vertex + 1) * max_vertex / 2)
    else:
       k = 0
    # there is a max possible edges can be added
    for index in range(min(len(to_move), k - o_count + len(to_move))):
        retry_count = 100
        while retry_count > 0:
            from_vertex = random.randint(0, max_vertex)
            to_vertex = random.randint(0, max_vertex)
            if from_vertex == to_vertex:
                # cannot add self-loop
                continue
            if to_vertex in edge_map.get(from_vertex, set()):
                # cannot add an edge that already exists
                continue
            if from_vertex in edge_map.get(to_vertex, set()):
                # cannot add an edge whose reverse direction exists
                continue
            # add this edge and the corresponding edge label
            if from_vertex not in edge_map:
                edge_map[from_vertex] = set()
            edge_map[from_vertex].add(to_vertex)
            edge_label[(from_vertex, to_vertex)] = edge_label[to_move[index]]
            # add succesfully, no need to retry
            break
            retry_count -= 1
    r_count = len(to_move) # move edge count
    f_count = sum(len(x) for x in edge_map.values()) # final edge count
    print('original edge count:', o_count, 'moved count:', r_count,
        'move ratio: %.3f' % (r_count/o_count), 'final count:', f_count)


def _read_edgelist(in_path):
    # edge_map maps from_vertex to its out-going vertexes
    edge_map = dict()
    v_label = dict()
    edge_label = dict()
    # default vertex label id and edge label
    la = ''
    lb = ''
    le = ''
    print('read:', in_path.replace('\\', '/'))
    with open(in_path, 'r', encoding='utf-8') as r:
        for line in r:
            row = line.strip().split()
            if len(row) == 2:
                va, vb = row
            elif len(row) == 5:
                va, vb, la, lb, le = row
            else:
                print('cannot parse edge list:', row)
                raise
            va = int(va)
            vb = int(vb)
            if va not in edge_map:
                edge_map[va] = set()
            edge_map[va].add(vb)
            _add_label(v_label, va, la)
            _add_label(v_label, vb, lb)
            edge_label[(va, vb)] = le
    return edge_map, v_label, edge_label


def _write_edgelist(edge_map, v_label, edge_label, out_path):
    print('write graph file:', out_path)
    with open(out_path, 'w', encoding='utf-8') as w:
        for from_vertex in sorted(edge_map.keys()):
            for to_vertex in sorted(edge_map[from_vertex]):
                la = v_label[from_vertex]
                lb = v_label[to_vertex]
                le = edge_label[(from_vertex, to_vertex)]
                content = '%s %s %s %s %s\n'
                content = content % (from_vertex, to_vertex, la, lb, le)
                w.write('%s\n' % (content.strip()))


def create_query_sample(in_path):
    if not os.path.isfile(in_path):
        print('abort. input data graph not found:', in_path)
        exit(-1)
    if SD_SUFFIX not in in_path:
        print('abort. input data graph is not single directed.')
        exit(-1)
    size_repeat_2d = []
    for size in range(3, 8):
        size_repeat_2d.append([size, 100])
    sample_query_set(in_path, size_repeat_2d)


def create_single_directed_edgelist(in_path, out_dir):
    # name convension
    name, ext = os.path.splitext(os.path.basename(in_path))
    out_path = '%s/%s%s%s' % (out_dir, name, SD_SUFFIX, ext)
    if not os.path.isfile(in_path):
        print('abort. input data graph not found:', in_path)
        exit(-1)
    if os.path.isfile(out_path):
        print('abort. output data graph already exists:', out_path)
        exit(-1)
    edge_map, v_label, edge_label = _read_edgelist(in_path)
    _move_bidirected_edge(edge_map, edge_label)
    _write_edgelist(edge_map, v_label, edge_label, out_path)


def parse_argument():
    command = 'default'
    in_path = DATASET_DIR
    out_dir = DATASET_DIR
    argument = sys.argv[1:4]
    if len(argument) == 1:
        command = sys.argv[1]
    elif len(argument) == 2:
        command, in_path = argument
    elif len(argument) == 3:
        command, in_path, out_dir = argument
    else:
        print('abort. unexpected input argument:', argument)
        exit(-1)
    if (command != 'default') and (not os.path.isfile(in_path)):
        print('abort. input file not found:', in_path)
        exit(-1)
    return command, in_path, out_dir


if __name__ == '__main__':
    command, in_path, out_dir = parse_argument()
    if command == 'data':
        create_single_directed_edgelist(in_path, out_dir)
    elif command == 'sample':
        create_query_sample(in_path)
    elif command == 'default':
        print('default mode. ignore input argument <in_path> <out_dir>')
        for name in ALL_DATASET:
            in_path = DATASET_DIR + '/' + name
            create_single_directed_edgelist(in_path, DATASET_DIR)
        for name in ALL_LABELED_DATASET:
            name, ext = os.path.splitext(os.path.basename(name))
            in_path = DATASET_DIR + '/%s%s%s' % (name, SD_SUFFIX, ext)
            create_query_sample(in_path)
    else:
        print('supported command: [data|sample]')
        print('abort. unknown command:', command)
