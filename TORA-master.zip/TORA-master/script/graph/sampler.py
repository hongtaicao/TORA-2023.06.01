#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '16:48 PM Jan 30 2023'
__doc__ = '''sampler.py
sample query graph from labeled text data graph

input data graph is stored as bi-directed labeled graph
    each line is an edge, can be either
    unlabeled 2 integers: from_vertex to_vertex
    labeled   5 integers: from_vertex to_vertex from_label to_label edge_label

output query graph is stored as bi-directed labeled graph
file name: querysize-topologyid.txt

also output how many times the same topology is sampled, in file
[prefix]-query-summary-[size].txt
as
topology_id count

topology_id match the topologyid in the query file name
'''


import functools, os, random, sys

import networkx as nx


PROJECT_ROOT = '../../'
DATASET_DIRECTORY = PROJECT_ROOT + 'dataset/'

Labeled = 'labeled-'
Unlabeled = 'unlabeled-'


class DataGraph(object):
    # labeled data graph
    def __init__(self, in_file):
        self.edge_label = dict()
        self.out_map = dict()
        self.vertex_label = dict()
        basename = os.path.basename(in_file)
        if basename[:len(Labeled)] == Labeled:
            self.has_label = True
            # labeled graph
        elif basename[:len(Unlabeled)] == Unlabeled:
            # unlabeled graph
            self.has_label = False
        else:
            print('error reading data graph file:', in_file)
            message = 'data file name should start with:'
            print('%s %s or %s' % (message, Labeled, Unlabeled))
            exit(-1)
        # read in_file and store into out_map, vertex_label and edge_label
        with open(in_file, 'r', encoding='utf-8') as r:
            va = ''
            vb = ''
            la = ''
            lb = ''
            le = ''
            for line in r:
                # from_vertex, to_vertex, from_label, to_label, edge_label
                if self.has_label:
                    va, vb, la, lb, le = line.strip().split()
                else:
                    va, vb = line.strip().split()
                if va not in self.out_map:
                    self.out_map[va] = set()
                self.out_map[va].add(vb)
                self.vertex_label[va] = la
                self.vertex_label[vb] = lb
                edge_key = _edge_key(va, vb)
                if edge_key in self.edge_label:
                    prev_label = self.edge_label[edge_key]
                    if prev_label != le:
                        message = 'edge (%s) has two labels ' % (edge_key)
                        message += ('[%s] and [%s]' % (prev_label, le))
                        print(message)
                        raise
                else:
                    self.edge_label[edge_key] = le

    def build_vertex_set(self):
        self.vertex_set = set()
        for k, v in self.out_map.items():
            self.vertex_set.add(k)
            self.vertex_set |= v

    def build_neighbor_dic(self):
        # neighbor dic does not care edge direction
        self.neighbor_dic = dict()
        for from_vertex, to_neighbor in self.out_map.items():
            if from_vertex not in self.neighbor_dic:
                self.neighbor_dic[from_vertex] = set()
            for to_vertex in to_neighbor:
                self.neighbor_dic[from_vertex].add(to_vertex)
                if to_vertex not in self.neighbor_dic:
                    self.neighbor_dic[to_vertex] = set()
                self.neighbor_dic[to_vertex].add(from_vertex)

    def has_edge(self, vi, vj):
        if vi in self.out_map:
            return vj in self.out_map[vi]
        return False


class QueryGraph(object):
    def __init__(self):
        self.vertex_set = set()
        self.topology_id = -1

    def get_hash(self, data_graph):
        v_1d = list(self.vertex_set)
        label_1d = sorted(data_graph.vertex_label[x] for x in v_1d)
        size = len(v_1d)
        count_b = 0         # bi_directed_edge_count
        count_s = 0         # single_directed_edge_count
        edge_label_1d = list()
        for j in range(1, size):
            vj = v_1d[j]
            for i in range(0, j):
                vi = v_1d[i]
                if data_graph.has_edge(vi, vj):
                    edge_label = data_graph.edge_label[_edge_key(vi, vj)]
                    edge_label_1d.append(edge_label)
                    if data_graph.has_edge(vj, vi):
                        count_b += 1
                    else:
                        count_s += 1
                elif data_graph.has_edge(vj, vi):
                    edge_label = data_graph.edge_label[_edge_key(vj, vi)]
                    edge_label_1d.append(edge_label)
                    count_s += 1
        edge_label_1d.sort()
        key = '%s;%s;%s;%s' % (size, count_b, count_s, ' '.join(label_1d))
        return key + ';%s' % (' '.join(edge_label_1d))


class QueryTable(object):
    def __init__(self):
        self.tid_to_counter = dict()    # topology_id -> count
        self.hash_to_q1d = dict()       # query_hash -> query_1d


def _build_query(query, data_graph):
    # map vertex into range [0, len(query.vertex_set))
    v_map = dict()
    for v in query.vertex_set:
        value = len(v_map)
        v_map[v] = value
    # build labeled edge list, this is write to file
    edge_list = list()
    for va in query.vertex_set:
        if va in data_graph.out_map:
            neighbor = data_graph.out_map[va]
            for vb in query.vertex_set:
                if vb in neighbor:
                    edge = [v_map[va], v_map[vb]]
                    if data_graph.has_label:
                        edge.append(data_graph.vertex_label[va])
                        edge.append(data_graph.vertex_label[vb])
                        edge.append(data_graph.edge_label[_edge_key(va, vb)])
                    edge = [int(x) for x in edge]
                    edge_list.append(edge)
    return sorted(edge_list, key=_compare_1d_key())


def _compare_1d_key():
    def _(array_a, array_b):
        for i in range(len(array_a)):
            if array_a[i] == array_b[i]:
                continue
            return array_a[i] < array_b[i]
    return functools.cmp_to_key(_)


def _edge_key(va, vb):
    return '%s %s' % (va, vb)


def _index_query(query, data_graph, query_pool, query_table):
    query_hash = query.get_hash(data_graph)
    if query_hash in query_table.hash_to_q1d:
        for qb in query_table.hash_to_q1d[query_hash]:
            if _isomorphic(query, qb, data_graph):
                # isomorphic, an old query, shared topology_id
                query.topology_id = qb.topology_id
                query_table.tid_to_counter[query.topology_id] += 1
                return
        # none is isomorphic, a new query
    # a new query, assign a new topology_id of the query
    query.topology_id = len(query_pool)
    query_pool.append(query)
    query_table.hash_to_q1d[query_hash] = list()
    query_table.hash_to_q1d[query_hash].append(query)
    query_table.tid_to_counter[query.topology_id] = 1


def _isomorphic(qa, qb, data_graph):
    def _build_nx_graph(query):
        G = nx.DiGraph()
        for va in query.vertex_set:
            G.add_node(va, label=data_graph.vertex_label[va])
            if va in data_graph.out_map:
                neighbor = data_graph.out_map[va]
                for vb in query.vertex_set:
                    if vb in neighbor:
                        edge_label = data_graph.edge_label[_edge_key(va, vb)]
                        G.add_edge(va, vb, label=edge_label)
        return G
    def _node(va, vb):
        return va['label'] == vb['label']
    def _edge(edge_a, edge_b):
        return edge_a['label'] == edge_b['label']
    G1 = _build_nx_graph(qa)
    G2 = _build_nx_graph(qb)
    return nx.is_isomorphic(G1, G2, node_match=_node, edge_match=_edge)


def _sample_one_query(data_graph, query_size):
    # each query is represeted by a vertex set
    # query is the subgraph induced on the set
    query = QueryGraph()
    if query_size:
        # add the first sampled vertex
        for v in random.sample(data_graph.vertex_set, k=1):
            # sample one vertex without replacement
            query.vertex_set.add(v)
    trial = 100
    while len(query.vertex_set) < query_size:
        candidate = set()
        for v in query.vertex_set:
            # candidate = neighbor of sampled vertex
            candidate |= data_graph.neighbor_dic[v]
        for v in random.sample(list(candidate), k=1):
            # add one sampled vertex to query
            query.vertex_set.add(v)
        if trial < 0:
            return None
        trial -= 1
    return query


def _write_querypool(query_pool, data_graph, in_file):
    dirname = os.path.splitext(in_file)[0] + '-sample-query/'
    if dirname:
        os.makedirs(dirname, exist_ok=True)
    # size, index
    query_name = dirname + '%s-%s.txt'
    for query in query_pool:
        out_file = query_name % (len(query.vertex_set), query.topology_id)
        _write_textfile(out_file, _build_query(query, data_graph))


def _write_summary(query_table, in_file):
    # write topology id, the number of times sampled
    data_2d = list()
    size = 0
    q_2d = list(query_table.hash_to_q1d.values())
    if q_2d:
        size = len(q_2d[0][0].vertex_set)
    for tid, count in query_table.tid_to_counter.items():
        data_2d.append((tid, count))
    out_file = os.path.splitext(in_file)[0]
    out_file += ('-sample-query-summary-%s.txt' % (size))
    _write_textfile(out_file, sorted(data_2d, key=_compare_1d_key()))


def _write_textfile(out_file, data_2d):
    with open(out_file, 'w', encoding='utf-8') as w:
        if data_2d:
            fmt = ['%s'] * len(data_2d[0])
            fmt = ' '.join(fmt) + '\n'
        for data_1d in data_2d:
            w.write(fmt % tuple(data_1d))
    print('write file:', out_file)


def sample_query_set(in_file, size_repeat_2d):
    data_graph = DataGraph(in_file)
    data_graph.build_vertex_set()
    data_graph.build_neighbor_dic()
    # sample a query
    for query_size, total in size_repeat_2d:
        query_pool = list()
        query_table = QueryTable()
        for repeat in range(0, total):
            query = _sample_one_query(data_graph, query_size)
            if not query:
                continue
            _index_query(query, data_graph, query_pool, query_table)
            message = 'generate query size=%s' % (query_size)
            message += (' topology_id=%s' % (query.topology_id,))
            message += (' repeat=%s/%s' % (repeat, total))
            print(message)
        _write_querypool(query_pool, data_graph, in_file)
        _write_summary(query_table, in_file)


def sample_patent_subcategory():
    in_file = DATASET_DIRECTORY + 'labeled-patent-subcategory.txt'
    size_repeat_2d = []
    for size in range(3, 8):
        size_repeat_2d.append([size, 100])
    sample_query_set(in_file, size_repeat_2d)


def sample_patents_rapidmatch():
    in_file = DATASET_DIRECTORY + 'labeled-patents-rapidmatch.txt'
    size_repeat_2d = []
    for size in range(3, 8):
        size_repeat_2d.append([size, 100])
    sample_query_set(in_file, size_repeat_2d)


def sample_wordnet_rapidmatch():
    '''
    generate query size=3 topology_id=0 repeat=0/100
    ...
    generate query size=3 topology_id=0 repeat=99/100
    write file: ../../dataset/labeled-wordnet-rapidmatch-sample-query/3-0.txt
    ...
    write file: ../../dataset/labeled-wordnet-rapidmatch-sample-query/3-8.txt
    write file: ../../dataset/labeled-wordnet-rapidmatch-sample-query-summary-3.txt
    ...
    write file: ../../dataset/labeled-wordnet-rapidmatch-sample-query/6-79.txt
    write file: ../../dataset/labeled-wordnet-rapidmatch-sample-query-summary-6.txt
    generate query size=7 topology_id=0 repeat=0/100
    ...
    generate query size=7 topology_id=86 repeat=98/100
    write file: ../../dataset/labeled-wordnet-rapidmatch-sample-query/7-0.txt
    ...
    write file: ../../dataset/labeled-wordnet-rapidmatch-sample-query/7-85.txt
    write file: ../../dataset/labeled-wordnet-rapidmatch-sample-query-summary-7.txt
    '''
    in_file = DATASET_DIRECTORY + 'labeled-wordnet-rapidmatch.txt'
    size_repeat_2d = []
    for size in range(3, 8):
        size_repeat_2d.append([size, 100])
    sample_query_set(in_file, size_repeat_2d)


if __name__ == '__main__':
    for name in sys.argv[1:]:
        if name == 'sample_patent_subcategory':
            sample_patent_subcategory()
        elif name == 'sample_patents_rapidmatch':
            sample_patents_rapidmatch()
        elif name == 'sample_wordnet_rapidmatch':
            sample_wordnet_rapidmatch()
        else:
            print('skip unrecognized sample command:', name)
