#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '15:50 PM Oct 2 2022'
__doc__ = '''patent_to_edgelist.py
read patent dataset from DATASET_DIRECTORY

input patent dataset format:
    directed vertex labeled graph
    *.node.txt the i-th line is the label for node i
    *.edge.txt each line is a directed edge a->b

convert the above patent dataset to desired format for other algorithms
into directory OUT_DIRECTORY

output edge list format:
    each line is an edge containing:
    5 integers: from_vertex to_vertex from_label to_label edge_label
'''


import functools, os


PROJECT_ROOT = '../../'
DATASET_DIRECTORY = PROJECT_ROOT + '../dataset/patent/'
OUT_DIRECTORY = PROJECT_ROOT + '/dataset/'


def cmp_key():
    def compare_edge(a, b):
        if a[0] == b[0]:
            return a[1] - b[1]
        return a[0] - b[0]
    return functools.cmp_to_key(compare_edge)


def convert_subcategory():
    # class count 418 category count 6 subcategory count 36
    # subcategory has the appropriate number of labels
    prefix = 'subcategory'
    edge_file = prefix + '.edge.txt'
    node_file = prefix + '.node.txt'
    out_file = OUT_DIRECTORY + 'patent-subcategory-labeled.txt'
    edge_list, node_label = read_patent_data(edge_file, node_file)
    to_adjacency_txt(edge_list, node_label, out_file)


def convert_subcategory_query():
    for size in [3, 4, 5, 6]:
        prefix = DATASET_DIRECTORY + 'patent_query/patent_%s' % (size)
        edge_file = prefix + '.txt'
        node_file = prefix + '.label'
        edge_list, node_label = read_patent_data(edge_file, node_file)
        out_file = OUT_DIRECTORY + 'patent-subcategory-query-labeled/'
        out_file += ('%s.txt' % (size))
        dirname = os.path.dirname(out_file)
        if not os.path.isdir(dirname):
            os.makedirs(dirname)
        to_adjacency_txt(edge_list, node_label, out_file)


def read_patent_data(edge_file, node_file):
    print('read edge file:', edge_file)
    edge_list = list()
    with open(edge_file, 'r', encoding='utf-8') as r:
        for line in r:
            src, dst = line.strip().split()
            edge_list.append((int(src), int(dst)))
    print('read node file:', node_file)
    node_label = dict()
    with open(node_file, 'r', encoding='utf-8') as r:
        for ith, line in enumerate(r):
            node_label[ith] = int(line.strip())
    # report statistics
    label_set = set()
    for value in node_label.values():
        label_set.add(value)
    print('read directed edge count', len(edge_list),
        'vertex label count', len(label_set))
    return sorted(edge_list, key=cmp_key()), node_label


def to_adjacency_txt(edge_list, node_label, out_file):
    # the dataset for adjacency-cpp or TORA
    # out_file format
    # sorted edge list, each line with 5 numbers
    # source_id, destination_id, source_label, destination_label, edge_label
    # the dataset does not contain edge label and edge_label is set to 0
    with open(out_file, 'w', encoding='utf-8') as w:
        for src, dst in edge_list:
            row = (src, dst, node_label[src], node_label[dst])
            w.write('%s %s %s %s 0\n' % (row))
    print('write file:', out_file)


if __name__ == '__main__':
    '''
    read edge file: ../../../dataset/patent/patent_query/patent_3.txt
    read node file: ../../../dataset/patent/patent_query/patent_3.label
    read directed edge count 2 vertex label count 2
    write file: ../..//dataset/patent-subcategory-query-labeled/3.txt
    read edge file: ../../../dataset/patent/patent_query/patent_4.txt
    read node file: ../../../dataset/patent/patent_query/patent_4.label
    read directed edge count 3 vertex label count 2
    write file: ../..//dataset/patent-subcategory-query-labeled/4.txt
    read edge file: ../../../dataset/patent/patent_query/patent_5.txt
    read node file: ../../../dataset/patent/patent_query/patent_5.label
    read directed edge count 4 vertex label count 4
    write file: ../..//dataset/patent-subcategory-query-labeled/5.txt
    read edge file: ../../../dataset/patent/patent_query/patent_6.txt
    read node file: ../../../dataset/patent/patent_query/patent_6.label
    read directed edge count 5 vertex label count 2
    write file: ../..//dataset/patent-subcategory-query-labeled/6.txt
    '''
    convert_subcategory_query()
