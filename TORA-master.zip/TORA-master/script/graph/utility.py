#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '3:52 AM Wednesday Sept 14 2022'
__doc__ = '''utility.py
process graph data stored as edgelist, from_vertex to_vertex
'''

import os, sys


PROJECT_ROOT = '../../'
DATASET_DIRECTORY = PROJECT_ROOT + '../dataset/'
OUT_DIRECTORY = PROJECT_ROOT + '../dataset-labeled/'


def _get_max_degree(edge_map):
    max_degree = 0
    for va, neighor in edge_map.items():
        for vb in neighor:
            max_degree = max(max_degree, len(neighor))
    return max_degree


def add_uniform_label(in_file, out_directory):
    # each input line contains two integers for an edge
    # from-vertex to-vertex
    # each output line contains five integers for an edge
    # from-vertex to-vertex from_label to_label edge_label
    basename = os.path.basename(in_file)
    out_file = OUT_DIRECTORY + '/' + os.path.splitext(basename)[0]
    out_file += '-label.txt'
    print('read file', in_file)
    with open(in_file, 'r') as r, open(out_file, 'w') as w:
        for line in r:
            w.write(line.strip() + ' 0 0 0\n')
    print('write file', out_file)


def print_graph_info(in_file):
    edge_count = 0
    line_count = 0
    elabel = set()
    vlabel = set()
    v_set = set()
    out_map = dict()
    with open(in_file, 'r') as r:
        for line in r:
            row = line.strip().split()
            if len(row) == 2:
                # from_vertex to_vertex
                va, vb = row
            elif len(row) == 5:
                # from_vertex to_vertex from_label to_label edge_label
                va, vb, la, lb, le = line.strip().split()
                vlabel.add(la)
                vlabel.add(lb)
                elabel.add(le)
            if va not in out_map:
                out_map[va] = set()
            if vb not in out_map[va]:
                edge_count += 1
            out_map[va].add(vb)
            line_count += 1
            v_set.add(va)
            v_set.add(vb)
    # check directed / undirected
    directed = False
    for va, neighor in out_map.items():
        for vb in neighor:
            if (vb not in out_map) or (va not in out_map[vb]):
                directed = True
                break
    # two single directed edges are viewed as 1 bidirected edge
    bidirected_edge = 0
    # check max degree
    # create reverse map
    in_map = dict()
    for va, neighor in out_map.items():
        for vb in neighor:
            if vb not in in_map:
                in_map[vb] = set()
            in_map[vb].add(va)
            if (va < vb) and (vb in out_map) and (va in out_map[vb]):
                bidirected_edge += 1
    max_in_degree = _get_max_degree(in_map)
    max_out_degree = _get_max_degree(out_map)
    print('graph information:', in_file)
    print('directed:', directed,
        'vertex_count:', len(v_set),
        'edge_count:', edge_count,
        'duplicated edge_count:', line_count - edge_count,
        'bidirected_edge count:', bidirected_edge,
        'max_in_degree', max_in_degree,
        'max_out_degree:', max_out_degree,
        'vertex_lable_count:', len(vlabel),
        'edge_label_count:', len(elabel),
    )


if __name__ == '__main__':
    '''
    read file ../../../dataset/grqc.txt
    write file ../../../dataset-labeled/grqc-label.txt
    '''
    if len(sys.argv[1:]):
        if sys.argv[1] == 'add_uniform_label':
            if len(sys.argv[2:]) == 2:
                # use provided input file and output directory
                if os.path.isfile(sys.argv[2]) and os.path.isdir(sys.argv[3]):
                    add_uniform_label(sys.argv[2], sys.argv[3])
                else:
                    print('in_file:', sys.argv[2])
                    print('out_directory:', sys.argv[3])
                    print('add_uniform_label wrong argument')
            elif sys.argv[2] == 'grqc.txt':
                # use default directory
                in_file = DATASET_DIRECTORY + 'grqc.txt'
                add_uniform_label(in_file, OUT_DIRECTORY)
            else:
                print('add_uniform_label: skip unrecognized command:', \
                    sys.argv[2:])
        elif sys.argv[1] == 'print_graph_info':
            print('print_graph_info')
            for in_file in sys.argv[2:]:
                print_graph_info(in_file)
        else:
            print('skip unrecognized command:', sys.argv[1])
    else:
        print('no given command')
