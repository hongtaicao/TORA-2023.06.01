#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '0:56 AM Aug 11 2022'
__doc__ = '''patent_create.py

input format:
    downloaded from https://www.nber.org/research/data/us-patents

create patent dataset into the following files

output format:
    *.node.txt the i-th line is the label for node i
    *.edge.txt each line is a directed edge a->b
'''

PROJECT_ROOT = '../../'
DATASET_DIRECTORY = PROJECT_ROOT + '../dataset/patent/'
OUT_DIRECTORY = DATASET_DIRECTORY


def create_dataset(node_set, edge_set, patent_dic, index):
    label_1d, edge_1d = create_label(node_set, edge_set, patent_dic, index)
    write_dateset(label_1d, edge_1d, index)


def create_label(node_set, edge_set, patent_dic, index):
    # normalize node to range [0, len)
    get_label_name(index)
    labeled_node = set()
    unlabeled_node = set()
    for node in sorted(node_set):
        if (node in patent_dic) and (patent_dic[node][index] != ''):
            labeled_node.add(node)
        else:
            unlabeled_node.add(node)
    print('node with labels', len(labeled_node), '/', len(node_set))
    print('node without labels', len(unlabeled_node))
    node_map = dict()
    label_1d = list()
    # fix: filter labeled nodes that don't have edges
    labeled_node_with_edges = set()
    for a, neighbor in edge_set.items():
        for b in neighbor:
            if (a in labeled_node) and (b in labeled_node):
                labeled_node_with_edges.add(a)
                labeled_node_with_edges.add(b)
    # re-assgin labeled node
    labeled_node = labeled_node_with_edges
    print('node with labels and edges', len(labeled_node), '/', len(node_set))
    # renumber node id
    for idx, node in enumerate(labeled_node):
        node_map[node] = idx
        label_1d.append(patent_dic[node][index])
    # create edge_set
    edge_1d = list()
    unlabled_edge = 0
    for a, neighbor in edge_set.items():
        for b in neighbor:
            if (a in node_map) and (b in node_map):
                edge_1d.append((node_map[a], node_map[b]))
            else:
                unlabled_edge += 1
    print('unlabeled edge count', unlabled_edge)
    return label_1d, edge_1d


def get_label_name(index):
    label = ''
    if index == 0:
        label = 'class'
    elif index == 1:
        label = 'category'
    elif index == 2:
        label = 'subcategory'
    if label:
        print('create a dataset labeled by patent', label)
    else:
        print('unsupport index', index)
        assert(0)
    return label


def read_citation(path=DATASET_DIRECTORY + 'cite75_99.txt'):
    '''
    format
    "CITING","CITED"
    3858241,956203
    3858241,1324234
    3858241,3398406
    3858241,3557384

    citing points to cited
    self-loops are removed
    duplicated edges are removed
    '''
    print('read citation file:', path)
    node_set = set()
    edge_set = dict()
    count = 0
    self_loop = 0
    with open(path, 'r', encoding='utf-8') as r:
        header = next(r)
        for line in r:
            count += 1
            src, dst = line.strip().split(',')
            if src == dst:
                self_loop += 1
            else:
                if src not in edge_set:
                    edge_set[src] = set()
                edge_set[src].add(dst)
                node_set.add(src)
                node_set.add(dst)
    edge_count = sum(len(v) for v in edge_set.values())
    print('node count', len(node_set), 'edge count', edge_count,
        'self-loop count', self_loop, 'duplicated edge count',
        count-self_loop-edge_count)
    return node_set, edge_set


def read_patent(path=DATASET_DIRECTORY + 'apat63_99.txt'):
    '''
    see apat63_99-sample.xlsx for sample
    '''
    print('read patent file:', path)
    patent_dic = dict()
    no_class = 0
    no_category = 0
    no_subcategory = 0
    class_set = set()
    category_set = set()
    subcategory_set = set()
    with open(path, 'r', encoding='utf-8') as r:
        row = next(r).strip().split(',')
        header = {name[1:-1]: idx for idx, name in enumerate(row)}
        print('header', header)
        for line in r:
            row = line.strip().split(',')
            patent = row[header['PATENT']]
            pclass = row[header['NCLASS']]
            category = row[header['CAT']]
            subcategory = row[header['SUBCAT']]
            if patent in patent_dic:
                print('duplicate patent:', patent)
                print('existing:', patent_dic[patent])
                print('current:', pclass, category, subcategory)
            else:
                patent_dic[patent] = (pclass, category, subcategory)
                class_set.add(pclass)
                category_set.add(category)
                subcategory_set.add(subcategory)
                if pclass == '':
                    no_class += 1
                if category == '':
                    no_category += 1
                if subcategory == '':
                    no_subcategory += 1
    print('patent count', len(patent_dic), 'missing class', no_class,
        'category', no_category, 'subcategory', no_subcategory)
    print('class count', len(class_set), 'category count', len(category_set),
        'subcategory count', len(subcategory_set))
    return patent_dic


def write_dateset(label_1d, edge_1d, index):
    label = get_label_name(index)
    path = OUT_DIRECTORY + 'patent-' + label + '.node.txt'
    with open(path, 'w') as w:
        for x in label_1d:
            w.write('%s\n' % (x))
    print('write file', path)
    path = OUT_DIRECTORY + 'patent-' + label + '.edge.txt'
    with open(path, 'w') as w:
        for a, b in edge_1d:
            w.write('%s %s\n' % (a, b))
    print('write file', path)


if __name__ == '__main__':
    '''
    read citation file: ../../../dataset/patent/cite75_99.txt
    node count 3774768 edge count 16518947 self-loop count 1 duplicated edge count 3490
    read patent file: ../../../dataset/patent/apat63_99.txt
    header {'PATENT': 0, 'GYEAR': 1, 'GDATE': 2, 'APPYEAR': 3, 'COUNTRY': 4, 'POSTATE': 5, 'ASSIGNEE': 6, 'ASSCODE': 7, 'CLAIMS': 8, 'NCLASS': 9, 'CAT': 10, 'SUBCAT': 11, 'CMADE': 12, 'CRECEIVE': 13, 'RATIOCIT': 14, 'GENERAL': 15, 'ORIGINAL': 16, 'FWDAPLAG': 17, 'BCKGTLAG': 18, 'SELFCTUB': 19, 'SELFCTLB': 20, 'SECDUPBD': 21, 'SECDLWBD': 22}
    patent count 2923922 missing class 0 category 0 subcategory 0
    class count 418 category count 6 subcategory count 36
    create a dataset labeled by patent subcategory
    node with labels 2755865 / 3774768
    node without labels 1018903
    node with labels and edges 2745762 / 3774768
    unlabeled edge count 2553537
    create a dataset labeled by patent subcategory
    ../../../dataset/patent/patent-subcategory.node.txt
    '''
    node_set, edge_set = read_citation()
    patent_dic = read_patent()
    create_dataset(node_set, edge_set, patent_dic, 2)
