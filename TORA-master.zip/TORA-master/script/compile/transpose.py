#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '02:03 AM Saturday Feb 4 2022'
__doc__ = '''transpose.py
given transpose function name for execution
generate C++ code for execution
'''

from function import Context, Function
from wcoj import Execution

# function name in C++
IndexSeparator = '_';   # separate vertex index
MarkNonedge = 'n';
MarkEdge = 'e';         # input edge Operand
MarkInput = 'i';        # input Operand
MarkSymBreak = 's';     # symmetry breaking rule
MismatchInput = 'x';
NonedgeAdd = '+';       # non-edge input name

# type name in C++
'Iterator'
'Node'

# variable name
'COUNT'
'in'
'result'
'VERTEX_COUNT'


class Initialization(Context):
    def __init__(self, builder):
        self._f = builder._f
        self._exe = builder._exe

    def __enter__(self):
        # empty function body checking is before this
        # initialize local variable
        out_index = self._exe.vertex_size() - 2
        var_type = Initialization.var_type() % (out_index)
        variable = Initialization.variable()
        self._f.statement('%s %s;' % (var_type, variable))

    def __exit__(self, type, value, traceback):
        f_name = self.function_name()
        variable = Initialization.variable()
        self._f.statement('return %s(%s);' % (f_name, variable))

    def function_name(self):
        return 'BuildSortTrie%s' % (self._exe.vertex_size())

    @classmethod
    def variable(cls):
        return 'map'

    @classmethod
    def var_type(cls):
        return 'HashTrie<%s>'


class Iterator(object):
    def __init__(self, out_index):
        self._out_index = out_index

    def argument(self):
        if self._out_index == 0:
            return 'in'
        else:
            return '%s.GetNode()' % (Iterator.name(self._out_index - 1))

    def increment(self):
        return Iterator.name(self._out_index) + '.Next()'

    def init(self, argument):
        if self._out_index == 0:
            return 'Iterator it0(in)'
        else:
            it = Iterator.name(self._out_index)
            return 'Iterator %s(%s)' % (it, argument)

    @classmethod
    def name(cls, index):
        # i0
        return 'i%s' % (index)

    def range(self):
        return Iterator.name(self._out_index) + '.InRange()'


class Transpose(object):
    def __init__(self, execution, function=Function(0, 4)):
        self._exe = execution
        self._f = function
        self._f._data = list()      # default parameter object is shared
        self._input = self._exe.input_1d[0]
        # transpose should have index for only 1 input
        assert(len(self._exe.input_1d) == 1)

    def build(self):
        # return the function build result
        with self._f.function_block('Node *%s(Node *in)' % self._exe.name()):
            vertex_size = self._exe.vertex_size()
            if vertex_size:
                with Initialization(self):
                    self._build_for_loop(0, vertex_size)
        return self._f

    def _add_symmetrybreak(self, variable, out_index):
        # determine symmetry breaking part
        result = list()
        low = _concat_iterator(self._exe.low_1d(out_index), 'MAX')
        if low:
            result.append(low)
        result.append(variable)
        high = _concat_iterator(self._exe.high_1d(out_index), 'MIN')
        if high:
            result.append(high)
        return ', '.join(result)

    def _build_for_loop(self, out_index, stop_size):
        # build for loop for out_index
        it = Iterator(out_index)
        symbreak = self._add_symmetrybreak(it.argument(), out_index)
        with self._f.for_block(it.init(symbreak), it.range(), it.increment()):
            # initialize for the next output index
            out_index += 1
            if out_index < stop_size:
                self._build_for_loop(out_index, stop_size)
            else:
                # build inner most, always save result
                variable = Initialization.variable()
                iter_name = '%s.Value()' % (Iterator.name('%s'))
                key_1d = [(iter_name % (x)) for x in self._input[:-1]]
                key = '['+ ']['.join(key_1d) + ']'
                value = iter_name % (self._input[-1])
                self._f.statement('%s%s = %s' % (variable, key, value))

    def _save_intermediate(self, out_index):
        append = '%s.Value(), node%s' % (Iterator.name(out_index), out_index)
        self._f.statement('node%s.Append(%s);' % (out_index - 1, append))


def _concat_iterator(index_1d, f_name):
    join_1d = [(Iterator.name(x) + '.Value()') for x in index_1d]
    if join_1d:
        # example: 'MIN2(j0.Value(), j1.Value())'
        return f_name + '%s(%s)' % (len(join_1d), ', '.join(join_1d))
    return ''


def build_transpose_example_0():
    input_1d = [
        [0, 1, 3, 2, ],
    ]
    rule_1d = [
        [2, 0, 1, ],
    ]
    execution = Execution(input_1d, rule_1d)
    builder = Transpose(execution)
    f = builder.build()
    print(f)


if __name__ == '__main__':
    build_transpose_example_0()
