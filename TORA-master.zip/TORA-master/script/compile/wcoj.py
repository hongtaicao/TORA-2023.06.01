#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '17:49 PM Sunday Jan 29 2022'
__doc__ = '''wcoj.py
given wcoj function name for execution
generate C++ code for execution
'''

from function import Context, Function

# function name in C++
IndexSeparator = '_';   # separate vertex index
MarkNonedge = 'n';
MarkEdge = 'e';         # input edge Operand
MarkInput = 'i';        # input Operand
MarkSymBreak = 's';     # symmetry breaking rule
MismatchInput = 'x';
NonedgeAdd = '+';       # non-edge input name

# type name in C++
'Iterator'
'Node'

# variable name
'COUNT'
'in'
'result'
'VERTEX_COUNT'


class Execution(object):
    def __init__(self, input_1d, rule_1d):
        # input_1d, each element is a list of an input vertex index
        # rule_1d, each element is a rule, rule is a list of bind vertex
        # iterator type
        self.iterator_type = ['', '0', '1']
        # '': does not iterator non-edge
        # '0': iterate 0-th index of non-edge
        # '1': iterate 1-th index of non-edge
        # validate input
        self.input_1d = input_1d
        self._rule_1d = rule_1d
        self._validate_arg()
        self._index_input_1d()
        self._index_rule_1d()

    def _index_input_1d(self):
        self._in_index = {
            key: dict() for key in self.iterator_type
        }
        # the ith input
        ith = 0
        for operand in self.input_1d:
            if operand[0] == MarkNonedge:
                # non-edge as input
                for i in range(1, 3):
                    iter_type = self.iterator_type[i]
                    _dict_append(self._in_index[iter_type], operand[i], ith)
            else:
                # other input
                iter_type = self.iterator_type[0]
                for out_index in operand:
                    _dict_append(self._in_index[iter_type], out_index, ith)
            ith += 1

    def _index_rule_1d(self):
        # first find the total order of out_index
        # each rule is a partial order
        # unordered represented by set, ordered represented by list
        # initialize
        self._rule_index = dict()
        self._sort_set = list()
        self._sort_set.append(set())
        for rule in self._rule_1d:
            for out_index in rule:
                self._sort_set[0].add(out_index)
        for rule in self._rule_1d:
            for rank, collection in enumerate(self._sort_set):
                # find overlapping of rule and self._sort_set
                if rule[0] in collection:
                    # can split other in the same set to the next set
                    rank += 1
                    if rank == len(self._sort_set):
                        self._sort_set.append(set())
                    for out_index in rule[1:]:
                        if out_index in collection:
                            # move from current set to the next set
                            collection.remove(out_index)
                            self._sort_set[rank].add(out_index)
        for rank, collection in enumerate(self._sort_set):
            for out_index in collection:
                self._rule_index[out_index] = rank

    def _validate_arg(self):
        for operand in self.input_1d:
            for index in operand:
                assert((type(index) == int) or (index ==MarkNonedge))
        for rule in self._rule_1d:
            for index in rule:
                assert(type(index) == int)

    def low_1d(self, out_index):
        # return output index that value should be lower than
        # the given out_index
        # out_index rank is self._rule_index[out_index]
        # therefore candidate is from sets whose rank < out_index rank
        candidate = list()
        if out_index in self._rule_index:
            for rank in range(0, self._rule_index[out_index]):
                for low_index in self._sort_set[rank]:
                    if low_index < out_index:
                        candidate.append(low_index)
        return sorted(candidate)

    def in_index_1d(self, iter_type, out_index):
        return sorted(self._in_index[iter_type].get(out_index, list()))

    def high_1d(self, out_index):
        # return output index that value should be higher than
        # the given out_index
        # out_index rank is self._rule_index[out_index]
        # therefore candidate is from sets whose rank > out_index rank
        candidate = list()
        if out_index in self._rule_index:
            start = self._rule_index[out_index] + 1
            for rank in range(start, len(self._sort_set)):
                for low_index in self._sort_set[rank]:
                    if low_index < out_index:
                        candidate.append(low_index)
        return sorted(candidate)

    def name(self):
        f_name = ''
        for operand in self.input_1d:
            f_name += MarkInput
            for index in operand:
                f_name += ('%s_' % (index))
        for rule in self._rule_1d:
            f_name += MarkSymBreak
            for index in rule:
                f_name += ('%s_' % (index))
        return f_name

    def vertex_size(self):
        # number of unique vertex index of input
        index_set = set()
        for operand in self.input_1d:
            for index in operand:
                if index != MarkNonedge:
                    index_set.add(index)
        return len(index_set)


class Initialization(Context):
    def __init__(self, builder):
        self._f = builder._f
        self._exe = builder._exe
        self._macro = builder._macro

    def __enter__(self):
        # empty function body checking is before this
        # initialize local variable
        count = self._exe.vertex_size() - 1
        if self._macro:
            self._f.statement('InitializeResult;')
            for out_index in range(count):
                self._f.statement('InitializeNode_%s;' % (out_index))
        else:
            self._f.statement('Node *result = new Node(VERTEX_COUNT);')
            for out_index in range(count):
                self._f.statement('Node node%s(MAX_DEGREE);' % (out_index))
        # define and initialize iterator
        # build index for iterator at the same time
        # index by iter_type and out_index, return a list of Iterator
        iterator_index = {
            '': dict(),
            '0': dict(),
            '1': dict(),
        }
        for iter_type in self._exe.iterator_type:
            in_index_1d = self._exe.in_index_1d(iter_type, 0)
            if in_index_1d:
                it = Iterator(iter_type, in_index_1d, 0)
                self._f.statement(it.init())
                iterator_index[iter_type][0] = it
        for out_index in range(1, self._exe.vertex_size()):
            # define only
            for iter_type in self._exe.iterator_type:
                in_index_1d = self._exe.in_index_1d(iter_type, out_index)
                if in_index_1d:
                    it = Iterator(iter_type, in_index_1d, out_index)
                    self._f.statement(it.define())
                    iterator_index[iter_type][out_index] = it
        return iterator_index

    def __exit__(self, type, value, traceback):
        if self._macro:
            self._f.statement('return Result;')
        else:
            self._f.statement('return result;')


class Iterator(object):
    Name = 'i%s_%s'

    def __init__(self, iter_type, in_index_1d, out_index):
        self.in_index_1d = in_index_1d
        self.iter_type = iter_type
        self.size = len(in_index_1d)
        self._name = (Iterator.Name % (out_index, iter_type)) + '[%s]'

    def define(self):
        return 'Iterator *%s;' % (self.name(self.size))

    def init(self):
        # new Iterator(in[0]), new Iterator(in[0])
        it_1d = [('new Iterator(in[%s])' % (x)) for x in self.in_index_1d]
        # Iterator *i_0_1[2] {new Iterator(in[0]), new Iterator(in[0])};
        return 'Iterator *%s {%s};' % (self.name(self.size), ', '.join(it_1d))

    def name(self, size):
        # i0_[size]
        return self._name % (size)


class Join(object):
    def __init__(self, execution, out_index):
        self._exe = execution
        self._out_index = out_index
        self._var_name = Join.name(out_index)

    def range(self):
        return '%s.InRange()' % (self._var_name)

    def increment(self):
        return '%s.Next()' % (self._var_name)

    def init(self):
        # build code for Join object
        var_type = 'Join'
        var_list = list()
        for iter_type in self._exe.iterator_type:
            in_index_1d = self._exe.in_index_1d(iter_type, self._out_index)
            if in_index_1d:
                var_type += iter_type
                size = len(in_index_1d)
                init = Iterator.Name % (self._out_index, iter_type)
                init += (', %s' % (size))
                var_list.append(init)
        return '%s %s(%s)' % (var_type, self._var_name, ', '.join(var_list))

    @classmethod
    def name(cls, out_index):
        return 'j%s' % (out_index)


class WCOJ(object):
    def __init__(self, execution, macro, function=Function(0, 4)):
        self._exe = execution
        self._f = function
        self._f._data = list()      # default parameter object is shared
        self._iter_index = dict()   # iterator index
        self._join_1d = list()      # join
        # macro: use macro or not
        # use it to switch mode for List, Memory and Counting
        self._macro = macro

    def build(self):
        # return the function build result
        signature = 'Node *%s(std::vector<Node *> &in)' % self._exe.name()
        with self._f.function_block(signature):
            vertex_size = self._exe.vertex_size()
            if vertex_size:
                with Initialization(self) as iterator_index:
                    self._iter_index = iterator_index
                    self._build_for_loop(0, vertex_size)
        return self._f

    def _add_symmetrybreak(self, node, out_index):
        # determine symmetry breaking part
        result = list()
        low = _concat_join(self._exe.low_1d(out_index), 'MAX')
        if low:
            result.append(low)
        result.append(node)
        high = _concat_join(self._exe.high_1d(out_index), 'MIN')
        if high:
            result.append(high)
        return ', '.join(result)

    def _build_for_loop(self, out_index, stop_size):
        # build for loop for out_index and initialize defined Iterator
        j = Join(self._exe, out_index)
        self._join_1d.append(j)
        with self._f.for_block(j.init(), j.range(), j.increment()):
            # initialize for the next output index
            out_index += 1
            if out_index < stop_size:
                for iter_type in self._exe.iterator_type:
                    it = self._iterator(iter_type, out_index)
                    it_index = 0
                    if iter_type:
                        # symmetry breaking cannot bind to type '0' or type '1'
                        # otherwise wrong result
                        add_symmetrybreak = False
                    else:
                        add_symmetrybreak = True
                    for x in self._exe.in_index_1d(iter_type, out_index):
                        # x: index of input that computes out_index vertex
                        # find how this input previous vertex is computed
                        operand = self._exe.input_1d[x]
                        for ith, index in enumerate(operand):
                            if index == out_index:
                                # ith input vertex -> out_index output vertex
                                break
                        if ith == 0:
                            # impossible to have symmetry breaking rule
                            node = 'in[%s]' % (x)
                        else:
                            node = self._node(operand, x, ith)
                            if add_symmetrybreak:
                                # find symmetry breaking rule involved
                                node = self._add_symmetrybreak(node, out_index)
                                # symmetry break is added only once
                                add_symmetrybreak = False
                        name = it.name(it_index)
                        statement = '%s = new Iterator(%s);' % (name, node)
                        it_index += 1
                        self._f.statement(statement)
                self._build_for_loop(out_index, stop_size)
                # save result
                if self._macro:
                    if out_index == 1:
                        self._f.statement('ResultAppendValueNode;')
                    else:
                        x = 'node%s' % (out_index - 2)
                        y = Join.name(out_index - 1)
                        z = 'node%s' % (out_index - 1)
                        arg = ', '.join([x, y, z])
                        self._f.statement('NodeAppendValueNode(%s);' % (arg))
                else:
                    # no Macro
                    if out_index == 1:
                        self._f.statement('result->Append(j0.Value(), node0);')
                    else:
                        ith = out_index - 1
                        append = '%s.Value(), node%s' % (Join.name(ith), ith)
                        statement = 'node%s.Append(%s);' % (ith - 1, append)
                        self._f.statement(statement)
            else:
                # build inner most
                if self._macro:
                    # use Macro
                    join = ', '.join(Join.name(x) for x in range(0, stop_size))
                    self._f.statement('Inner%s(%s);' % (stop_size, join))
                else:
                    # always save result
                    ith = out_index - 1
                    append = '%s.Value()' % (Join.name(ith))
                    statement = 'node%s.Append(%s);' % (ith - 1, append)
                    self._f.statement(statement)

    def _iterator(self, iter_type, out_index):
        # return the list of iterator computing the out_index
        return self._iter_index.get(iter_type, dict()).get(out_index, None)

    def _node(self, operand, i_in, i_op):
        # operand: the current operand
        # i_in: index of the current input operand
        # i_op: the index of the current output vertex index
        # current output vertex index = operand[i_op]
        # find the type, the number of other involved input
        # for the previous output vertex index
        if operand[0] == MarkNonedge:
            # non-edge input Operand
            if i_op == 1:
                # use input
                return 'in[%s]' % (i_in)
            iter_type = str(i_op - 2)
        else:
            if i_op == 0:
                return 'in[%s]' % (i_in)
            iter_type = ''
        # previous out_index
        prev_index = operand[i_op - 1]
        # all input computing the previous out_index vertex
        in_index_1d = self._exe.in_index_1d(iter_type, prev_index)
        for ith, x_op in enumerate(in_index_1d):
            if x_op == i_in:
                node = Join.name(prev_index)
                node += ('.Child%s(%s)' % (iter_type, ith))
                break
        return node


def _concat_join(index_1d, f_name):
    join_1d = [(Join.name(x) + '.Value()') for x in index_1d]
    if join_1d:
        # example: 'MIN2(j0.Value(), j1.Value())'
        return f_name + '%s(%s)' % (len(join_1d), ', '.join(join_1d))
    return ''


def _dict_append(dic, key, value):
    if key not in dic:
        dic[key] = list()
    dic[key].append(value)


def build_wcoj_example_0():
    '''
    i0_1_3_4_5_i0_2_3_4_5_in1_2_s0_2_s1_0_2_ <- i0_1_3_4_i0_2_3_4_in1_2_s2_0_1_ | i0_1_3_4_i0_2_3_4_in1_2_s2_0_1_ | +0+1 |
    '''
    input_1d = [
        [0, 1, 3, 4, 5, ],
        [0, 2, 3, 4, 5, ],
        [MarkNonedge, 1, 2, ],
    ]
    rule_1d = [
        [0, 2, ],
        [1, 0, 2, ],
    ]
    execution = Execution(input_1d, rule_1d)
    for macro in [True, False]:
        builder = WCOJ(execution, macro)
        f = builder.build()
        print(f)


def build_wcoj_example_1():
    '''
    i0_1_3_4_i0_2_3_4_in1_2_s2_0_1_ <- in0_1_i0_2_3_i1_2_3_ | in0_1_i0_2_3_i1_2_3_ | +0+1 |
    '''
    input_1d = [
        [0, 1, 3, 4, ],
        [0, 2, 3, 4, ],
        [MarkNonedge, 1, 2, ],
    ]
    rule_1d = [
        [2, 0, 1, ],
    ]
    execution = Execution(input_1d, rule_1d)
    for macro in [True, False]:
        builder = WCOJ(execution, macro)
        f = builder.build()
        print(f)


if __name__ == '__main__':
    '''
    in0_1_i0_2_3_i1_2_3_ <- +0+1 | i0_1_in0_2_i1_2_s2_0_ | i0_1_in0_2_i1_2_s2_0_ |
    i0_1_in0_2_i1_2_s2_0_ <- x | +0+1 | x |
    '''
    build_wcoj_example_1()
