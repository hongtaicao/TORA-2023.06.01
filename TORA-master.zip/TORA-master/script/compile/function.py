#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = 'Wednesday 14:50 PM Sept 30 2020'
__doc__ = 'function.py'


class Context(object):
    def __enter__(self):
        raise NotImplementedError(self.__class__.__name__ + '.__enter__()')

    def __exit__(self, type, value, traceback):
        raise NotImplementedError(self.__class__.__name__ + '.__exit__()')


class Block(Context):
    def __init__(self, block, exit):
        super().__init__()
        self._block = block
        self._exit = exit

    def __enter__(self):
        self._block.inc_indent()
        return self._block

    def __exit__(self, type, value, traceback):
        self._block.dec_indent()
        self._block.write(self._exit)


class NoIndentBlock(Block):
    def __init__(self, block, exit):
        super().__init__()

    def __enter__(self):
        return self._block

    def __exit__(self, type, value, traceback):
        self._block.write(self._exit)


class Function(object):
    # handle indent
    # handle parentheses
    def __init__(self, indent, indent_step):
        self._data = []
        self._indent = indent
        self._indent_step = indent_step

    def __str__(self):
        return ''.join(self._data)

    def else_line(self):
        self.dec_indent()
        self.write('} else {\n')
        self.inc_indent()

    def else_if_line(self, content):
        self.dec_indent()
        self.write('} else if (%s) {\n' % content)
        self.inc_indent()

    def for_block(self, for_initial, for_condition, for_increment):
        t = (for_initial, for_condition, for_increment)
        self.write('for (%s; %s; %s) {\n' % t)
        return Block(self, '}\n')

    def function_block(self, signature):
        self.write(signature + ' {\n')
        return Block(self, '}\n')

    def if_block(self, content):
        self.write('if (%s) {\n' % (content))
        return Block(self, '}\n')

    def no_indent_block(self, head, tail):
        self.write(head)
        return NoIndentBlock(self, tail)

    def statement(self, content):
        self.write(content + '\n')

    def write(self, content):
        # handle indent
        self._data.append(' ' * int(self.indent) + content)

    @property
    def data(self):
        return self._data

    def dec_indent(self):
        self._indent -= self._indent_step

    def inc_indent(self):
        self._indent += self._indent_step

    @property
    def indent(self):
        return self._indent
