#!/usr/bin/env python
# -*- coding: utf-8 -*-
# python3.6


__date__ = '08:38 AM Saturday Feb 4 2022'
__doc__ = '''sorttrie.py
given build sorttrie function name for execution
generate C++ code for execution
'''

from function import Context, Function
from transpose import Execution, Initialization as TInit


class Initialization(Context):
    def __init__(self, sorttrie, key_1d):
        self._f = sorttrie._f
        self._key_1d = key_1d
        self._result = 'node0';
        self._size = sorttrie.size

    def __enter__(self):
        argument = (self._result, self._key_1d)
        statement = 'Node *%s = new Node(%s.size());' % argument
        self._f.statement(statement)

    def __exit__(self, type, value, traceback):
        self._f.statement('return %s;' % (self._result))


class SortTrie(object):
    Name = 'BuildSortTrie%s'
    def __init__(self, size, function=Function(0, 4)):
        # code to build a sort trie from nested map
        self._f = function
        self._f._data = list()
        self.size = size

    def build(self):
        # use function overload
        f_name = SortTrie.name('')
        var_type = TInit.var_type() % (self.size)
        variable = TInit.variable()
        argument = '%s &%s0' % (var_type, variable)
        with self._f.function_block('Node *%s(%s)' % (f_name, argument)):
            if self.size:
                key = SortTrie.keyname(0)
                key_1d = self._build_sorted_key(0)
                with Initialization(self, key_1d):
                    self._build_for_loop(key, key_1d, 0, self.size)
        return self._f

    @classmethod
    def name(cls, size):
        return cls.Name % (size)

    def _build_for_loop(self, key, key_1d, out_index, stop_size):
        # build for loop for out_index
        with self._f.function_block('for (auto &%s : %s)' % (key, key_1d)):
            # initialize for the next output index
            prev_map = self._prev_map(out_index)
            out_index += 1
            size = '%s[%s].size()' % (prev_map, key)
            statement = 'Node *node%s = new Node(%s);' % (out_index, size)
            self._f.statement(statement)
            if out_index < stop_size - 1:
                var_type = TInit.var_type() % (stop_size - out_index)
                var_type = 'auto'
                variable = TInit.variable() + ('%s' % (out_index))
                statement = '%s &%s' % (var_type, variable)
                statement += (' = %s[%s];' % (prev_map, key))
                self._f.statement(statement)
                next_key = SortTrie.keyname(out_index)
                key_1d = self._build_sorted_key(out_index)
                self._build_for_loop(next_key, key_1d, out_index, stop_size)
            else:
                # the inner most level value is a vector
                self._f.statement('auto &vec = %s[%s];' % (prev_map, key))
                self._f.statement('std::sort(vec.begin(), vec.end());')
                with self._f.function_block('for (auto &value : vec)'):
                    self._f.statement('node%s->Append(value);' % (out_index))
            # append result. use pointer because no need ReSize
            argument = '%s, node%s' % (key, out_index)
            statement = 'node%s->Append(%s);' % (out_index - 1, argument)
            self._f.statement(statement)

    @classmethod
    def keyname(self, out_index):
        return 'key%s' % (out_index)

    def _build_sorted_key(self, out_index):
        key_1d = '%s_1d' % (SortTrie.keyname(out_index))
        self._f.statement('vid_1d_t %s;' % (key_1d))
        prev_map = self._prev_map(out_index)
        self._f.statement('%s.reserve(%s.size());' % (key_1d, prev_map))
        argument = '(%s, %s);' % (prev_map, key_1d)
        self._f.statement(_sortkey() + argument);
        return key_1d

    def _prev_map(self, out_index):
        return TInit.variable() + '%s' % (out_index)


def _sortkey():
    return 'SortMapKey'

def build_sortkey():
    # a template function to be in a heafer file
    f = Function(0, 4)
    f.statement('template<typename map_T>')
    argument = 'const map_T &map, vid_1d_t &key_1d'
    with f.function_block('void %s(%s)' % (_sortkey(), argument)):
        with f.function_block('for (auto &pair : map)'):
            f.statement('key_1d.push_back(pair.first);')
        f.statement('std::sort(key_1d.begin(), key_1d.end());')
    return f


def build_typedef_map(vertex_size):
    code_1d = list()
    var_type = TInit.var_type()
    var = TInit.variable() + '%s'
    p0 = 'typedef std::unordered_map<vid_t, vid_t> %s;' % (var_type)
    p1 = 'typedef std::unordered_map<vid_t, %s> %s;' % (var_type, var_type)
    for out_index in range(vertex_size):
        if out_index == 0:
            code_1d.append(p0 % (out_index))
        elif out_index < vertex_size - 1:
            code_1d.append(p1 % (out_index - 1, out_index))
    return code_1d


def build_sorttrie_example_0():
    for size in range(2, 10):
        builder = SortTrie(size)
        f = builder.build()
        print(f)


if __name__ == '__main__':
    print('\n'.join(build_typedef_map(4)))
    print('')
    print(build_sortkey())
    build_sorttrie_example_0()
