G1 u-path-3 2-path
G2 u-clique-3 triangle 3-clique 3-cycle
G3 u-path-4 3-path
G4 u-star-4 3-star
G5 u-cycle-4 4-cycle rectangle
G6 u-4-4 tailed-triangle
G7 u-4-5 diamond
G8 u-clique-4 4-clique
G9 u-path-5 4-path
G10 u-prong prong
G11 u-star-5 4-star
G12 u-double-tailed-triangle double-tailed-triangle
G13 u-long-tailed-triangle long-tailed-triangle
G14 u-forktailed-triangle forktailed-triangle
G15 u-cycle-5 5-cycle pentagon
G16 u-tailed-4-cycle tailed-4-cycle
G17 u-stingray stingray
G18 u-hourglass hourglass
G19 u-cobra cobra
G20 u-3-wedge-collision 3-wedge-collision
G21 u-hatted-4-cycle hatted-4-cycle house
G22 u-3-triangle-collision 3-triangle-collision
G23 u-tailed-4-clique tailed-4-clique
G24 u-triangle-strip triangle-strip
G25 u-diamond-wedge-collision diamond-wedge-collision
G26 u-hatted-4-clique hatted-4-clique
G27 u-wheel-4 4-wheel
G28 u-almost-clique-5 almost-5-clique
G29 u-clique-5 5-clique