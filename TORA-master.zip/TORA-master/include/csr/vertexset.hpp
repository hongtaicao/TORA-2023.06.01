/*
 * vertexset.hpp
 *
 * a VertexSet that always allocate space for data
 * this is used for Difference and Intersection result, expensive
 *
 *  Created on: 17:07 PM Monday 2023-4-17
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_CSR_VERTEXSET_HPP_
#define INCLUDE_CSR_VERTEXSET_HPP_

#include "include/common.hpp"
#include "include/csr/neighborset.hpp"

namespace csr {

class NeighborSet;

class VertexSet {
public:
    static vid_t MAX_DEGREE;

    VertexSet()
            : data(new vid_t[VertexSet::MAX_DEGREE]), size(0) {
    }

    VertexSet(const VertexSet &) = delete;
    VertexSet(VertexSet &&) = default;
    ~VertexSet() {
        delete[] this->data;
    }

    VertexSet &operator=(const VertexSet &) = delete;
    VertexSet &operator=(VertexSet &&) = default;

    // difference method always modify this instance
    // set_a - set_b
    template<typename T1, typename T2>
    void DSet(const T1 &a, const T2 &b) {
        /* save difference of a and b into this
         * a can be the same object as this
         * therefore the loop can only modify this->data, but not this->size
         * this->size should be updated at the end
         */
        vid_t idx_l = 0, idx_r = 0, idx_out = 0;
        while ((idx_l < a.size) && (idx_r < b.size)) {
            vid_t left = a.data[idx_l];
            vid_t right = b.data[idx_r];
            if (left <= right) {
                idx_l++;
            }
            if (right <= left) {
                idx_r++;
            }
            if (left < right) {
                this->data[idx_out++] = left;
            }
        }
        while (idx_l < a.size) {
            vid_t left = a.data[idx_l];
            idx_l++;
            this->data[idx_out++] = left;
        }
        // loop complete and then update the size
        this->size = idx_out;
    }

    // set_a - set_b - {vertex_b} and smaller than up
    template<typename T1, typename T2>
    void DSet(const T1 &a, const vid_t vb, const T2 &b, const vid_t up) {
        if (vb >= up) {
            return this->DSet(a, b, up);
        } else {
            vid_t idx_l = 0, idx_r = 0, idx_out = 0;
            while (idx_l < a.size && idx_r < b.size) {
                vid_t left = a.data[idx_l];
                vid_t right = b.data[idx_r];
                if (left >= up) {
                    break;
                }
                if (right >= up) {
                    break;
                }
                if (left < right) {
                    idx_l++;
                    if (left != vb) {
                        this->data[idx_out++] = left;
                    }
                } else if (right < left) {
                    idx_r++;
                } else {
                    idx_l++;
                    idx_r++;
                }
            }
            while (idx_l < a.size) {
                vid_t left = a.data[idx_l];
                if (left >= up) {
                    break;
                }
                idx_l++;
                if (left != vb) {
                    this->data[idx_out++] = left;
                }
            }
            this->size = idx_out;
        }
    }

    // set_a - set_b - {vertex_b}
    template<typename T1, typename T2>
    void DSet(const T1 &a, const vid_t b_vertex, const T2 &b) {
        /* save difference of a and b into this, also exclude b_vertex
         * a can be the same object as this
         */
        vid_t idx_l = 0, idx_r = 0, idx_out = 0;
        while ((idx_l < a.size) && (idx_r < b.size)) {
            vid_t left = a.data[idx_l];
            vid_t right = b.data[idx_r];
            if (left < right) {
                idx_l++;
                if (left != b_vertex) {
                    this->data[idx_out++] = left;
                }
            } else if (right < left) {
                idx_r++;
            } else {
                idx_l++;
                idx_r++;
            }
        }
        while (idx_l < a.size) {
            vid_t left = a.data[idx_l];
            idx_l++;
            if (left != b_vertex) {
                this->data[idx_out++] = left;
            }
        }
        this->size = idx_out;
    }

    // set_a - set_b and smaller than up
    template<typename T1, typename T2>
    void DSet(const T1 &a, const T2 &b, const vid_t up) {
        /* save difference of a and b into this, less than up
         * a can be the same object as this
         */
        vid_t idx_l = 0, idx_r = 0, idx_out = 0;
        while ((idx_l < a.size) && (idx_r < b.size)) {
            vid_t left = a.data[idx_l];
            vid_t right = b.data[idx_r];
            if (left >= up) {
                break;
            }
            if (right >= up) {
                break;
            }
            if (left < right) {
                idx_l++;
                this->data[idx_out++] = left;
            } else if (right < left) {
                idx_r++;
            } else {
                idx_l++;
                idx_r++;
            }
        }
        while (idx_l < a.size) {
            vid_t left = a.data[idx_l];
            if (left >= up)
                break;
            idx_l++;
            this->data[idx_out++] = left;
        }
        this->size = idx_out;
    }

    // intersect
    template<typename T1, typename T2>
    void ISet(const T1 &a, const T2 &b) {
        /* save intersect of a and b into this
         * a can be the same object as this
         */
        vid_t idx_l = 0, idx_r = 0, idx_out = 0;
        while ((idx_l < a.size) && (idx_r < b.size)) {
            vid_t left = a.data[idx_l];
            vid_t right = b.data[idx_r];
            if (left < right) {
                idx_l++;
            } else if (right < left) {
                idx_r++;
            } else {
                // left == right
                idx_l++;
                idx_r++;
                this->data[idx_out++] = left;
            }
        }
        this->size = idx_out;
    }

    template<typename T1, typename T2>
    void ISet(const T1 &a, const T2 &b, const vid_t up) {
        /* save intersect of a and b ( < up ) into this
         * a can be the same object as this
         */
        vid_t idx_l = 0, idx_r = 0, idx_out = 0;
        while (idx_l < a.size && idx_r < b.size) {
            vid_t left = a.data[idx_l];
            vid_t right = b.data[idx_r];
            if (left >= up) {
                break;
            }
            if (right >= up) {
                break;
            }
            if (left < right) {
                idx_l++;
            } else if (right < left) {
                idx_r++;
            } else {
                // left == right
                idx_l++;
                idx_r++;
                this->data[idx_out++] = left;
            }
        }
        this->size = idx_out;
    }

    template<typename T1, typename T2>
    void USet(const T1 &a, const T2 &b) {
        /* save union of a and b into this
         * a or b CANNOT be the same object as this
         * therefore this->size can be updated during looping
         */
        vid_t idx_l = 0, idx_r = 0;
        this->size = 0;
        // union of two sets
        while (idx_l < a.size && idx_r < b.size) {
            vid_t left = a.data[idx_l];
            vid_t right = b.data[idx_r];
            if (left < right) {
                idx_l++;
                this->data[this->size++] = left;
            } else if (right < left) {
                idx_r++;
                this->data[this->size++] = right;
            } else {
                idx_l++;
                idx_r++;
                this->data[this->size++] = left;
            }
        }
        // copy remaining
        this->Copy(a, idx_l);
        this->Copy(b, idx_r);
    }

    template<typename T1, typename T2>
    void USet(const T1 &a, const T2 &b, const vid_t up) {
        /* save union of a and b into this ( < up )
         * a or b CANNOT be the same object as this
         */
        vid_t idx_l = 0, idx_r = 0;
        this->size = 0;
        while (idx_l < a.size && idx_r < b.size) {
            vid_t left = a.data[idx_l];
            vid_t right = b.data[idx_r];
            if (left < right) {
                if (left >= up) {
                    return;
                }
                idx_l++;
                this->data[this->size++] = left;
            } else if (right < left) {
                if (right >= up) {
                    return;
                }
                idx_r++;
                this->data[this->size++] = right;
            } else {
                if (left >= up) {
                    return;
                }
                idx_l++;
                idx_r++;
                this->data[this->size++] = left;
            }
        }
        this->Copy(a, idx_l, up);
        this->Copy(b, idx_r, up);
    }

    inline vid_t Vertex(const vid_t index) const {
        return this->data[index];
    }

    vid_t *data;
    vid_t size;

private:
    template<typename T>
    void Copy(const T &a, vid_t index) {
        while (index < a.size) {
            this->data[this->size++] = a.data[index++];
        }
    }

    template<typename T>
    void Copy(const T &a, vid_t index, const vid_t up) {
        while (index < a.size) {
            vid_t vid = a.data[index++];
            if (vid >= up) {
                return;
            }
            this->data[this->size++] = vid;
        }
    }
};

} // namespace csr

#endif /* INCLUDE_CSR_VERTEXSET_HPP_ */
