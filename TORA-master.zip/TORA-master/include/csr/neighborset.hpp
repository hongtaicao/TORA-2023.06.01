/*
 * neighborset.hpp
 *
 * a VertexSet that does not allocate space for data
 * all data come from csr::Graph and are shared
 * can be used for range query, which only changes size, not expensive
 *
 *  Created on: Tuesday 11:56 AM 2023-4-18
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_CSR_NEIGHBORSET_HPP_
#define INCLUDE_CSR_NEIGHBORSET_HPP_

#include "include/common.hpp"

namespace csr {

template<typename T1, typename T2>
vid_t DifferenceSize(const T1 &a, const T2 &b) {
    vid_t idx_l = 0, idx_r = 0, idx_out = 0;
    while ((idx_l < a.size) && (idx_r < b.size)) {
        vid_t left = a.data[idx_l];
        vid_t right = b.data[idx_r];
        if (left < right) {
            idx_l++;
            idx_out++;
        } else if (right < left) {
            idx_r++;
        } else {
            idx_l++;
            idx_r++;
        }
    }
    // count remaining items in a
    return idx_out + a.size - idx_l;
}

template<typename T1, typename T2>
vid_t DifferenceSize(const T1 &a, const vid_t b_vertex, const T2 &b) {
    vid_t idx_l = 0, idx_r = 0, idx_out = 0;
    while ((idx_l < a.size) && (idx_r < b.size)) {
        vid_t left = a.data[idx_l];
        vid_t right = b.data[idx_r];
        if (left < right) {
            idx_l++;
            if (left != b_vertex) {
                idx_out++;
            }
        } else if (right < left) {
            idx_r++;
        } else {
            idx_l++;
            idx_r++;
        }
    }
    while (idx_l < a.size) {
        vid_t left = a.data[idx_l];
        idx_l++;
        if (left != b_vertex) {
            idx_out++;
        }
    }
    return idx_out;
}

template<typename T1, typename T2>
vid_t DifferenceSize(const T1 &a, const T2 &b, const vid_t up) {
    vid_t idx_l = 0, idx_r = 0, idx_out = 0;
    while ((idx_l < a.size) && (idx_r < b.size)) {
        vid_t left = a.data[idx_l];
        vid_t right = b.data[idx_r];
        if (left >= up) {
            break;
        }
        if (right >= up) {
            break;
        }
        if (left < right) {
            idx_l++;
            idx_out++;
        } else if (right < left) {
            idx_r++;
        } else {
            idx_l++;
            idx_r++;
        }
    }
    vid_t start = idx_l;
    while (idx_l < a.size) {
        vid_t left = a.data[idx_l];
        if (left >= up) {
            break;
        }
        idx_l++;
    }
    return idx_out + idx_l - start;
}

template<typename T1, typename T2>
vid_t IntersectSize(const T1 &a, const T2 &b) {
    vid_t idx_l = 0, idx_r = 0, idx_out = 0;
    while ((idx_l < a.size) && (idx_r < b.size)) {
        vid_t left = a.data[idx_l];
        vid_t right = b.data[idx_r];
        if (left < right) {
            idx_l++;
        } else if (right < left) {
            idx_r++;
        } else {
            idx_l++;
            idx_r++;
            idx_out++;
        }
    }
    return idx_out;
}

template<typename T1, typename T2>
vid_t IntersectSize(const T1 &a, const T2 &b, const vid_t up) {
    vid_t idx_l = 0, idx_r = 0, idx_out = 0;
    while ((idx_l < a.size) && (idx_r < b.size)) {
        vid_t left = a.data[idx_l];
        vid_t right = b.data[idx_r];
        if (left >= up) {
            break;
        }
        if (right >= up) {
            break;
        }
        if (left < right) {
            idx_l++;
        } else if (right < left) {
            idx_r++;
        } else {
            idx_l++;
            idx_r++;
            idx_out++;
        }
    }
    return idx_out;
}

template<typename T>
void PrintSet(const std::string &name, const T &vset) {
    Print("set=" << name << " size=" << vset.size << " content=");
    for (vid_t idx = 0; idx < vset.size; idx++) {
        Print(vset.Vertex(idx) << " ");
    }
    PrintLine("");
}

// private method
vid_t GetSize(const vid_t *, const vid_t, const vid_t);

class NeighborSet {
public:
    NeighborSet(const vid_t *array, const vid_t array_size)
            : data(array), size(array_size) {
    }
    NeighborSet(const vid_t *array, const vid_t array_size, const vid_t up)
            : data(array), size(GetSize(array, array_size, up)) {
    }

    NeighborSet(const NeighborSet &) = delete;
    NeighborSet(NeighborSet &&) = default;

    NeighborSet &operator=(const NeighborSet &) = delete;
    NeighborSet &operator=(NeighborSet &&) = default;

    NeighborSet Less(const vid_t) const;

    inline vid_t Vertex(const vid_t index) const {
        return this->data[index];
    }

    const vid_t *data;
    const vid_t size;
};

} // namespace csr

#endif /* INCLUDE_CSR_NEIGHBORSET_HPP_ */
