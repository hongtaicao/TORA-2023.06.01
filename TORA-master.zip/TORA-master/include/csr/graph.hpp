/*
 * graph.hpp
 *
 * represent the data graph
 *
 *  Created on: 0:05 Sunday 2022-8-28
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_CSR_GRAPH_HPP_
#define INCLUDE_CSR_GRAPH_HPP_

#include <string>

#include "include/common.hpp"
#include "include/csr/neighborset.hpp"
#include "include/optim/graph.hpp"

namespace utility {

class Config;

} // namespace utility

namespace csr {

void VerifyBinaryGraph(utility::Config &);

class Graph: public optim::Graph {
public:
    Graph(utility::Config &);
    ~Graph();

    inline eid_t EdgeSize(const lsize_t ilabel) const override {
        auto root_size = this->RootSize(ilabel);
        if (root_size > 0) {
            auto row_index = this->row_index_[ilabel];
            return row_index[root_size] - row_index[0];
        }
        // graph has no edges under this label_index
        return 0;
    }
    inline NeighborSet N(const vid_t vertex) const {
        /* undirected unlabeled neighbor
         * it has only 1 label and the label id is 0
         * therefore the first indexes of row_index_ and column_index are 0
         *
         * also the in-coming neighbor vertices of unlabeled graphs
         */
        rid_t begin = this->row_index_[0][vertex];
        rid_t end = this->row_index_[0][vertex + 1];
        cid_t *neighbor = this->column_index_[0];
        return NeighborSet(neighbor + begin, end - begin);
    }
    inline NeighborSet N(const vid_t vertex, const vid_t up) const {
        /* undirected unlabeled neighbor of vertex and smaller than up
         * also the in-coming neighbor vertices of unlabeled graphs
         */
        rid_t begin = this->row_index_[0][vertex];
        rid_t end = this->row_index_[0][vertex + 1];
        cid_t *neighbor = this->column_index_[0];
        return NeighborSet(neighbor + begin, end - begin, up);
    }
    inline NeighborSet O(const vid_t vertex) const {
        // outgoing neighbor vertices of unlabeled graphs
        rid_t begin = this->row_index_[1][vertex];
        rid_t end = this->row_index_[1][vertex + 1];
        cid_t *neighbor = this->column_index_[1];
        return NeighborSet(neighbor + begin, end - begin);
    }
    inline NeighborSet O(const vid_t vertex, const vid_t up) const {
        // outgoing neighbor vertices of unlabeled graphs and smaller than up
        rid_t begin = this->row_index_[1][vertex];
        rid_t end = this->row_index_[1][vertex + 1];
        cid_t *neighbor = this->column_index_[1];
        return NeighborSet(neighbor + begin, end - begin, up);
    }
    inline vid_t OutDegree(const lsize_t ilabel, const vid_t irow) const
            override {
        auto row_index = this->row_index_[ilabel];
        return row_index[irow + 1] - row_index[irow];
    }
    inline vid_t OutVertex(const lsize_t ilabel, const vid_t irow,
            const vid_t icolumn) const override {
        return this->column_index_[ilabel][this->row_index_[ilabel][irow]
                + icolumn];
    }
    inline vid_t RootSize(const lsize_t ilabel) const override {
        return this->row_size_[ilabel];
    }
    inline vid_t RootVertex(const lsize_t, const vid_t irow) const override {
        return irow;
    }

    void WriteText(const std::string &, const std::string &) const override;

private:
    vid_t *row_size_; // row_size_[i] is the size of row_index_[i]
    /*
     * graph data is represented in CSR format
     * 1. fast neighbor intersection, for worst-case optimal join
     * 2. symmetry breaking
     *
     * each CSR is further indexed by the label id, as a tuple
     * (vlabel, vlabel, elabel, topology)
     *
     * the CSR format of a graph under label id 0 is
     * c = column_index_[0]
     * r = row_index_[0]
     *
     * the neighbor node of vertex 1 is a sub-array in c
     * [c[begin_index], c[end_index])
     * begin_index = r[1]
     * end_index = r[2]
     */
    cid_t **column_index_;
    rid_t **row_index_;
};

} // namespace csr

#endif /* INCLUDE_CSR_GRAPH_HPP_ */
