/*
 * trietree.hpp
 *
 *  Created on: 10:34 AM Sunday 2022-11-06
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_ALGORITHM_TRIETREE_HPP_
#define INCLUDE_ALGORITHM_TRIETREE_HPP_

#include <cstdlib>          // size_t
#include <unordered_map>
#include <vector>

namespace algorithm {

template<typename item_T>
class TriTree {
    // default: private
    // forward declaration
    class TriNode;

public:
    typedef std::vector<item_T> sequence_t;

    TriTree() {
    }
    TriTree(const TriTree<item_T> &) = delete;
    TriTree &operator=(const TriTree<item_T> &) = delete;

    size_t Index(const sequence_t &);
    size_t Match(const sequence_t &);
private:
    TriNode root_;

    // Created on: 2020-2-5 14:42
    // https://www.geeksforgeeks.org/preventing-object-copy-in-cpp-3-different-ways/
    // member instance can't be defined outside
    class TriNode {
    public:
        TriNode()
                : count_(0) {
        }
        ~TriNode() {
            for (auto &pair : this->children_) {
                delete pair.second;
            }
        }
        // deleted copy constructor and copy assignment
        TriNode(const TriNode &) = delete;
        TriNode &operator=(const TriNode &) = delete;

        inline void AddChild(const item_T &child) {
            this->children_[child] = new TriNode();
        }
        inline void AddOne() {
            this->count_ += 1;
        }
        inline size_t GetCount() {
            return this->count_;
        }
        inline TriNode *GetChild(const item_T &child) {
            return this->children_[child];
        }
        inline bool HasChild(const item_T &child) {
            return (this->children_.count(child) > 0);
        }

    private:
        std::unordered_map<item_T, TriNode *> children_;
        size_t count_;
    };
};

template<typename item_T>
size_t TriTree<item_T>::Index(const sequence_t &sequence) {
    TriNode *ptr = &this->root_;
    for (auto const &item : sequence) {
        if (!ptr->HasChild(item)) {
            ptr->AddChild(item);
        }
        ptr = ptr->GetChild(item);
    }
    ptr->AddOne();
    return ptr->GetCount();
}

template<typename item_T>
size_t TriTree<item_T>::Match(const sequence_t &sequence) {
    TriNode *ptr = &this->root_;
    for (auto const &item : sequence) {
        if (ptr->HasChild(item)) {
            ptr = ptr->GetChild(item);
        } else {
            return 0;
        }
    }
    return ptr->GetCount();
}

} // namespace algorithm

#endif /* INCLUDE_ALGORITHM_TRIETREE_HPP_ */
