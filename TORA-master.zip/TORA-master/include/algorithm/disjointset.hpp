/*
 * disjointset.hpp
 *
 *  Created on: 1:47 AM Saturday 2022-10-29
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_ALGORITHM_DISJOINTSET_HPP_
#define INCLUDE_ALGORITHM_DISJOINTSET_HPP_

#include <assert.h>
#include <cstdlib>          // size_t
#include <string>
#include <unordered_map>
#include <unordered_set>

namespace algorithm {

template<typename item_T>
class DisjointSet {
    // default: private
    // forward declaration
    class LabelSize;

public:
    typedef item_T item_t;
    typedef size_t label_t;
    typedef std::unordered_map<label_t, item_T> label2item_t;

    DisjointSet() {
    }
    ~DisjointSet();
    DisjointSet(const DisjointSet &) = delete;
    DisjointSet &operator=(const DisjointSet &) = delete;

    inline void Add(const item_T &item) {
        // each item is is treated as a unique item
        label_t new_label = this->item2label_.size();
        this->item2label_[item] = new_label;
        this->label2info_[new_label] = new LabelSize(new_label);
    }
    template<typename container_T>
    void GetAllItem(container_T &);
    void GetUnionItem(label2item_t &);
    label_t Find(const item_T &);
    size_t Size();
    void Union(const item_T &, const item_T &);

private:
    inline label_t GetLabel(label_t label) {
        return this->label2info_[label]->GetLabel();
    }
    inline size_t GetSize(label_t label) {
        return this->label2info_[label]->GetSize();
    }
    inline void SetLabel(label_t label, label_t new_label) {
        this->label2info_[label]->SetLabel(new_label);
    }
    inline void SetSize(label_t label, size_t new_size) {
        this->label2info_[label]->SetSize(new_size);
    }

    typedef std::unordered_map<item_T, label_t> item2label_t;
    typedef std::unordered_map<label_t, LabelSize *> label2info_t;
    item2label_t item2label_;
    label2info_t label2info_;

    // Created on: 2020-2-5 21:10
    class LabelSize {
    public:
        LabelSize(label_t label)
                : label_(label), size_(1) {
        }
        LabelSize(const LabelSize &) = delete;
        LabelSize &operator=(const LabelSize &) = delete;
        inline label_t GetLabel() {
            return this->label_;
        }
        inline size_t GetSize() {
            return this->size_;
        }
        inline void SetLabel(label_t label) {
            this->label_ = label;
        }
        inline void SetSize(size_t size) {
            this->size_ = size;
        }

    private:
        size_t label_;
        size_t size_;
    };
};

template<typename item_T>
typename DisjointSet<item_T>::label_t DisjointSet<item_T>::Find(
        const item_T &item) {
    assert(this->item2label_.count(item) > 0);
    label_t label = this->item2label_[item];
    while (label != this->label2info_[label]->GetLabel()) {
        label_t temp = this->label2info_[label]->GetLabel();
        label_t next_label = this->label2info_[temp]->GetLabel();
        this->label2info_[label]->SetLabel(next_label);
        label = next_label;
    }
    this->item2label_[item] = label;
    return label;
}

/*
 * https://stackoverflow.com/a/15176127/11193802
 * auto x: work with copies.
 * auto &x: work with original items and may modify them.
 * auto const &x: work with original items and will not modify them
 * auto const / const auto are equivalent
 */
template<typename item_T>
template<typename container_T>
void DisjointSet<item_T>::GetAllItem(container_T &item_1D) {
    for (const auto &pair : this->item2label_) {
        item_1D.push_back(pair.first);
    }
}

template<typename item_T>
void DisjointSet<item_T>::GetUnionItem(label2item_t &label2item) {
    for (const auto &pair : this->item2label_) {
        label_t label = this->Find(pair.first);
        if (label2item.count(label) == 0) {
            label2item[label] = pair.first;
        }
    }
}

template<typename item_T>
size_t DisjointSet<item_T>::Size() {
    std::unordered_set<label_t> label_set;
    for (const auto &pair : this->item2label_) {
        label_set.insert(this->Find(pair.first));
    }
    return label_set.size();
}

template<typename item_T>
void DisjointSet<item_T>::Union(const item_T &a, const item_T &b) {
    label_t label_a = this->Find(a);
    label_t label_b = this->Find(b);
    if (label_a != label_b) {
        size_t merge_size = this->GetSize(label_a) + this->GetSize(label_b);
        if (this->GetSize(label_a) < this->GetSize(label_b)) {
            this->SetLabel(label_a, label_b);
            this->SetSize(label_b, merge_size);
        } else {
            this->SetLabel(label_b, label_a);
            this->SetSize(label_a, merge_size);
        }
    }
}

template<typename item_T>
DisjointSet<item_T>::~DisjointSet() {
    for (auto &pair : this->label2info_) {
        delete pair.second;
    }
}

} // namespace algorithm

#endif /* INCLUDE_ALGORITHM_DISJOINTSET_HPP_ */
