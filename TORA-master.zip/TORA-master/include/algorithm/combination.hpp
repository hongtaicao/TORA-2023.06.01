/*
 * combination.hpp
 *
 *  Created on: 14:03 PM Sunday 2022-11-06
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_ALGORITHM_COMBINATION_HPP_
#define INCLUDE_ALGORITHM_COMBINATION_HPP_

#include <cstdlib>      // size_t
#include <vector>

namespace algorithm {

class Combination {
public:
    /* a combination generator for n choose k
     * (1,1) -> [0]
     * (2,1) -> [0], [1]
     * (2,2) -> [0,1]
     * (3,2) -> [0,1], [0,2], [1,2]
     */
    Combination(size_t, size_t);

    inline bool InRange() const {
        return this->combination.size();
    }
    void Next();

    std::vector<size_t> combination;

private:
    /* n choose k
     * n_ = n-1 is the max value can be chosen
     * k_ = k-1 to index the last value in this->combination
     */
    size_t n_, k_;
};

} // namespace algorithm

#endif /* INCLUDE_ALGORITHM_COMBINATION_HPP_ */
