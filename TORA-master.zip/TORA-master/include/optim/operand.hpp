/*
 * operand.hpp
 *
 *  Created on: 16:24 PM Friday 2022-10-28
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_OPTIM_OPERAND_HPP_
#define INCLUDE_OPTIM_OPERAND_HPP_

#include "include/common.hpp"
#include "include/optim/type.hpp"

namespace optim {

namespace symbreak {
class SingleNode;
}

typedef typename symbreak::SingleNode SingleNode;

class Query;

class Operand {
public:
    Operand(Query *q)
            : query(q), estimate_size(0.0) {
    }
    ~Operand() {
        this->ClearSymBreak();
    }

    struct AscQuerySizeIsomorphism {
        // sort by the number of Query vertex and isomorphism
        bool operator()(const Operand *, const Operand *) const;
    };
    static inline bool AscSymBreakRuleCount(const Operand *a,
            const Operand *b) {
        // ascending order of the count of symmetry breaking rules
        return a->rule_1d.size() < b->rule_1d.size();
    }
    /* sort symmetry breaking rule by values and then by the count of values
     * no value is considered the smallest
     * should not contain identical rules
     */
    static bool AscSymBreakRuleValueCount(const order_1d_t *,
            const order_1d_t *);

    void BuildSymBreak(SingleNode *);
    void ClearSymBreak();
    bool ContainSymBreak(const Operand *) const;

#ifdef NDEBUG
    inline void DebugPrint(bool) const {
    }
#else
    void DebugPrint(bool end_of_line) const {
        this->PrintDetail(end_of_line);
    }
#endif

    /* find the index of this->mapping_1d such that
     * two Operand.order are the same
     * return -1 if not found
     */
    int FindSameOrder(const Operand *) const;
    bool IsDirectShare(const Operand *) const;

    inline bool IsInput() const {
        // does not need plan, cost is 0
        return this->order.size() == 2;
    }

    bool Isomorphic(const Operand *) const;

    inline bool IsSameOrder(const Operand *other) const {
        return this->FindSameOrder(other) >= 0;
    }

    void KeepCommonSymBreak(Operand *);
    void PrintDetail(bool) const;
    void SortSymBreak();

    /* be careful when accessing query and query vertex order
     * order[0]=a means the first (0-th) vertex is query->v_1d[a]
     */
    // constructor should match type. otherwise pointer is incomplete
    Query *query;           // not owner. shared among operands
    order_1d_t order;       // permutation of Query.v_1d
    double estimate_size;   // the estimated size of the operand
    order_2d_t rule_1d;     // owner. permutation. for symmetry breaking
};

} // namespace optim

#endif /* INCLUDE_OPTIM_OPERAND_HPP_ */
