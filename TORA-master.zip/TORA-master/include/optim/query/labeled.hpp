/*
 * labeled.hpp
 *
 *  Created on: 20:24 PM Friday 2022-10-28
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_OPTIM_QUERY_LABELED_HPP_
#define INCLUDE_OPTIM_QUERY_LABELED_HPP_

#include <string>
#include <unordered_map>

#include "include/common.hpp"
#include "include/optim/query/base.hpp"
#include "include/optim/type.hpp"

namespace optim {

namespace query {

typedef std::unordered_map<std::string, eid_t> edge_label_t;
typedef vid_map_t vertex_label_t;

// a base class cannot be forward declared
class Labeled: public Base {
public:
    Labeled(Config &);
    // used in sample induced subgraph
    Labeled(edge_label_t &, vertex_label_t &, edge_map_t &, vid_set_t &);

    size_t Hash(const Query *) override;
    inline bool IsomorphicTo(Query *a_, const vid_t vi, const vid_t vj,
            Query *b_, const vid_t xi, const vid_t xj) override {
        // check labels first
        auto a = (Labeled *) a_->base;
        auto b = (Labeled *) b_->base;
        // check vertex label
        if (a->vlabel_[vi] != b->vlabel_[xi]) {
            return false;
        }
        if (a->vlabel_[vj] != b->vlabel_[xj]) {
            return false;
        }
        auto count = a->HasEdge(vi, vj) + b->HasEdge(xi, xj);
        if (count == 1) {
            // out-going edges do not match
            return false;
        } else if ((count == 2) and (a->Label(vi, vj) != b->Label(xi, xj))) {
            // out-going edge labels do not match
            return false;
        }
        count = a->HasEdge(vj, vi) + b->HasEdge(xj, xi);
        if (count == 1) {
            // in-coming edges do not match
            return false;
        } else if ((count == 2) and (a->Label(vj, vi) != b->Label(xj, xi))) {
            // in-coming edge labels do not match
            return false;
        }
        return true;
    }
    inline vid_t Label(const vid_t a) override {
        // return vertex label
        return this->vlabel_[a];
    }
    inline eid_t Label(const vid_t a, const vid_t b) override {
        /* return edge label
         * edge might not exist and therefore should check edge before label
         */
        return this->elabel_[ToString2(a, b)];
    }

private:
    edge_label_t elabel_;
    vertex_label_t vlabel_;
};

} // namespace query

} // namespace optim

#endif /* INCLUDE_OPTIM_QUERY_LABELED_HPP_ */
