/*
 * costbound.hpp
 *
 * use cost model and estimate the cost bound for an Expression
 *
 *  Created on: 10:30 AM Tuesday 2022-11-08
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_OPTIM_TOPDOWN_COSTBOUND_HPP_
#define INCLUDE_OPTIM_TOPDOWN_COSTBOUND_HPP_

#include "include/optim/type.hpp"

namespace optim {

class CostModel;
class Query;

namespace topdown {

class CostBound {
public:
    void SetInputExpressionCost(Expression *) const;
    void SetJoinExpressionCost(Expression *) const;
    void SetSelectExpressionCost(Expression *) const;
    void SetTransposeExpressionCost(Expression *) const;

    // shared. pointer due to different cost model
    CostModel *costmodel;
};

}

} // namespace

#endif /* INCLUDE_OPTIM_TOPDOWN_COSTBOUND_HPP_ */
