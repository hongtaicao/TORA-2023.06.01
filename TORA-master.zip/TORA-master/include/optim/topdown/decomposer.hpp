/*
 * decomposer.hpp
 *
 * generate decomposition given an operand
 * cache based decomposition
 *
 * 1. determine what kind of decomposition
 *      1. avoid duplicated decompositions
 * 2. cache operand and their decomposition
 *      1. determine the amount of caching. cache base/all
 * 3. manage resources
 *      1. owner of all operands
 *
 *  Created on: 7:25 AM Sunday 2022-10-30
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_OPTIM_TOPDOWN_DECOMPOSER_HPP_
#define INCLUDE_OPTIM_TOPDOWN_DECOMPOSER_HPP_

#include <cstdlib>          // size_t
#include <unordered_map>
#include <vector>

#include "include/optim/type.hpp"

namespace optim {

class Expression;
class TopologyTable;

namespace topdown {

class Decomposition;
typedef std::vector<Decomposition *> decomp_1d_t;
typedef std::vector<decomp_1d_t *> decomp_2d_t;
typedef std::unordered_map<size_t, decomp_2d_t *> topology_to_decomp_t;

class Decomposer {
public:
    Decomposer(TopologyTable &topology_table)
            : topology_table_(topology_table) {
    }
    ~Decomposer();

    class Generator {
        // generate all decomposition iteratively, one at a time
        // can access private members of Decomposer
    public:
        Generator(Decomposer &, Query *);

        /* usage
         * for (auto g=Generator(...); g.InRange(); g.Next()) {
         *     g.SetDecomposition(...);
         * }
         */
        bool InRange();
        void Next() {
            this->ith_++;
        }
        /* return true if there is decomposition
         * require constructor Query.tid == Expression.operand.query.tid
         */
        bool SetDecomposition(Expression *);

    private:

        decomp_2d_t *decomposition_;    // for a Topology
        size_t ith_;                    // track loop status
        vid_1d_t *iso_mapping_;         // transform Topology to given Query
    };

private:
    // different decomposition methods
    void DecomposeMaxOverlap(Query *, decomp_2d_t *);

    // identify every query topology, whether it is seen before
    TopologyTable &topology_table_;

    // keep track of valid decomposition of a Topology. index by TopologyID
    // therefore not all query has decomposition tracked and map is used
    // topology_id -> list of decomposition (query_1d)
    topology_to_decomp_t tid_to_decomp_;
};

} // namespace topdown

} // namespace optim

#endif /* INCLUDE_OPTIM_TOPDOWN_DECOMPOSER_HPP_ */
