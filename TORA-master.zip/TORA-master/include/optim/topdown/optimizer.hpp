/*
 * optimizer.hpp
 *
 *  Created on: 20:21 PM Thursday 2022-10-27
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_OPTIM_TOPDOWN_OPTIMIZER_HPP_
#define INCLUDE_OPTIM_TOPDOWN_OPTIMIZER_HPP_

#include <queue>
#include <string>
#include <unordered_set>
#include <vector>

#include "include/algorithm/disjointset.hpp"
#include "include/common.hpp"
#include "include/optim/expression.hpp"
#include "include/optim/symbreak/symbreak.hpp"
#include "include/optim/topdown/costbound.hpp"
#include "include/optim/topdown/decomposer.hpp"
#include "include/optim/topologytable.hpp"
#include "include/optim/type.hpp"

namespace abstract {
class Execution;
class Expression;
class Operand;
}

namespace utility {
class Logger;
}

namespace optim {

class CostModel;
class Graph;
class Operand;

namespace topdown {

class Optimizer;

typedef utility::Logger Logger;

// public function
void BuildExecution(Optimizer &, Expression *, abstract::Execution &);

class Optimizer {
    typedef algorithm::DisjointSet<Operand *> djs_t;
    typedef typename djs_t::label2item_t djs_group_t;
    typedef typename djs_group_t::iterator it_map_t;

public:
    Optimizer(Config &, Logger &, Graph &);
    ~Optimizer();

    void BuildAllExpression();
    Expression *BuildOneExpression();
    inline CostModel *GetCostModel() {
        return this->cost_bound_.costmodel;
    }

    Config &config;
    Logger &logger;
    expression_1d_t complete_plan;

private:
    expression_1d_t BuildJoin(const expression_1d_t &, Operand *);
    Expression *BuildRename(Expression *, const operand_1d_t &, djs_group_t &);
    Expression *BuildSelection(Expression *, djs_group_t &);
    void BuildTranspose(Expression *, djs_group_t &, const operand_1d_t &);
    void CollectExpressionOperand(Expression *);
    Expression *PopulateSymmetryBreak(Expression *);
    Expression *ShareNonedge(Expression * const leaf);

    struct AscSymBreakRuleCount {
        // ascending order of the count of symmetry breaking rule
        bool operator()(const it_map_t &, const it_map_t &) const;
    };

    CostBound cost_bound_;              // use cost_model to achieve bound
    TopologyTable topology_table_;      // cache isomorphism among queries
    Decomposer decomposer_;             // need topology_table_ to construct
    symbreak::SymBreak symbreak_;       // manage all rules

    // https://stackoverflow.com/a/34851417/11193802, segment fault
    // https://stackoverflow.com/a/1480483/11193802
    // sort queue element by comparator, top is the end
    // sort in cost descending order => lowest cost at the top
    typedef std::priority_queue<Expression *, expression_1d_t,
            Expression::DescCost> expression_min_heap_t;

    expression_min_heap_t pool_;

    // used for resource release
    // owner of Expression * and Operand *
    std::unordered_set<Expression *> expression_set_;
    std::unordered_set<Operand *> operand_set_;
};

} // namespace topdown

} // namespace optim

#endif /* INCLUDE_OPTIM_TOPDOWN_OPTIMIZER_HPP_ */
