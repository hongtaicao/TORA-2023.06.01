/*
 * query.hpp
 * does not copy edges when creating new instances
 * represents a graph as induced one of Base, computed on the fly
 *
 * query.hpp is actually used in optimization
 * therefore Query is a complete type
 * and polymorphism is derived from Query.Base on the fly
 *
 * to avoid potential infinite recursive calling
 * Query -> Base -> Query -> Base
 * Base should contain all implementation and should not call Query::method
 * Query should simply call Base.method and can avoid virtual method
 *
 *  Created on: 13:22 PM Friday 2022-10-28
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_OPTIM_QUERY_HPP_
#define INCLUDE_OPTIM_QUERY_HPP_

#include "include/common.hpp"
#include "include/optim/type.hpp"

namespace optim {

namespace query {
// forward declaration of a subclass
class Base;

} // namespace query

class Query {
public:
    Query(Query *q)
            : base(q->base), tid(0), size_b(0), size_s(0) {
        // subclass should not call this
        // otherwise double InitializeCounter call
        this->InitializeCounter();
    }
    // below two are used in Decomposer to create decomposed Query
    Query(Query *, vid_1d_t &&);
    Query(Query *, const vid_t);

    virtual ~Query();

    // delete copy construct and copy assignment
    Query(const Query &) = delete;
    Query &operator=(const Query &) = delete;

#ifdef NDEBUG
    inline void DebugPrint(bool) const {
    }
#else
    inline void DebugPrint(bool end_of_line) const {
        this->PrintDetail(end_of_line);
    }
#endif

    inline vid_t Degree(const vid_t vertex) {
        return this->InDegree(vertex) + this->OutDegree(vertex);
    }

    size_t Hash() const;
    bool HasEdge(const vid_t, const vid_t);
    vid_t InDegree(const vid_t) const;
    bool IsEmpty() const;                       // query contain edge or not
    bool IsomorphicTo(Query *);
    bool IsConnected();
    vid_t Label(const vid_t);                   // return vertex label
    eid_t Label(const vid_t, const vid_t);      // return edge label
    vid_t OutDegree(const vid_t vertex);
    void PrintDetail(bool) const;
    edge_map_t &VertexNeighbor() const;         // WARNING: root query edge_map

    struct AscSizeIsomorphism {
        inline bool operator()(const Query *a, const Query *b) {
            // sort by vertex size and then isomorphism
            if (a->v_1d.size() == b->v_1d.size()) {
                return a->tid < b->tid;
            }
            return a->v_1d.size() < b->v_1d.size();
        }
    };

    /* error: 'optim::query::Base* optim::Query::base_' is protected
     * labeled.hpp:31:34: error: within this context
     * https://stackoverflow.com/a/45146678
     */
    query::Base *base;      // to achieve polymorphism labeled/unlabeled
    tid_t tid;              // topology_id, need TopologyTable to figure out
    vid_1d_t v_1d;          // the set of vertexes. can be a random order
    // below are features to generate graph hash
    size_t size_b;          // bidirected edge count
    size_t size_s;          // single directed edge count
    vid_2d_t mapping_1d;    // permutation of topology to be isomorphic to this

protected:
    Query()
            : base(nullptr), tid(0), size_b(0), size_s(0) {
        // should be used by subclass Base
    }
    void InitializeCounter();

private:
    /* call sequence of all IsomorphicTo
     * public Query.IsomorphicTo(Query *, const vid_2d_t &)
     * -> private Query.IsomorphicTo(Query *, const vid_1d_t &)
     * -> base.IsomorphicTo(vid_t, vid_t, Query *, vid_t, vid_t)
     * -> protected Query.IsomorphicTo(vid_t, vid_t, Query *, vid_t, vid_t)
     *
     * to avoid such complicated routing
     * method depend on labels are implemented in Base
     */
};

Query *ReadQuery(Config &);

} // namespace optim

#endif /* INCLUDE_OPTIM_QUERY_HPP_ */
