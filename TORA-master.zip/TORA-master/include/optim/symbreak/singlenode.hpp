/*
 * singlenode.hpp
 *
 * singly linked tree node
 *
 * representation of symmetry breaking rules
 * a nested class used to build tree structures
 * nested class cannot be forward declared and therefore is not exposed
 * Constraint should be bound to Operand because
 * 1. Query is cached for topology
 * 2. Expression gives less information than required to populate constraints
 *
 * now need forward declaration
 * because this class becomes a member of other classes
 *
 *  Created on: 19:55 PM Saturday 2022-12-03
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_OPTIM_SYMBREAK_SINGLENODE_HPP_
#define INCLUDE_OPTIM_SYMBREAK_SINGLENODE_HPP_

#include "include/optim/type.hpp"

namespace optim {

namespace symbreak {

class SingleNode {
    /* representation of symmetry breaking rules
     * each object holds a list of index of query vertexes
     * the first index corresponding vertex is bound to the smallest
     * data graph vertex than other indexes within the list
     */
public:
    SingleNode(SingleNode *p)
            : parent(p) {
    }

#ifdef NDEBUG
    inline void DebugPrint(bool) const {
    }
    inline void DebugPrintChain(bool) const {
    }
#else
    void DebugPrint(bool) const;
    void DebugPrintChain(bool) const;
#endif

    order_1d_t rule_1d;     // a permutation, the index to Query.v_1d
    SingleNode *parent;     // shared by Constraint
};

} // namespace symbreak

} // namespace optim

#endif /* INCLUDE_OPTIM_SYMBREAK_SINGLENODE_HPP_ */
