/*
 * adhoc.hpp
 *
 *  Created on: 14:20 PM Monday 2023-5-22
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_OPTIM_ORDERGENERATOR_ADHOC_HPP_
#define INCLUDE_OPTIM_ORDERGENERATOR_ADHOC_HPP_

#include <cstdlib>          // size_t
#include <string>

#include "include/common.hpp"
#include "include/optim/type.hpp"
#include "include/optim/ordergenerator.hpp"

namespace optim {

class Query;

namespace ordergenerator {

class Adhoc: public OrderGenerator {
public:
    Adhoc(Config &, Query &);

    inline bool InRange() override {
        return this->in_range_;
    }
    void Next() override;

private:
    size_t index_;
    bool in_range_;
    const size_t order_size_;
    const std::string &order_str_;
    vid_1d_t vertex2permute_;

    Query &query_;
};

} // namespace ordergenerator

} // namespace optim

#endif /* INCLUDE_OPTIM_ORDERGENERATOR_ADHOC_HPP_ */
