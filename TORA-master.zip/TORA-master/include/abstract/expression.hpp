/*
 * expression.hpp
 *
 *  Created on: 14:55 PM Friday 2023-2-17
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_ABSTRACT_EXPRESSION_HPP_
#define INCLUDE_ABSTRACT_EXPRESSION_HPP_

#include <string>
#include <vector>

#include "include/common.hpp"

namespace abstract {

class Operand;

typedef std::vector<order_1d_t> vec2_t;

class Expression {
    /* correspond to a set of Expression in Optimization
     * whose results are not materialized
     */
public:
    Expression(Operand *output)
            : output(output) {
    }

    void BuildJoin();

#ifdef NDEBUG
    inline void DebugPrint(bool) {
    }
#else
    inline void DebugPrint(bool end_of_line) {
        this->PrintDetail(end_of_line);
    }
#endif

    /* generate a function name for execution, include
     * input marker, io vertex index mapping, symmetry breaking index
     */
    std::string FunctionName();

    inline bool IsJoin() const {
        return this->input_1d.size() > 1;
    }
    inline bool IsRename() const {
        return this->io_vertex_index.empty();
    }
    inline bool IsTranspose() const {
        // map to both Select and Transpose of optim::Expression
        return this->io_vertex_index.size() and (this->input_1d.size() == 1);
    }

    void PrintDetail(bool);

    /* map each output index to output index that it should be
     * smaller or larger
     * due to the output index order
     * the larger one of symmetry breaking index should be key
     * smaller one should be value
     */
    void SymBreakIndexToBindIndex(vec2_t &, vec2_t &) const;

    // not owner because Expression can share input Operand
    std::vector<Operand *> input_1d;
    /* io_vertex_index saves the Execution input to output vertex index
     * has one to one mapping to Operand in this->input_1d
     * and therefore should sort together with this->input_1d
     * format is designed to best support execute compiled
     * therefore each item (order_1d_t) corresponds to an input Operand
     */
    vec2_t io_vertex_index;
    /* owner. output vertex index. for symmetry breaking
     * it is index and therefore independent of input Operand order
     * it is now part of Expression
     * because symmetry breaking is part of Execution
     */
    order_2d_t symbreak_index;
    // not owner. need this as key to index result value
    Operand *output;
};

} // namespace abstract

#endif /* INCLUDE_ABSTRACT_EXPRESSION_HPP_ */
