/*
 * operand.hpp
 *
 *  Created on: 15:08 PM Friday 2023-2-17
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_ABSTRACT_OPERAND_HPP_
#define INCLUDE_ABSTRACT_OPERAND_HPP_

#include "include/common.hpp"

namespace abstract {

class Operand {
    /* placeholder for both input and output of Expression
     * used to compute name (execute compiled)
     * or argument (execute dynamic)
     * for execution function
     */
public:
    Operand()
            : is_nonedge(false) {
    }
    static bool Compare(const Operand *a, const Operand *b);

#ifdef NDEBUG
    inline void DebugPrint(bool) const {
    }
#else
    inline void DebugPrint(bool end_of_line) const {
        this->PrintDetail(end_of_line);
    }
#endif

    inline bool IsNonedge() const {
        return this->is_nonedge;
    }

    void PrintDetail(bool) const;

    /* only edge / non-edge Operand is required to build following two
     * need Execution to judge if Operand is an input edge / non-edge
     * input Operand does not have an Expression to compute its value
     * if not dge_index.empty(), then it must be an input Operand
     * is_nonedge distinguishes edge and non-edge
     */
    bool is_nonedge;
    edge_index_1d_t edge_index;
    /* used to construct Join execution that should compute together
     * the 0-th vertex of Operand computes the out_index[0]-th
     * output vertex of the root Query
     * it is also guaranteed that out_index[i] < out_index[i+1]
     *
     * cannot replace Expression.io_vertex_index
     * the same Operand can be used as input multiple times
     * therefore its out_index can change for each use
     * therefore later on Execution cannot be constructed from out_index
     */
    order_1d_t out_index;
};

}

#endif /* INCLUDE_ABSTRACT_OPERAND_HPP_ */
