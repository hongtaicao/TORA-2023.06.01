/*
 * graph.hpp
 *
 * file read and write for graphs
 *
 *  Created on: 1:28 AM Sunday 2022-8-28
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_UTILITY_GRAPH_HPP_
#define INCLUDE_UTILITY_GRAPH_HPP_

#include <array>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>

#include "include/common.hpp"
#include "include/utility/config.hpp"
#include "include/utility/utility.hpp"

namespace utility {

namespace graph {

extern const eid_t DefaultLabel;

extern const eid_t UnconnectedEdgeLabel;
extern const eid_t BidirectedEdgeLabel;
extern const eid_t IncomingEdgeLabel;
extern const eid_t OutgoingEdgeLabel;

typedef std::unordered_set<vid_t> neighbor_t;
typedef std::unordered_map<vid_t, neighbor_t> edge_map_t;
typedef std::vector<edge_map_t> edge_map_1d_t;
typedef std::array<eid_t, 4> labelarray_t;
typedef std::vector<labelarray_t> labelarray_1d_t;
typedef std::unordered_map<std::string, labelarray_t> edge_to_labelarray_t;
typedef std::unordered_map<std::string, lsize_t> labelstr_index_t;
typedef std::unordered_map<std::string, std::string> str_map_t;
typedef std::unordered_set<std::string> str_set_t;

void BuildLabelArray1d(const edge_to_labelarray_t &, labelarray_1d_t &);

inline bool HasBinaryData(const std::string &data, const std::string &label) {
    return utility::IsFile(data) and utility::IsFile(label);
}

inline void InsertEdge(const vid_t src, const vid_t dst, edge_map_t &edge_map) {
    if (not edge_map.count(src)) {
        edge_map[src] = neighbor_t();
    }
    edge_map[src].insert(dst);
}

// can read both labeled and unlabeled graph, but process as labeled
void ReadTextGraph(bool, const std::string &, edge_map_t &,
        edge_to_labelarray_t &);

void ReadTextLabelFile(const std::string &, labelstr_index_t &);

void SampleInducedSubgraph(Config &);

class BinaryToText {
public:
    BinaryToText(const std::string &label_file, const std::string &out_file)
            : label_file_(label_file), out_file_(out_file) {
    }

    void WriteTextGraph();

    // update these variable in order to call WriteText() method
    edge_map_t edge_map;
    // edge_to_label_id: map edge string to label_id
    labelstr_index_t edge_to_label_id;

private:
    /* https://stackoverflow.com/a/3097811
     * lifetime of objects and their reference
     * object lifetime is as long as the const reference
     * therefore it is safe to use const reference
     */
    const std::string &label_file_;
    const std::string &out_file_;
};

class TextToBinary {
public:
    TextToBinary(Config &config)
            : vertex_size(0), config_(config) {
    }

    inline static void ReadBinHeader(std::ifstream &in, vid_t &vertex_size,
            vid_t &max_degree, vid_t &label_size) {
        in.read(reinterpret_cast<char *>(&vertex_size), sizeof(vertex_size));
        in.read(reinterpret_cast<char *>(&max_degree), sizeof(max_degree));
        in.read(reinterpret_cast<char *>(&label_size), sizeof(label_size));
        DPrintCTX("read vertex_size=" << vertex_size << " max_degree=");
        DPrintLine(max_degree << " label_size=" << label_size);
    }
    void ReadTextGraph(edge_map_1d_t &, labelstr_index_t &, vid_t &);
    void WriteBinHeader(const std::string &, const edge_map_1d_t &,
            const labelstr_index_t &, const vid_t);

    std::ofstream out;
    vid_t vertex_size;

private:
    Config &config_;
};

} // namespace graph

} // namespace utility

#endif /* INCLUDE_UTILITY_GRAPH_HPP_ */
