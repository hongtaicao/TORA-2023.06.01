/*
 * clock.hpp
 *
 *  Created on: 0:19 Sunday 2022-8-28
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_UTILITY_CLOCK_HPP_
#define INCLUDE_UTILITY_CLOCK_HPP_

#include <chrono>
#include <ctime>
#include <string>

namespace utility {

// https://stackoverflow.com/a/40021836/11193802
// invalid use of template-name 'std::chrono::time_point'
// without an argument list
typedef std::chrono::time_point<std::chrono::system_clock> timepoint_t;

inline std::string GetCurrentTime();
inline double GetDuration(const timepoint_t &);
inline timepoint_t GetTimepoint();

/*
 * https://www.avrfreaks.net/forum/declaring-function-extern-inline-header-file
 * if you want inline global functions with no warning from the compiler
 * you need to put both prototype and definition in the header file as
 * previously mentioned.
 */
inline std::string GetCurrentTime() {
    // return in format %Y_%m_%d-%H_%M_%S
    // https://stackoverflow.com/a/16358111/11193802
    // std::put_time is only supported for GCC > 5.0
    // non C++ solution
    // https://stackoverflow.com/a/16358264/11193802
    time_t rawtime;
    struct tm *timeinfo;
    char buffer[80];

    time(&rawtime);
    timeinfo = localtime(&rawtime);

    // year_month_day-hour_minute_second
    strftime(buffer, sizeof(buffer), "%Y_%m_%d-%H_%M_%S", timeinfo);
    std::string str(buffer);
    return str;
}

// https://www.geeksforgeeks.org/measure-execution-time-function-cpp/
inline timepoint_t GetTimepoint() {
    // return the current time point
    return std::chrono::high_resolution_clock::now();
}

inline double GetDuration(const timepoint_t &start) {
    // return duration in seconds
    // Get current time point
    auto stop = std::chrono::high_resolution_clock::now();
    // Get duration. Subtract time points to get duration
    // To cast it to proper unit use duration cast method
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(
            stop - start);
    return duration.count() / 1000.0;
}

}

#endif /* INCLUDE_UTILITY_CLOCK_HPP_ */
