/*
 * config.hpp
 *
 * parse the command line input
 * hard code all configuration flags to prevent key mismatch at run-time
 *
 * configuration level
 * GraphStorage: CSR, SortTrie
 *  +-- Algorithm: AutoMine, Ours
 *      +-- QueryName
 *
 *  Created on: 0:07 Sunday 2022-8-28
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_UTILITY_CONFIG_HPP_
#define INCLUDE_UTILITY_CONFIG_HPP_

#include <cstdlib>          // size_t
#include <sstream>
#include <string>
#include <unordered_map>

#include "include/common.hpp"

namespace utility {

class Logger;

class Config {
public:
    Config(int argc, char *argv[]);

    void SaveToFile(const Logger &);

    // configuration function
    inline bool AdhocSorttrie() {
        return this->Algorithm() == Config::ValueAdhocSortTrie;
    }
    inline std::string &Algorithm() {
        return this->string_[Config::KeyAlgorithm];
    }
    inline bool AutoMineCSR() {
        return this->Algorithm() == Config::ValueAutoMineCSR;
    }
    inline bool AutoMineShareTrie() {
        return this->Algorithm() == Config::ValueAutoMineShareTrie;
    }
    inline bool AutoMineWCOJ() {
        return this->Algorithm() == Config::ValueAutoMineWCOJ;
    }
    inline std::string BinaryCSR() {
        return this->BinaryDirectory() + "/data.csr.bin";
    }
    inline std::string &BinaryDirectory() {
        return this->string_[Config::KeyBinaryDirectory];
    }
    inline std::string BinarySortTrie() {
        return this->BinaryDirectory() + "/data.sorttrie.bin";
    }
    inline bool CSR() {
        return this->GraphStorage() == Config::ValueCSR;
    }
    inline std::string &DataFile() {
        return this->string_[Config::KeyDataFile];
    }
    inline std::string &DateTime() {
        return this->string_[Config::KeyDateTime];
    }
    inline bool DisableSymmetryBreaking() {
        return this->string_[Config::KeySymmetryBreaking]
                == Config::ValueDisable;
    }
    inline bool EstimateCost() {
        // if plan (-p) and query (-q) are both given
        return this->Plan().size()
                and this->string_[Config::KeyQueryFile].size();
    }
    inline bool ExecuteCompiled() {
        return this->string_[Config::KeyExecute] == Config::ValueExecuteCompiled;
    }
    inline bool ExecuteDynamic() {
        return this->string_[Config::KeyExecute] == Config::ValueExecuteDynamic;
    }
    inline std::string &GraphStorage() {
        return this->string_[Config::KeyGraphStorage];
    }
    inline bool HyperGeometry() {
        return this->string_[Config::KeyCostModel] == Config::ValueHyperGeometry;
    }
    inline bool IsLabeled() {
        return this->int_[Config::KeyIsLabeled];
    }
    inline std::string &LabelFile() {
        return this->string_[Config::KeyLabelFile];
    }
    inline bool OGAdhoc() {
        return this->OrderGenerator() == Config::ValueAdhoc;
    }
    inline bool OGDegreeLabel() {
        return this->OrderGenerator() == Config::ValueDegreeLabel;
    }
    inline bool OGNonAutomorphism() {
        return this->OrderGenerator() == Config::ValueNonAutomorphism;
    }
    inline bool OperandTableSize() {
        return this->string_[Config::KeyOperandSize] == Config::ValueTableSize;
    }
    inline bool OperandTrieSize() {
        return this->string_[Config::KeyOperandSize] == Config::ValueTrieSize;
    }
    inline bool Optimize() {
        // if plan is not given
        return this->string_[Config::KeyPlan].empty();
    }
    inline std::string &OrderGenerator() {
        return this->string_[Config::KeyOrderGenerator];
    }
    inline std::string &Plan() {
        // Plan.getter
        return this->string_[Config::KeyPlan];
    }
    inline void Plan(const std::string &plan) {
        // Plan.setter
        this->string_[Config::KeyPlan] = plan;
    }
    inline bool PowerLaw() {
        return this->string_[Config::KeyCostModel] == Config::ValuePowerLaw;
    }
    inline std::string &QueryFile() {
        return this->string_[Config::KeyQueryFile];
    }
    inline std::string &QueryName() {
        return this->string_[Config::KeyQueryName];
    }
    inline size_t SampleCount() {
        return this->int_[Config::KeySampleCount];
    }
    inline bool SampleInducedSubgraph() {
        return this->int_[Config::KeySampleInducedSubgraph];
    }
    inline int SampleRetryCount() {
        return this->int_[Config::KeySampleRetryCount];
    }
    inline size_t SampleSubgraphSize() {
        return this->int_[Config::KeySampleSubgraphSize];
    }
    inline std::string &SaveFile() {
        // if return "", don't save to file
        return this->string_[Config::KeySaveFile];
    }
    inline std::string &SaveIntermediateFile() {
        return this->string_[Config::KeySaveIntermediateFile];
    }
    inline std::string SaveIntermediateFile(void *suffix) {
        /* https://stackoverflow.com/a/7850160
         * turn an address to string
         */
        std::stringstream ss;
        ss << "-" << suffix << ".txt";
        std::string name(ss.str());
        return this->string_[Config::KeySaveIntermediateFile] + name;
    }
    inline bool ShareSubquery() {
        return this->int_[Config::KeyShareSubquery];
    }
    inline bool SingleDirectedCSR() {
        return this->Algorithm() == Config::ValueSingleDirectedCSR;
    }
    inline bool SymmetryBreaking2007() {
        return this->string_[Config::KeySymmetryBreaking]
                == Config::ValueSymBreak2007;
    }
    inline bool SymmetryBreakingGraphPi() {
        return this->string_[Config::KeySymmetryBreaking]
                == Config::ValueSymBreakGraphPi;
    }
    inline bool SortTrie() {
        return this->GraphStorage() == Config::ValueSortTrie;
    }
    inline bool TopDown() {
        return this->Algorithm() == Config::ValueTopDown;
    }

    /* constant for argument key value pairs
     * error: 'const string {aka const std::basic_string<char>}' cannot be
     * the type of a complete constant expression because it has
     * mutable sub-objects
     *
     * https://stackoverflow.com/a/1563906
     * declare here, and define in implementation file
     */
    const static std::string KeyAlgorithm;
    const static std::string KeyAutomorphism;
    const static std::string KeyBinaryDirectory;
    const static std::string KeyCostModel;
    const static std::string KeyDataFile;
    const static std::string KeyDateTime;
    const static std::string KeyExecute;
    const static std::string KeyGraphStorage;
    const static std::string KeyIsLabeled;
    const static std::string KeyLabelFile;
    const static std::string KeyOperandSize;
    const static std::string KeyOrderGenerator;
    const static std::string KeyPlan;
    const static std::string KeyQueryFile;
    const static std::string KeyQueryName;
    const static std::string KeySampleCount;
    const static std::string KeySampleInducedSubgraph;
    const static std::string KeySampleRetryCount;
    const static std::string KeySampleSubgraphSize;
    const static std::string KeySaveFile;
    const static std::string KeySaveIntermediateFile;
    const static std::string KeyShareSubquery;
    const static std::string KeySymmetryBreaking;
    const static std::string ValueAdhoc;
    const static std::string ValueAdhocSortTrie;
    const static std::string ValueAutoMineCSR;
    const static std::string ValueAutoMineShareTrie;
    const static std::string ValueAutoMineWCOJ;
    const static std::string ValueCSR;
    const static std::string ValueDataQuery;
    const static std::string ValueDataQueryDateTime;
    const static std::string ValueDegreeLabel;
    const static std::string ValueDisable;
    const static std::string ValueExecuteCompiled;
    const static std::string ValueExecuteDynamic;
    const static std::string ValueHyperGeometry;
    const static std::string ValueNonAutomorphism;
    const static std::string ValuePowerLaw;
    const static std::string ValueSingleDirectedCSR;
    const static std::string ValueSortTrie;
    const static std::string ValueSymBreak2007;
    const static std::string ValueSymBreakGraphPi;
    const static std::string ValueTableSize;
    const static std::string ValueTopDown;
    const static std::string ValueTrieSize;
    const static std::string ValueVersionDataQuery;
    const static std::string ValueVersionDataQueryDateTime;

    // other constant variable
    const static std::string FUNCTION_FILE;
    const static std::string LOG_FILE;
    const static std::string Version;

private:
    void DefaultHeader(string_1d_t &) const;
    void PrintParsedArgument();
    void SetOutFileName(const std::string &, const std::string &,
            const std::string &, const std::string &);

    /*
     * https://stackoverflow.com/a/70447240
     * std::unordered_map<std::string const, std::string> uses
     * std::hash<std::string const>, but no specialization exists for
     * hash<std::string const>
     */
    std::unordered_map<std::string, int> int_;
    std::unordered_map<std::string, std::string> string_;
};

} // namespace utility

#endif /* INCLUDE_UTILITY_CONFIG_HPP_ */
