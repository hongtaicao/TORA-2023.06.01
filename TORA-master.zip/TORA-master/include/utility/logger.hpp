/*
 * logger.hpp
 *
 * save performance measure variables
 *
 *  Created on: 2:17 AM Thursday 2022-11-10
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_UTILITY_LOGGER_HPP_
#define INCLUDE_UTILITY_LOGGER_HPP_

#include <cstdlib>          // size_t
#include <string>
#include <unordered_map>

namespace utility {

class Logger {
    typedef std::unordered_map<std::string, std::string> data_t;
public:
    Logger() {
        this->BranchPrunedCount = 0;
        this->BranchTotalCount = 0;
        this->CostMargin = 0;
        this->MatchVertex = "";
        this->MultipleCompletePlan = false;
        this->PlanCount = 0;
        this->PlanCost = 0;
        this->PoolInitialSize = 0;
        this->PoolRemainSize = 0;
        this->SymbreakScore = -1;

        this->DurationBuildOne = 0.0;
        this->DurationInitialPool = 0.0;
        this->DurationSymbreakOne = 0.0;

        this->DurationExecutionCompiled = 0.0;
        this->DurationExecutionDynamic = 0.0;
        this->DurationReadBinaryGraph = 0.0;

        this->AutomorphismCount = 0;
        this->MatchCount = 0;
        this->SymbreakCount = 0;
    }

    inline data_t Data() const {
        data_t data;
        data["BranchPrunedCount"] = std::to_string(this->BranchPrunedCount);
        data["BranchTotalCount"] = std::to_string(this->BranchTotalCount);
        data["CostMargin"] = std::to_string(this->CostMargin);
        data["MatchVertex"] = this->MatchVertex;
        data["MultipleCompletePlan(bool)"] = std::to_string(
                this->MultipleCompletePlan);
        data["PlanCount"] = std::to_string(this->PlanCount);
        data["PlanCost"] = std::to_string(this->PlanCost);
        data["PoolInitialSize"] = std::to_string(this->PoolInitialSize);
        data["PoolRemainSize"] = std::to_string(this->PoolRemainSize);
        data["SymbreakScore"] = std::to_string(this->SymbreakScore);

        data["DurationBuildOne(s)"] = std::to_string(this->DurationBuildOne);
        data["DurationInitialPool(s)"] = std::to_string(
                this->DurationInitialPool);
        data["DurationSymbreakOne(s)"] = std::to_string(
                this->DurationSymbreakOne);

        data["DurationExecutionCompiled(s)"] = std::to_string(
                this->DurationExecutionCompiled);
        data["DurationExecutionDynamic(s)"] = std::to_string(
                this->DurationExecutionDynamic);
        data["DurationReadBinaryGraph(s)"] = std::to_string(
                this->DurationReadBinaryGraph);

        data["AutomorphismCount"] = std::to_string(this->AutomorphismCount);
        data["MatchCount"] = std::to_string(this->MatchCount);
        data["SymbreakCount"] = std::to_string(this->SymbreakCount);
        return data;
    }

    // top-down optimization
    size_t BranchPrunedCount;
    size_t BranchTotalCount;
    double CostMargin;
    std::string MatchVertex;        // query vertex matching order
    bool MultipleCompletePlan;      // whether multiple complete plan in pool
    size_t PlanCount;               // total number of plans for a query
    double PlanCost;                // the best plan cost
    size_t PoolInitialSize;
    size_t PoolRemainSize;
    double SymbreakScore;           // the best plan score

    // time used in top-down optimization computation
    double DurationBuildOne;        // build the first Expression
    double DurationInitialPool;     // build the initial pool
    double DurationSymbreakOne;     // symmetry breaking for first Expression

    // time used in execution
    double DurationExecutionCompiled;
    double DurationExecutionDynamic;
    double DurationReadBinaryGraph;

    // count metric
    size_t AutomorphismCount;
    uint64_t MatchCount;            // number of results
    size_t SymbreakCount;
};

} // namespace utility

#endif /* INCLUDE_UTILITY_LOGGER_HPP_ */
