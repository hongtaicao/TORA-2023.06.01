/*
 * executejoin.hpp
 *
 *  Created on: 02:01 AM Saturday 2023-2-18
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_EXECUTEJOIN_HPP_
#define INCLUDE_SORTTRIE_EXECUTEJOIN_HPP_

#include <array>
#include <cstdlib>          // size_t
#include <string>
#include <unordered_set>
#include <vector>

namespace sorttrie {

class Iterator;
class Join;
class JoinVertex;
class Node;

typedef abstract::Expression Expression;
typedef std::array<size_t, 5> info_t;
typedef std::vector<Join *> join_1d_t;
typedef std::unordered_set<Node *> node_set_t;
typedef std::vector<Node *> node_1d_t;
typedef std::vector<order_1d_t> vec2_t;

class ExecuteJoin {
public:
    ExecuteJoin(const Expression *, const node_1d_t &, const node_set_t &,
            const vid_t);
    ~ExecuteJoin();

    Node *Result();
    Node *Result(const std::string &, uint64_t &);

private:
    void Initialize(size_t);
    Join *InitializeIndex(size_t) const;

    const node_1d_t &in_;                 // join input Node

    // output to input vertex index map
    std::vector<JoinVertex> join_vertex_1d_;
    vec2_t symbreak_low_;
    vec2_t symbreak_up_;

    /* used to index iterator_1d_t, which is flattened
     * each output vertex occupies offset_ positions
     */
    const size_t offset_;
    const vid_t vertex_size_;

    // state variable used in computation
    size_t depth_;
    Iterator **iterator_2d_;
    join_1d_t join_1d_;
    node_1d_t node_1d_;             // this 0-th Node * is release outside
};

class JoinVertex {
    // keep all information required to join one output vertex
public:
    JoinVertex()
            : iter_size(0), iter0_size(0), iter1_size(0) {
    }

#ifdef NDEBUG
    inline void DebugPrint(bool) const {
    }
#else
    void DebugPrint(bool) const;
#endif

    inline void IterateEdgeChild(size_t type_index, size_t output_index) {
        /* Iter[i_th] = new Iterator(join[o_index].Child(type_index), ...)
         * IterN_Type -> Iter
         * i_th = info_t[1]
         * IterN_Type -> Child
         * o_index = output_index
         */
        this->type_index.push_back(
                info_t { JoinVertex::IterN_Type, this->iter_size, IterN_Type,
                        type_index, output_index });
        this->iter_size++;
    }

    inline void IterateEdgeInput(size_t input_index) {
        /* Iter[i_th] = new Iterator(in[input_index], ...)
         * i_th = info_t[1]
         * the 4-th value does not care
         */
        this->type_index.push_back(
                info_t { JoinVertex::IterN_Type, this->iter_size,
                        JoinVertex::IterIn_Type, input_index });
        this->iter_size++;
    }

    inline void IterateNonedgeChild(size_t type_index, size_t output_index) {
        /* Iter1[i_th] = new Iterator(join[o_index].Child0(type_index), ...)
         * Iter1_Type -> Iter1
         * i_th = info_t[1]
         * o_index = output_index
         * Iter0_Type -> Child0
         */
        this->type_index.push_back(
                info_t { JoinVertex::Iter1_Type, this->iter1_size,
                        JoinVertex::Iter0_Type, type_index, output_index });
        this->iter1_size++;
    }

    inline void IterateNonedgeInput(size_t input_index) {
        /* Iterate a non-edge input Node
         * its Iterator type is Iter0_Type
         * it is the i_th input Node of non-edge, i_th=this->iter0_size
         * the index to Iterator is i_th
         * e.g., Iter0[i_th] = new Iterator(...)
         *
         * it should be an input Node
         * because Iter0 cannot be a child Node
         * and the index of input Node is input_index
         *
         * therefore
         * Iter0[i_th] = new Iterator(in[input_index], ...)
         * Iter0_Type -> Iter0
         * i_th = info_t[1]
         * IterIn_Type -> in
         */
        this->type_index.push_back(
                info_t { JoinVertex::Iter0_Type, this->iter0_size,
                        JoinVertex::IterIn_Type, input_index });
        this->iter0_size++;
    }

    // static const variable
    static const size_t Iter0_Type;     // child 0 Iterator
    static const size_t Iter1_Type;     // child 1 Iterator
    static const size_t IterN_Type;     // normal Iterator
    static const size_t IterIn_Type;    // input Iterator

    /* 5 value tuple
     * current Iterator Type: Iter0_Type, Iter1_Type, IterN_Type, IterIn_Type
     * current Iterator index: the index-th Iterator
     * previous Iterator Type: Iter0_Type, Iter1_Type, IterN_Type, IterIn_Type
     * previous Iterator index: the index-th Iterator
     * previous output vertex index: where to find the child Node
     *
     * if an input Node is first used
     * then
     * previous Iterator Type=IterIn_Type
     * previous Iterator index: the index to the input Node
     * previous output vertex index: don't care
     */
    std::vector<info_t> type_index;

    // count the number of Join types
    size_t iter_size;
    size_t iter0_size;
    size_t iter1_size;
};

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_EXECUTEJOIN_HPP_ */
