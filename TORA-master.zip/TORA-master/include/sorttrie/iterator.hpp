/*
 * iterator.hpp
 *
 * iterate thought Node.children and value of each child
 * multiple Iterator can share the same Node
 *
 *  Created on: 0:47 AM Friday 2022-9-9
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_ITERATOR_HPP_
#define INCLUDE_SORTTRIE_ITERATOR_HPP_

#include <queue>
#include <vector>

#include "include/common.hpp"
#include "include/sorttrie/node.hpp"

namespace sorttrie {

class Iterator {
public:
    Iterator(const Node *node)
            : ptr_(node->Data()), end_(node->Data() + node->Size()) {
    }
    Iterator(const value_t low, const Node *node)
            : ptr_(node->Data()), end_(node->Data() + node->Size()) {
        /*
         * node->children_ is assumed ascending order
         * lower bound points to new first child
         */
        this->Greater(low);
    }
    Iterator(const Node *node, const value_t up)
            : ptr_(node->Data()), end_(node->Data() + node->Size()) {
        // upper bound points to new last child
        this->Less(up);
    }
    Iterator(const value_t low, const Node *node, const value_t up)
            : ptr_(node->Data()), end_(node->Data() + node->Size()) {
        this->Greater(low);
        this->Less(up);
    }
    Iterator(const Iterator &other)
            : ptr_(other.ptr_), end_(other.end_) {
        // copy constructor
        // used when Iterator is re-used across loops
    }
    Iterator &operator=(const Iterator &) = delete; // copy assignment

#ifdef NDEBUG
    inline void DebugPrint(bool) const {
    }
#else
    void DebugPrint(bool) const;
#endif

    // set (ptr_) to the first value such that ptr_->value >= target
    inline Iterator *Equal(const value_t value) {
        return this->GreaterEqual(value);
    }

    // set (ptr_) to the first value such that ptr_->value > target
    Iterator *Greater(const value_t);
    // set (ptr_) to the first value such that ptr_->value >= target
    Iterator *GreaterEqual(const value_t);

    inline bool InRange() const {
        return this->ptr_ < this->end_;
    }

    // set (end_) to the first value such that end_->value_ >= target
    Iterator *Less(const value_t);

    // set (end_) to the first value such that end_->value_ > target
    inline Iterator *LessEqual(const value_t value) {
        /* https://stackoverflow.com/a/70044648
         * The trick here is to search for searchValue + 1
         */
        return this->Less(value + 1);
    }

    inline bool Match(const value_t value) {
        if (this->InRange()) {
            return this->Equal(value)->InRange() and (this->Value() == value);
        }
        return false;
    }

    inline void Next() {
        this->ptr_++;
    }
    inline Node *GetNode() const {
        return (*this->ptr_);
    }
    inline vid_t Size() const {
        return this->end_ - this->ptr_;
    }
    inline value_t Value() const {
        return (*this->ptr_)->Value();
    }

    struct ComparatorGreater {
        inline bool operator()(const Iterator *a, const Iterator *b) const {
            return a->Value() > b->Value();
        }
    };
    // descending order. top is min
    typedef std::priority_queue<Iterator *, std::vector<Iterator *>,
            ComparatorGreater> iterator_min_heap_t;

private:
    // assume in ascending order
    pointer_t ptr_;
    pointer_t end_;
};

typedef std::vector<Iterator *> iterator_1d_t;
typedef typename iterator_1d_t::size_type size_type;

#ifdef NDEBUG
#define DPrintIterator(x, y)                                    (void (0))
#else
void DPrintIterator(Iterator **, vid_t);
#endif

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_ITERATOR_HPP_ */
