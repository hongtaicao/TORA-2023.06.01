/*
 * adhoc_expression.hpp
 *
 *  Created on: 13:06 PM 2023-5-11
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_COMPILE_ADHOC_EXPRESSION_HPP_
#define INCLUDE_SORTTRIE_COMPILE_ADHOC_EXPRESSION_HPP_

#include <cstdint>
#include <string>
#include <unordered_map>

#include "include/common.hpp"
#include "include/sorttrie/node.hpp"    // expression_map_t

namespace sorttrie {

namespace compile {

namespace adhoc {

// https://www.learncpp.com/cpp-tutorial/78-function-pointers/
using counting_t = uint64_t (*)(node_1d_t &);
typedef std::unordered_map<std::string, counting_t> counting_map_t;

extern counting_map_t COUNTING_EXPRESSION;
extern expression_map_t MATCHING_EXPRESSION;

void CountByShare(node_1d_t &, const std::string &, const std::string &);
void CountQuery(node_1d_t &, const std::string &, const std::string &);

Node *MatchByShare(node_1d_t &, const std::string &, const std::string &);
Node *MatchQuery(node_1d_t &, const std::string &, const std::string &);

void SetDegreeSize(const vid_t, const vid_t);

} // namespace adhoc

} //namespace compile

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_COMPILE_ADHOC_EXPRESSION_HPP_ */
