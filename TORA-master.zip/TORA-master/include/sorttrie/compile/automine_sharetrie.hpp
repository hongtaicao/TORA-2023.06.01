/*
 * automine_sharetrie.hpp
 *
 *  Created on: Thursday 13:50 PM 2023-4-6
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_COMPILE_AUTOMINE_SHARETRIE_HPP_
#define INCLUDE_SORTTRIE_COMPILE_AUTOMINE_SHARETRIE_HPP_

namespace utility {

class Config;
class Logger;

} // namespace utility

namespace sorttrie {

class Graph;

namespace compile {

namespace automine_sharetrie {

typedef utility::Config Config;
typedef utility::Logger Logger;

bool ExecuteByQueryName(Config &, const Graph &, Logger &);

} // namespace automine_sharetrie

} // namespace compile

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_COMPILE_AUTOMINE_SHARETRIE_HPP_ */
