/*
 * automine_wcoj.hpp
 *
 *  Created on: 18:41 PM Friday 2022-9-16
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_COMPILE_AUTOMINE_WCOJ_HPP_
#define INCLUDE_SORTTRIE_COMPILE_AUTOMINE_WCOJ_HPP_

namespace utility {

class Config;
class Logger;

} // namespace utility

namespace sorttrie {

class Graph;

namespace compile {

namespace automine_wcoj {

typedef utility::Config Config;
typedef utility::Logger Logger;

bool ExecuteByQueryName(Config &, const Graph &, Logger &);

} // namespace automine_wcoj

} // namespace compile

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_COMPILE_AUTOMINE_WCOJ_HPP_ */
