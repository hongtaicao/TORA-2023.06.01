/*
 * sorttrie.hpp
 *
 * build sort trie from nested map
 *
 *  Created on: Thursday 2:05 AM 2023-2-16
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_COMPILE_SORTTRIE_HPP_
#define INCLUDE_SORTTRIE_COMPILE_SORTTRIE_HPP_

#include <unordered_map>
#include <vector>

#include "include/common.hpp"
#include "include/sorttrie/node.hpp"

namespace sorttrie {

namespace compile {

typedef std::vector<vid_t> vid_1d_t;

// variable depth nested map https://stackoverflow.com/a/22792549
template<typename Key, typename Value, unsigned int N>
struct VarMapHelper {
    typedef std::unordered_map<Key,
            typename VarMapHelper<Key, Value, N - 1>::type> type;
};

template<typename Key, typename Value>
struct VarMapHelper<Key, Value, 2> {
    typedef std::unordered_map<Key, Value> type;
};

template<typename Key, typename Value, unsigned int N>
using VarMap = typename VarMapHelper<Key, Value, N>::type;

// a specialization for BuildSortTrieX. X is the number of vertexes
template<unsigned int N>
using HashTrie = typename VarMapHelper<vid_t, vid_1d_t, N>::type;

// declare and define a template for all other cases
template<unsigned int N>
Node *BuildSortTrie(HashTrie<N> &) {
    /* define the primary template
     * primary template should not be instantiated
     * compile time assertion, static_assert can catch it at runtime
     * but does not work
     * static_assert(false, "BuildSortTrie<N> cannot be instantiated.");
     * because it will instantiate at compile time even if it is not called
     */
    PrintLCTX("vertex count N supported=[2,9]. get N=" << N);
    SystemExit(-1);
    return new Node(0);
}

Node *BuildSortTrie(HashTrie<2> &);
Node *BuildSortTrie(HashTrie<3> &);
Node *BuildSortTrie(HashTrie<4> &);
Node *BuildSortTrie(HashTrie<5> &);
Node *BuildSortTrie(HashTrie<6> &);
Node *BuildSortTrie(HashTrie<7> &);
Node *BuildSortTrie(HashTrie<8> &);
Node *BuildSortTrie(HashTrie<9> &);

} // namespace compile

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_COMPILE_SORTTRIE_HPP_ */
