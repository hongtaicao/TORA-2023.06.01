/*
 * joins01.hpp
 *
 * join 1 relation, multiple root levels and leaf levels of negation
 *
 *  Created on: 12:57 PM Thursday 2023-3-2
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOINS01_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOINS01_HPP_

#include "include/sorttrie/join/joins1.hpp"

namespace sorttrie {

namespace join {

class JoinS01: public join::JoinS1 {
public:
    JoinS01(Iterator **iter, Iterator **iter0, vid_t size0, Iterator **iter1,
            vid_t size1)
            : JoinS1(iter, iter1, size1), iterator0_(iter0), size0_(size0) {
        /* iter0 contains self-loops and therefore they always join
         * they are not considered when join other iterators
         * need to adjust the pointer when requesting its leaf level
         */
        DPrintLCTX("**iterator0=" << iter0 << " size0=" << size0);
        DPrintIterator(this->iterator0_, size0);
    }
    ~JoinS01();

    // return the index-th child Node of the join value
    inline Node *Child0(vid_t index) const override {
        // need to adjust to the child level of the join value
        return this->iterator0_[index]->Equal(this->Value())->GetNode();
    }

private:
    // owner of Iterator *, but not Iterator **
    Iterator **iterator0_;
    size_type size0_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOINS01_HPP_ */
