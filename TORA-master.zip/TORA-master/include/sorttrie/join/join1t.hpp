/*
 * join1t.hpp
 *
 * join multiple relation and 2 leaf levels of negation
 *
 *  Created on: 3:26 AM Friday 2023-3-3
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOIN1T_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOIN1T_HPP_

#include "include/sorttrie/join/join.hpp"

namespace sorttrie {

namespace join {

class Join1T: public join::Join {
public:
    Join1T(Iterator **iter, vid_t size, Iterator **iter1)
            : Join(iter, size), iter1_a_(iter1[0]), iter1_b_(iter1[1]) {
        // negation is not initialized. does not check negation
        DPrintLCTX("**iter1=" << iter1);
        this->iter1_a_->DebugPrint(true);
        this->iter1_b_->DebugPrint(true);
        this->Negate();
    }
    ~Join1T() {
        delete this->iter1_a_;
        delete this->iter1_b_;
    }

    // should be at a joined value when calling this function
    inline void Next() override {
        Join::Next();
        this->Negate();
    }

private:
    void Negate();

    // owner of Iterator *
    Iterator *iter1_a_, *iter1_b_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOIN1T_HPP_ */
