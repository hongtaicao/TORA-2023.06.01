/*
 * joins.hpp
 *
 * join only a single Iterator(Node).
 * Iterator is not shared. Node is shared
 *
 * this class servers as the base class with negation
 * no practical use of join a single Iterator
 * which is just a loop over Iterator
 *
 * no negation
 * take the ownership of Iterator
 * return the join value or the child Node of join value
 *
 *  Created on: 16:09 PM Wednesday 2023-3-1
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOINS_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOINS_HPP_

#include "include/sorttrie/join.hpp"

namespace sorttrie {

namespace join {

class JoinS: public sorttrie::Join {
    // a specialized implementation for a single Iterator(Node) join
public:
    JoinS(Iterator **iterator)
            : iterator_(iterator[0]) {
        DPrintLCTX("**iterator=" << iterator);
        this->iterator_->DebugPrint(true);
    }
    virtual ~JoinS() {
        delete this->iterator_;
    }

    // return the index-th child Node of the join value
    inline Node *Child(vid_t) const override {
        return this->iterator_->GetNode();
    }

    virtual inline Node *Child0(vid_t) const override {
        DPrintLCTX("method called on a wrong Join");
        SystemExit(-1);
    }

    virtual inline bool InRange() const override {
        return this->iterator_->InRange();
    }

    // should be at a join value when calling this function
    virtual inline void Next() override {
        this->iterator_->Next();
    }

    /*
     *  value is always the joined value
     *  therefore can return any one of them
     */
    inline value_t Value() const override {
        return this->iterator_->Value();
    }

private:
    // owner of Iterator *
    Iterator *iterator_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOINS_HPP_ */
