/*
 * joint1t.hpp
 *
 * join 2 relations and 2 leaf levels of negation
 *
 *  Created on: 2:27 AM Friday 2023-3-3
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOINT1T_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOINT1T_HPP_

#include "include/sorttrie/join/joint.hpp"

namespace sorttrie {

namespace join {

class JoinT1T: public join::JoinT {
public:
    JoinT1T(Iterator **iter, Iterator **iter1)
            : JoinT(iter), iter1_a_(iter1[0]), iter1_b_(iter1[1]) {
        // negation is not initialized. does not check negation
        DPrintLCTX("**iterator1=" << iter1 << " size1=2");
        this->iter1_a_->DebugPrint(true);
        this->iter1_b_->DebugPrint(true);
        this->Negate();
    }
    virtual ~JoinT1T() {
        delete this->iter1_a_;
        delete this->iter1_b_;
    }

    // should be at a join value when calling this function
    inline void Next() override {
        join::JoinT::Next();
        this->Negate();
    }

private:
    void Negate();

    // owner of Iterator *
    Iterator *iter1_a_, *iter1_b_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOINT1T_HPP_ */
