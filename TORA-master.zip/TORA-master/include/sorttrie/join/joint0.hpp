/*
 * joint0.hpp
 *
 * join 2 relations and multiple root levels of negation
 *
 *  Created on: 22:44 PM Thursday 2023-3-2
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOINT0_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOINT0_HPP_

#include "include/sorttrie/join/joint.hpp"

namespace sorttrie {

namespace join {

class JoinT0: public join::JoinT {
public:
    JoinT0(Iterator **iter, Iterator **iter0, vid_t size0)
            : JoinT(iter), iterator0_(iter0), size0_(size0) {
        DPrintLCTX("**iterator0=" << iter0 << " size0=" << size0);
        DPrintIterator(iter0, size0);
        AssertJoin0(iter0, size0);
    }
    ~JoinT0();

    // return the index-th child Node of the join value
    inline Node *Child0(vid_t index) const override {
        return this->iterator0_[index]->Equal(this->Value())->GetNode();
    }

private:
    // owner of Iterator *, but not Iterator **
    Iterator **iterator0_; // store NegationRoot
    size_type size0_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOINT0_HPP_ */
