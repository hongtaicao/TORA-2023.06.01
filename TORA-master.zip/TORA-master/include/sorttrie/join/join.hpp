/*
 * join.hpp
 *
 * join multiple Iterator(Node)
 * Iterator is not shared. Node is shared
 *
 * no negation
 * take the ownership of Iterator
 * return the join value or the child Node of join value
 *
 *  Created on: 4:50 AM Wednesday 2022-9-7
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOIN_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOIN_HPP_

#include "include/sorttrie/join.hpp"

namespace sorttrie {

namespace join {

class Join: public sorttrie::Join {
public:
    Join(Iterator **, vid_t);
    virtual ~Join();

    // return the index-th child Node of the join value
    inline Node *Child(vid_t index) const override {
        return this->iterator_[index]->GetNode();
    }

    virtual inline Node *Child0(vid_t) const override {
        DPrintLCTX("method called on a wrong Join");
        SystemExit(-1);
    }

    inline bool InRange() const override {
        return this->pool_.size() == this->size_;
    }

    // should be at a join value when calling this function
    virtual void Next() override;

    /*
     *  value is always the joined value
     *  therefore can return any one of them
     */
    inline value_t Value() const override {
        return this->join_value_;
    }

private:
    // owner of everything in Iterator **, but not Iterator **
    value_t join_value_;
    Iterator **iterator_;

    iterator_heap_t pool_;
    size_type size_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOIN_HPP_ */
