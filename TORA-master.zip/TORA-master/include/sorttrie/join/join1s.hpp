/*
 * join1s.hpp
 *
 * join multiple Iterator(Node) and 1 leaf (1) level of negation
 *
 *  Created on: 3:24 AM Friday 2023-3-3
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOIN1S_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOIN1S_HPP_

#include "include/sorttrie/join/join.hpp"

namespace sorttrie {

namespace join {

class Join1S: public join::Join {
public:
    Join1S(Iterator **iterator, vid_t size, Iterator **iterator1)
            : Join(iterator, size), iterator1_(iterator1[0]) {
        // negation is not initialized. does not check negation
        DPrintLCTX("**iterator1=" << iterator1);
        this->iterator1_->DebugPrint(true);
        this->Negate();
    }
    ~Join1S() {
        delete this->iterator1_;
    }

    // should be at a joined value when calling this function
    inline void Next() override {
        join::Join::Next();
        this->Negate();
    }

private:
    void Negate();

    // owner of Iterator *
    Iterator *iterator1_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOIN1S_HPP_ */
