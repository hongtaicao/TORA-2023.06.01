/*
 * joins01t.hpp
 *
 * join 1 relation, multiple root levels and 2 leaf levels of negation
 *
 *  Created on: 16:31 PM Thursday 2023-3-2
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOINS01T_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOINS01T_HPP_

#include "include/sorttrie/join/joins1t.hpp"

namespace sorttrie {

namespace join {

class JoinS01T: public join::JoinS1T {
public:
    JoinS01T(Iterator **iter, Iterator **iter0, vid_t size0, Iterator **iter1)
            : JoinS1T(iter, iter1), iterator0_(iter0), size0_(size0) {
        /* iter0 contains self-loops and therefore they always join
         * they are not considered when join other iterators
         * need to adjust the pointer when requesting its leaf level
         */
        DPrintLCTX("**iterator0=" << iter0 << " size0=" << size0);
        DPrintIterator(this->iterator0_, size0);
    }
    ~JoinS01T();

    // return the index-th child Node of the join value
    inline Node *Child0(vid_t index) const override {
        // need to adjust to the child level of the join value
        return this->iterator0_[index]->Equal(this->Value())->GetNode();
    }

private:
    // owner of Iterator *, but not Iterator **
    Iterator **iterator0_;
    size_type size0_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOINS01T_HPP_ */
