/*
 * join01s.hpp
 *
 * join multiple relations, multiple root levels of negation and
 * 1 leaf level of negation
 *
 *  Created on: 3:29 AM Friday 2023-3-3
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOIN01S_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOIN01S_HPP_

#include "include/sorttrie/join/join1s.hpp"

namespace sorttrie {

namespace join {

class Join01S: public join::Join1S {
public:
    Join01S(Iterator **iterator, vid_t size, Iterator **iterator0, vid_t size0,
            Iterator **iterator1)
            : Join1S(iterator, size, iterator1) {
        /* iter0 contains self-loops and therefore they always join
         * they are not considered when join other iterators
         * need to adjust the pointer when requesting its leaf level
         */
        DPrintLCTX("**iterator0=" << iterator0 << " size0=" << size0);
        DPrintIterator(iterator0, size0);
        this->iterator0_ = iterator0;
        this->size0_ = size0;
    }
    ~Join01S();

    // return the index-th child Node of the join value
    inline Node *Child0(vid_t index) const override {
        // need to adjust to the child level of the join value
        return this->iterator0_[index]->Equal(this->Value())->GetNode();
    }

private:
    // owner of Iterator *, but not Iterator **
    Iterator **iterator0_;
    size_type size0_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOIN01S_HPP_ */
