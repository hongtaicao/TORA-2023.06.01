/*
 * joins0.hpp
 *
 * join 1 relation and multiple root levels of negation
 *
 *  Created on: 12:50 PM Thursday 2023-3-2
 *      Author: Hongtai Cao
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOINS0_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOINS0_HPP_

#include "include/sorttrie/join/joins.hpp"

namespace sorttrie {

namespace join {

class JoinS0: public join::JoinS {
public:
    JoinS0(Iterator **iter, Iterator **iter0, vid_t size0)
            : JoinS(iter), iterator0_(iter0), size0_(size0) {
        DPrintLCTX("**iterator0=" << iter0 << " size0=" << size0);
        DPrintIterator(iter0, size0);
        AssertJoin0(iter0, size0);
    }
    ~JoinS0();

    // return the index-th child Node of the join value
    inline Node *Child0(vid_t index) const override {
        return this->iterator0_[index]->Equal(this->Value())->GetNode();
    }

private:
    // owner of Iterator *, but not Iterator **
    Iterator **iterator0_; // store NegationRoot
    size_type size0_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOINS0_HPP_ */
